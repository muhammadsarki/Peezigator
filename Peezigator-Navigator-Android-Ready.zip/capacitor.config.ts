import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.peezi.peezigator',
  appName: 'Peezigator Navigator',
  webDir: 'dist',
  android: {
    allowMixedContent: true
  }
};

export default config;
