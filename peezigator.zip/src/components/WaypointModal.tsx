/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Waypoint, WaypointCategory, AppSettings } from '../types';
import { MapPin, Trash2, Edit, Save, Plus, Navigation2, Search, Star, Heart, Camera } from 'lucide-react';

interface WaypointModalProps {
  waypoints: Waypoint[];
  selectedWaypoint: Waypoint | null;
  onSelectWaypoint: (wp: Waypoint | null) => void;
  onAddWaypoint: (wp: Waypoint) => void;
  onRemoveWaypoint: (id: string) => void;
  onEditWaypoint: (updatedWp: Waypoint) => void;
  currentUserEmail: string;
  settings: AppSettings;
  placementPendingCoords: { x: number; y: number; lat: number; lng: number } | null;
  onCancelPlacement: () => void;
}

const CATEGORIES: WaypointCategory[] = [
  'Campsite',
  'Water Source',
  'Harbor',
  'Checkpoint',
  'Landmark',
  'Emergency Point',
  'Hazard',
  'Custom',
];

const PRESET_PHOTOS = [
  { name: 'Wilderness Campsite', url: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&w=400&q=80' },
  { name: 'Oasis Water Pump', url: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=400&q=80' },
  { name: 'Mountain Overlook Checkpoint', url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=400&q=80' },
  { name: 'Active Harbor Bay', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=400&q=80' },
  { name: 'Steep Gorge Canyon Gap (Hazard)', url: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=400&q=80' },
  { name: 'Ancient Stone Ruins', url: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=400&q=80' },
];

export default function WaypointModal({
  waypoints,
  selectedWaypoint,
  onSelectWaypoint,
  onAddWaypoint,
  onRemoveWaypoint,
  onEditWaypoint,
  currentUserEmail,
  settings,
  placementPendingCoords,
  onCancelPlacement,
}: WaypointModalProps) {
  const isDark = settings.theme === 'dark';

  // State controls
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterFavoriteOnly, setFilterFavoriteOnly] = useState<boolean>(false);

  // Form states
  const [wpId, setWpId] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [category, setCategory] = useState<WaypointCategory>('Campsite');
  const [notes, setNotes] = useState<string>('');
  const [lat, setLat] = useState<number>(24.0000);
  const [lng, setLng] = useState<number>(21.5000);
  const [posX, setPosX] = useState<number>(50);
  const [posY, setPosY] = useState<number>(50);
  const [rating, setRating] = useState<number>(4);
  const [isFavorite, setIsFavorite] = useState<boolean>(false);
  const [photoUrl, setPhotoUrl] = useState<string>('');

  // If a coordinate is dropped on the map, trigger auto-creation modal!
  useEffect(() => {
    if (placementPendingCoords) {
      setName(`Pin #${Math.floor(Math.random() * 900) + 100}`);
      setCategory('Custom');
      setNotes('Dropped directly from mapping canvas pointer.');
      setLat(placementPendingCoords.lat);
      setLng(placementPendingCoords.lng);
      setPosX(placementPendingCoords.x);
      setPosY(placementPendingCoords.y);
      setRating(5);
      setIsFavorite(false);
      setPhotoUrl('');
      setIsCreatingNew(true);
      setIsEditing(false);
    }
  }, [placementPendingCoords]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (isEditing && wpId) {
      const original = waypoints.find((w) => w.id === wpId);
      if (original) {
        onEditWaypoint({
          ...original,
          name,
          category,
          notes,
          latitude: lat,
          longitude: lng,
          rating,
          isFavorite,
          photoUrl: photoUrl || undefined,
        });
      }
      setIsEditing(false);
    } else {
      // Create new
      const newWp: Waypoint = {
        id: `wp_${Date.now()}`,
        name,
        latitude: lat,
        longitude: lng,
        category,
        notes,
        createdBy: currentUserEmail || 'guest',
        dateCreated: new Date().toISOString().split('T')[0],
        x: posX,
        y: posY,
        rating,
        isFavorite,
        photoUrl: photoUrl || undefined,
      };
      onAddWaypoint(newWp);
      setIsCreatingNew(false);
      onCancelPlacement(); // Close placement coordinate lock
    }

    // Reset Form
    resetFields();
  };

  const resetFields = () => {
    setWpId('');
    setName('');
    setCategory('Campsite');
    setNotes('');
    setLat(24.0000);
    setLng(21.5000);
    setPosX(50);
    setPosY(50);
    setRating(4);
    setIsFavorite(false);
    setPhotoUrl('');
  };

  const handleEditClick = (wp: Waypoint) => {
    setWpId(wp.id);
    setName(wp.name);
    setCategory(wp.category);
    setNotes(wp.notes);
    setLat(wp.latitude);
    setLng(wp.longitude);
    setPosX(wp.x);
    setPosY(wp.y);
    setRating(wp.rating || 4);
    setIsFavorite(wp.isFavorite || false);
    setPhotoUrl(wp.photoUrl || '');
    setIsEditing(true);
    setIsCreatingNew(false);
  };

  // Category visual helper
  const getCategoryTheme = (cat: WaypointCategory) => {
    switch (cat) {
      case 'Campsite':
        return 'text-yellow-500 border-yellow-500/30 bg-yellow-500/10';
      case 'Water Source':
        return 'text-blue-400 border-blue-400/30 bg-blue-500/10';
      case 'Checkpoint':
        return 'text-[#1fac34] border-[#1fac34]/30 bg-green-500/10';
      case 'Harbor':
        return 'text-cyan-400 border-cyan-400/30 bg-cyan-500/10';
      case 'Landmark':
        return 'text-purple-400 border-purple-400/30 bg-purple-500/10';
      case 'Emergency Point':
        return 'text-red-500 border-red-500/30 bg-red-500/10 font-bold';
      case 'Hazard':
        return 'text-amber-500 border-amber-500/40 bg-amber-500/10 font-bold animate-pulse';
      default:
        return 'text-gray-400 border-gray-400/30 bg-gray-500/10';
    }
  };

  // Filtered list
  const filteredWaypoints = waypoints.filter((wp) => {
    const matchesSearch =
      wp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wp.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wp.notes.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFavorite = !filterFavoriteOnly || wp.isFavorite;
    return matchesSearch && matchesFavorite;
  });

  // Action to toggle favorite on list
  const toggleFavoriteQuick = (wp: Waypoint) => {
    onEditWaypoint({
      ...wp,
      isFavorite: !wp.isFavorite,
    });
  };

  const containerBg = isDark ? 'bg-[#0B0B0B] text-white' : 'bg-zinc-50 text-zinc-900';
  const cardBorderClass = isDark ? 'border-zinc-800 bg-[#161616]' : 'border-zinc-200 bg-white';
  const inputBgClass = isDark ? 'bg-zinc-950 border-zinc-800 text-white focus:border-[#00E676]' : 'bg-white border-zinc-200 text-zinc-850';
  const btnPrimary = isDark ? 'bg-[#00E676] hover:bg-[#00C853] text-black font-extrabold' : 'bg-[#00C853] hover:bg-emerald-700 text-white font-extrabold';

  return (
    <div className={`p-4 h-full overflow-y-auto flex flex-col justify-start space-y-6 ${containerBg}`}>
      
      {/* Header action panel */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-sans font-extrabold uppercase tracking-widest text-[#00E676]">
          WAYPOINT PINS DIRECTORY
        </h3>

        {!isCreatingNew && !isEditing && (
          <button
            onClick={() => {
              resetFields();
              setPosX(Math.floor(Math.random() * 60) + 20);
              setPosY(Math.floor(Math.random() * 60) + 20);
              setIsCreatingNew(true);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold tracking-wider flex items-center gap-1.5 cursor-pointer uppercase ${btnPrimary}`}
          >
            <Plus className="h-4 w-4" /> ADD PIN
          </button>
        )}
      </div>

      {isCreatingNew || isEditing ? (
        /* Form workspace */
        <form onSubmit={handleSubmit} className={`p-5 rounded-2xl border ${cardBorderClass} space-y-4 shadow-xl`}>
          <h4 className="text-sm font-bold uppercase tracking-wider text-gray-200 flex items-center gap-2">
            <MapPin className="h-4 w-4 text-green-500" />
            {isEditing ? 'RE-ORIENT WAYPOINT PIN' : 'CONFIGURE OFF-GRID COORDINATES'}
          </h4>

          {placementPendingCoords && (
            <div className={`p-2.5 rounded-xl text-[11px] font-mono border text-center ${
              isDark ? 'bg-purple-950/20 border-purple-900 text-purple-300 animate-pulse' : 'bg-purple-50 border-purple-200 text-purple-700'
            }`}>
              📡 Locked coordinate source: {posX}% Lat, {posY}% Lng
            </div>
          )}

          <div className="space-y-3.5">
            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Waypoint Label</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Campsite Alpha Oasis"
                className={`w-full px-3.5 py-2 rounded-lg border text-xs outline-none ${inputBgClass}`}
                required
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Category Vibe</label>
              <div className="grid grid-cols-4 gap-1">
                {CATEGORIES.map((cat) => {
                  const isSelected = category === cat;
                  return (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => setCategory(cat)}
                      className={`py-1.5 rounded text-[9px] font-bold tracking-wider uppercase border text-center transition-all cursor-pointer ${
                        isSelected
                          ? (isDark ? 'bg-green-500 text-black border-green-500' : 'bg-[#006ca5] text-white border-sky-700')
                          : 'bg-zinc-800/10 hover:bg-zinc-800/30 text-gray-400 border-transparent text-[8.5px]'
                      }`}
                    >
                      {cat.slice(0, 8)}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3.5">
              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Latitude GPS</label>
                <input
                  type="number"
                  step="0.0001"
                  value={lat}
                  onChange={(e) => setLat(parseFloat(e.target.value) || 24)}
                  className={`w-full px-3.5 py-2 rounded-lg border text-xs outline-none ${inputBgClass}`}
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Longitude GPS</label>
                <input
                  type="number"
                  step="0.0001"
                  value={lng}
                  onChange={(e) => setLng(parseFloat(e.target.value) || 21)}
                  className={`w-full px-3.5 py-2 rounded-lg border text-xs outline-none ${inputBgClass}`}
                />
              </div>
            </div>

            {/* Custom Interactive Elements: ratings and favoriting */}
            <div className="grid grid-cols-2 gap-4 border-t border-b border-gray-700/15 py-3">
              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1.5 font-bold">User Rating</label>
                <div className="flex gap-1 items-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setRating(star)}
                      className="cursor-pointer transition-transform hover:scale-110"
                    >
                      <Star
                        className={`h-4.5 w-4.5 ${
                          star <= rating ? 'fill-amber-500 text-amber-500' : 'text-gray-500'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-mono ml-2 text-amber-400">({rating}/5)</span>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1.5 font-bold">Favorite</label>
                <button
                  type="button"
                  onClick={() => setIsFavorite(!isFavorite)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    isFavorite 
                      ? 'bg-rose-500/10 border-rose-500 text-rose-500' 
                      : 'border-gray-700 text-gray-400 hover:bg-zinc-800/10'
                  }`}
                >
                  <Heart className={`h-3.5 w-3.5 ${isFavorite ? 'fill-rose-500' : ''}`} />
                  {isFavorite ? 'FAVORITED' : 'MARK FAVORITE'}
                </button>
              </div>
            </div>

            {/* Photo Selection and management */}
            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1.5 font-bold flex items-center gap-1">
                <Camera className="h-3 w-3" /> ATTACH EXPLORATION PHOTO
              </label>
              
              <div className="space-y-2">
                <div className="grid grid-cols-3 gap-1.5">
                  {PRESET_PHOTOS.map((preset, index) => {
                    const isSelected = photoUrl === preset.url;
                    return (
                      <button
                        type="button"
                        key={index}
                        onClick={() => setPhotoUrl(preset.url)}
                        className={`relative rounded-lg overflow-hidden border h-10 transition-all group cursor-pointer ${
                          isSelected ? 'border-green-400 ring-2 ring-green-950' : 'border-gray-700 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center p-1 text-[7px] text-white overflow-hidden text-center select-none font-sans leading-none">
                          {preset.name.split(' ')[0]}
                        </div>
                      </button>
                    );
                  })}
                </div>

                <input
                  type="text"
                  value={photoUrl}
                  onChange={(e) => setPhotoUrl(e.target.value)}
                  placeholder="Or paste custom photo URL..."
                  className={`w-full px-3 py-1.5 rounded-lg border text-[10px] font-mono outline-none ${inputBgClass}`}
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Field Notes & Safety Log</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Water quality details, terrain steepness, cellular signal state, emergency warnings..."
                className={`w-full h-18 px-3.5 py-2 rounded-lg border text-xs outline-none resize-none ${inputBgClass}`}
              />
            </div>
          </div>

          <div className="flex gap-2 pt-2 text-xs">
            <button
              type="submit"
              className={`flex-1 py-2.5 rounded-lg flex items-center justify-center gap-1.5 font-bold cursor-pointer ${btnPrimary}`}
            >
              <Save className="h-4 w-4" /> SAVE REGISTER
            </button>
            <button
              type="button"
              onClick={() => {
                setIsCreatingNew(false);
                setIsEditing(false);
                onCancelPlacement();
              }}
              className="px-4 py-2.5 rounded-lg border border-gray-600 hover:bg-zinc-800/30 transition-all font-semibold"
            >
              ABORT
            </button>
          </div>
        </form>
      ) : (
        /* Standard directory viewer */
        <div className="space-y-4">
          
          {/* Custom Search bar & filter controls */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search coordinates, category, notes..."
                className={`w-full pl-9 pr-4 py-2.5 rounded-xl border text-xs outline-none focus:ring-1 ${inputBgClass}`}
              />
            </div>

            {/* Filters */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setFilterFavoriteOnly(!filterFavoriteOnly)}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                  filterFavoriteOnly
                    ? 'bg-rose-500/10 border-rose-500 text-rose-400'
                    : 'border-gray-700 text-gray-400 hover:bg-zinc-800/10'
                }`}
              >
                <Heart className={`h-3 w-3 ${filterFavoriteOnly ? 'fill-rose-500' : ''}`} />
                {filterFavoriteOnly ? 'FAVORITES ONLY' : 'SHOW ALL'}
              </button>
            </div>
          </div>

          {filteredWaypoints.length === 0 ? (
            <div className="p-10 text-center rounded-2xl border border-dashed border-gray-700 text-gray-500 text-xs uppercase space-y-1.5 animate-pulse">
              <span>No Matching Waypoints Found</span>
              <p className="text-[10px] lowercase text-gray-600">click "Drop Pin" on the map screen or click "Add Pin" above!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredWaypoints.map((wp) => {
                const isSelected = selectedWaypoint?.id === wp.id;
                const visualTheme = getCategoryTheme(wp.category);

                return (
                  <div
                    key={wp.id}
                    className={`rounded-xl border transition-all overflow-hidden ${
                      isSelected
                        ? (isDark ? 'border-green-600 bg-emerald-950/10' : 'border-sky-500 bg-sky-50')
                        : (isDark ? 'border-gray-800 bg-[#060a07]/30 hover:border-zinc-700' : 'border-gray-200 hover:bg-gray-50')
                    }`}
                  >
                    {/* Optional waypoint visual image */}
                    {wp.photoUrl && (
                      <div className="w-full h-24 relative overflow-hidden">
                        <img src={wp.photoUrl} alt={wp.name} className="w-full h-full object-cover" />
                        <button
                          onClick={() => toggleFavoriteQuick(wp)}
                          className="absolute right-2 top-2 p-1.5 rounded-full bg-black/55 hover:bg-black/80 text-white cursor-pointer transition-all"
                        >
                          <Heart className={`h-3.5 w-3.5 text-rose-500 ${wp.isFavorite ? 'fill-rose-500' : ''}`} />
                        </button>
                      </div>
                    )}

                    <div className="p-4">
                      <div className="flex items-start justify-between gap-2.5 mb-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="font-bold text-sm truncate">{wp.name}</h4>
                            <span className={`px-2 py-0.5 rounded text-[8px] font-mono tracking-wider uppercase border font-semibold ${visualTheme}`}>
                              {wp.category}
                            </span>
                            {!wp.photoUrl && (
                              <button
                                onClick={() => toggleFavoriteQuick(wp)}
                                className="text-gray-500 hover:text-rose-500 transition-colors"
                              >
                                <Heart className={`h-3.5 w-3.5 ${wp.isFavorite ? 'text-rose-500 fill-rose-500' : ''}`} />
                              </button>
                            )}
                          </div>
                          
                          {/* Rating display */}
                          {wp.rating && (
                            <div className="flex gap-0.5 items-center mt-1">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-3 w-3 ${
                                    i < wp.rating! ? 'fill-amber-500 text-amber-500' : 'text-gray-650'
                                  }`}
                                />
                              ))}
                            </div>
                          )}

                          <p className="text-[10px] font-mono text-gray-400 mt-1">
                            🌐 {wp.latitude.toFixed(4)}°N, {wp.longitude.toFixed(4)}°E
                          </p>
                        </div>

                        <div className="flex flex-col gap-1.5 items-end">
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => onSelectWaypoint(isSelected ? null : wp)}
                              className={`p-1 px-2 text-[10px] uppercase font-bold rounded flex items-center gap-1 cursor-pointer transition-colors ${
                                isSelected
                                  ? 'bg-amber-600 text-white'
                                  : (isDark ? 'bg-zinc-800 hover:bg-zinc-700 text-green-300' : 'bg-gray-150 text-sky-800 hover:bg-gray-200')
                              }`}
                            >
                              <Navigation2 className="h-2.5 w-2.5" /> {isSelected ? 'LOCKED' : 'FOCUS'}
                            </button>
                            
                            <button
                              onClick={() => handleEditClick(wp)}
                              className="p-1.5 rounded border border-gray-600 hover:bg-zinc-800/20 text-gray-400 hover:text-white cursor-pointer"
                            >
                              <Edit className="h-3 w-3" />
                            </button>
                            
                            <button
                              onClick={() => onRemoveWaypoint(wp.id)}
                              className="p-1.5 rounded border border-rose-900 bg-rose-950/10 text-rose-400 hover:bg-rose-900 hover:text-white transition-all cursor-pointer"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {wp.notes && (
                        <p className={`text-xs p-2.5 rounded bg-zinc-900/40 border border-gray-800 font-mono mt-2.5 text-gray-300 leading-relaxed`}>
                          📝 {wp.notes}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
