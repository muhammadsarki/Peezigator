import React, { useState, useEffect, useRef } from 'react';
import { Compass as CompassIcon, RotateCcw, ShieldAlert, Sparkles, Navigation } from 'lucide-react';

interface CompassProps {
  isDark?: boolean;
  onHeadingChange?: (heading: number) => void;
  onToggleSyncMap?: (sync: boolean) => void;
  isMapSynced?: boolean;
}

export default function Compass({
  isDark = true,
  onHeadingChange,
  onToggleSyncMap,
  isMapSynced = false
}: CompassProps) {
  const [heading, setHeading] = useState<number>(0);
  const [permissionState, setPermissionState] = useState<'prompt' | 'granted' | 'denied' | 'unsupported'>('prompt');
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);
  const [hasSensorData, setHasSensorData] = useState<boolean>(false);

  // Handle device orientation events
  const handleOrientation = (event: any) => {
    setHasSensorData(true);
    let currentHeading = 0;

    // 1. Check for iOS webkitCompassHeading (magnetic North)
    if (event.webkitCompassHeading !== undefined && event.webkitCompassHeading !== null) {
      currentHeading = event.webkitCompassHeading;
    }
    // 2. Android deviceorientationabsolute / Standard alpha
    else if (event.alpha !== undefined && event.alpha !== null) {
      // For absolute orientation, 360 - alpha gives direction from magnetic North (clockwise)
      currentHeading = (360 - event.alpha) % 360;
    } else {
      return;
    }

    const roundedHeading = Math.round(currentHeading);
    setHeading(roundedHeading);
    if (onHeadingChange) {
      onHeadingChange(roundedHeading);
    }
  };

  useEffect(() => {
    // Determine initially if deviceorientation is supported
    if (typeof window === 'undefined') return;

    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    const hasDeviceOrientation = 'DeviceOrientationEvent' in window;

    if (!hasDeviceOrientation) {
      setPermissionState('unsupported');
      return;
    }

    // Check if DeviceOrientationEvent has iOS permission request API
    const DeviceOrientationEventClass = (window as any).DeviceOrientationEvent;
    const requiresIOSPermission = DeviceOrientationEventClass && typeof DeviceOrientationEventClass.requestPermission === 'function';

    if (requiresIOSPermission) {
      setPermissionState('prompt');
    } else {
      // Standard browsers just listen immediately
      setPermissionState('granted');
      
      // Prefer absolute orientation for Android
      if ('ondeviceorientationabsolute' in window) {
        (window as any).addEventListener('deviceorientationabsolute', handleOrientation);
      } else {
        (window as any).addEventListener('deviceorientation', handleOrientation);
      }
    }

    return () => {
      if ('ondeviceorientationabsolute' in window) {
        (window as any).removeEventListener('deviceorientationabsolute', handleOrientation);
      } else {
        (window as any).removeEventListener('deviceorientation', handleOrientation);
      }
    };
  }, []);

  // Request orientation permissions (required for Safari/iOS)
  const requestPermission = async () => {
    const DeviceOrientationEventClass = (window as any).DeviceOrientationEvent;
    if (DeviceOrientationEventClass && typeof DeviceOrientationEventClass.requestPermission === 'function') {
      try {
        setIsCalibrating(true);
        const permission = await DeviceOrientationEventClass.requestPermission();
        if (permission === 'granted') {
          setPermissionState('granted');
          if ('ondeviceorientationabsolute' in window) {
            (window as any).addEventListener('deviceorientationabsolute', handleOrientation);
          } else {
            (window as any).addEventListener('deviceorientation', handleOrientation);
          }
        } else {
          setPermissionState('denied');
        }
      } catch (error) {
        console.error('Error requesting orientation permission:', error);
        setPermissionState('denied');
      } finally {
        setIsCalibrating(false);
      }
    } else {
      // No permission mechanism needed (Android / Standard desktop)
      setPermissionState('granted');
      if ('ondeviceorientationabsolute' in window) {
        (window as any).addEventListener('deviceorientationabsolute', handleOrientation);
      } else {
        (window as any).addEventListener('deviceorientation', handleOrientation);
      }
    }
  };

  // Convert degrees to human cardinal direction
  const getCardinal = (deg: number) => {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const index = Math.round(((deg % 360) / 45)) % 8;
    return directions[index];
  };

  return (
    <div className={`p-4 rounded-2xl border shadow-2xl flex flex-col items-center gap-3 select-none transition-all pointer-events-auto backdrop-blur-md ${
      isDark 
        ? 'bg-zinc-950/95 border-emerald-500/20 text-green-300' 
        : 'bg-white/95 border-sky-200 text-zinc-800'
    }`} style={{ width: '150px' }}>
      
      {/* Component Title / Status */}
      <div className="flex flex-col items-center leading-none text-center">
        <span className="text-[8px] font-mono font-black tracking-widest uppercase text-gray-400">Tactical Compass</span>
        <span className="text-[6px] font-mono text-emerald-500 font-extrabold mt-0.5 uppercase">
          {permissionState === 'granted' 
            ? (hasSensorData ? 'LIVE SENSOR DIRECT' : 'WAITING FOR SENSOR') 
            : `${permissionState} mode`}
        </span>
      </div>

      {/* Rotating Compass Rose Dial */}
      <div className="relative w-28 h-28 flex items-center justify-center">
        {/* Radar grids backplate */}
        <div className={`absolute inset-0 rounded-full border border-dashed opacity-25 ${
          isDark ? 'border-emerald-500' : 'border-sky-500'
        }`} />
        <div className={`absolute inset-2 rounded-full border border-dashed opacity-10 ${
          isDark ? 'border-emerald-500' : 'border-sky-500'
        }`} />

        {/* Dial wrapper rotating based on degrees */}
        <div 
          className="w-full h-full transition-transform duration-300 ease-out"
          style={{ transform: `rotate(${-heading}deg)` }}
        >
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {/* Outer ring */}
            <circle cx="50" cy="50" r="48" fill="none" stroke={isDark ? '#10b981' : '#0284c7'} strokeWidth="1" strokeOpacity="0.4" />
            <circle cx="50" cy="50" r="44" fill="none" stroke={isDark ? '#10b981' : '#0284c7'} strokeWidth="0.5" strokeOpacity="0.2" />

            {/* Dial Ticks */}
            {[...Array(24)].map((_, i) => {
              const angle = i * 15;
              const isMajor = angle % 90 === 0;
              const isMedium = angle % 45 === 0 && !isMajor;
              const length = isMajor ? 8 : (isMedium ? 5 : 3);
              const x1 = 50 + 44 * Math.sin((angle * Math.PI) / 180);
              const y1 = 50 - 44 * Math.cos((angle * Math.PI) / 180);
              const x2 = 50 + (44 - length) * Math.sin((angle * Math.PI) / 180);
              const y2 = 50 - (44 - length) * Math.cos((angle * Math.PI) / 180);
              return (
                <line 
                  key={i} 
                  x1={x1} y1={y1} x2={x2} y2={y2} 
                  stroke={isMajor ? '#ef4444' : (isDark ? '#059669' : '#0284c7')} 
                  strokeWidth={isMajor ? 1.5 : 0.75} 
                  strokeOpacity={0.8}
                />
              );
            })}

            {/* Cardinal direction markers */}
            <text x="50" y="16" textAnchor="middle" fontSize="11" fontWeight="900" fill="#ef4444">N</text>
            <text x="85" y="54" textAnchor="middle" fontSize="9" fontWeight="800" fill={isDark ? '#34d399' : '#0284c7'}>E</text>
            <text x="50" y="90" textAnchor="middle" fontSize="9" fontWeight="800" fill={isDark ? '#34d399' : '#0284c7'}>S</text>
            <text x="15" y="54" textAnchor="middle" fontSize="9" fontWeight="800" fill={isDark ? '#34d399' : '#0284c7'}>W</text>

            {/* Intercardinal markers */}
            <text x="73" y="32" textAnchor="middle" fontSize="6.5" fontWeight="700" fill={isDark ? '#6ee7b7' : '#0369a1'} opacity="0.7">NE</text>
            <text x="73" y="74" textAnchor="middle" fontSize="6.5" fontWeight="700" fill={isDark ? '#6ee7b7' : '#0369a1'} opacity="0.7">SE</text>
            <text x="27" y="74" textAnchor="middle" fontSize="6.5" fontWeight="700" fill={isDark ? '#6ee7b7' : '#0369a1'} opacity="0.7">SW</text>
            <text x="27" y="32" textAnchor="middle" fontSize="6.5" fontWeight="700" fill={isDark ? '#6ee7b7' : '#0369a1'} opacity="0.7">NW</text>
            
            {/* Compass needle */}
            <polygon points="50,18 54,50 46,50" fill="#ef4444" />
            <polygon points="50,82 54,50 46,50" fill={isDark ? '#065f46' : '#93c5fd'} />
            <circle cx="50" cy="50" r="3.5" fill="#ffffff" stroke={isDark ? '#065f46' : '#0284c7'} strokeWidth="1.5" />
          </svg>
        </div>

        {/* Real-time reading overlays */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-1">
          <span className="text-xl font-black font-mono leading-none">{heading}°</span>
          <span className="text-[10px] font-black font-mono tracking-wider text-rose-500 leading-none mt-0.5">
            {getCardinal(heading)}
          </span>
        </div>
      </div>

      {/* Synced Mode toggle, only if callback is present */}
      {onToggleSyncMap && (
        <button
          onClick={() => onToggleSyncMap(!isMapSynced)}
          className={`w-full py-1.5 px-2 rounded-lg border text-[9px] font-mono font-bold uppercase transition-all tracking-wider flex items-center justify-center gap-1.5 cursor-pointer hover:scale-102 active:scale-98 ${
            isMapSynced
              ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white border-emerald-400'
              : (isDark ? 'bg-zinc-900/60 border-zinc-800 text-gray-400 hover:text-white' : 'bg-gray-100 border-gray-250 text-gray-600 hover:text-black')
          }`}
          title="Align maps automatically with device orientation"
        >
          <Navigation className={`h-3 w-3 ${isMapSynced ? 'fill-white animate-pulse' : ''}`} style={{ transform: isMapSynced ? 'none' : 'rotate(45deg)' }} />
          {isMapSynced ? 'MAP SYNC: ON' : 'MAP SYNC: OFF'}
        </button>
      )}

      {/* Permission request trigger button for iOS Devices */}
      {permissionState === 'prompt' && (
        <button
          onClick={requestPermission}
          className="w-full py-1.5 px-2 bg-gradient-to-r from-yellow-500 to-amber-600 hover:opacity-90 active:scale-95 text-black font-extrabold text-[8px] uppercase tracking-wider rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 shadow-lg"
        >
          <Sparkles className="h-2.5 w-2.5" />
          Enable Sensor
        </button>
      )}

      {/* Permission Denied notification feedback */}
      {permissionState === 'denied' && (
        <div className="text-[7px] text-red-400 font-mono flex items-center gap-1 border border-red-500/30 p-1 rounded bg-red-950/20 text-center w-full justify-center">
          <ShieldAlert className="h-2.5 w-2.5 shrink-0" />
          <span>ORIENTATION LOCKED</span>
        </div>
      )}
    </div>
  );
}
