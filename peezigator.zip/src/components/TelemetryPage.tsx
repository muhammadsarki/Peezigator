import React, { useState, useEffect } from 'react';
import { 
  Activity, Navigation, Compass as CompassIcon, Shield, Radio, Server, MapPin, Orbit
} from 'lucide-react';
import { AppSettings } from '../types';

interface TelemetryPageProps {
  currentGPS: { x: number; y: number; lat: number; lng: number; heading: number };
  isDark: boolean;
  settings: AppSettings;
  onUpdateGPS?: (gps: { x: number; y: number; lat: number; lng: number; heading: number }) => void;
}

export default function TelemetryPage({
  currentGPS,
  isDark,
  settings,
  onUpdateGPS,
}: TelemetryPageProps) {
  // Mock active satellites based on settings
  const [satellites, setSatellites] = useState<number>(11);
  const [signalStrength, setSignalStrength] = useState<string>('STRONG');
  const [geocodedAddress, setGeocodedAddress] = useState<{ city: string; state: string; country: string }>({
    city: 'Tactical Base',
    state: 'Remote Sector',
    country: 'Off-grid Territory'
  });

  // Fetch coordinates geocoding if available
  useEffect(() => {
    const fetchAddress = async () => {
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${currentGPS.lat}&lon=${currentGPS.lng}&zoom=10&addressdetails=1`
        );
        if (response.ok) {
          const data = await response.json();
          if (data && data.address) {
            const addr = data.address;
            const city = addr.city || addr.town || addr.village || addr.municipality || addr.suburb || 'Tactical Base';
            const state = addr.state || addr.region || addr.county || 'Remote Region';
            const country = addr.country || 'Global Grid';
            setGeocodedAddress({ city, state, country });
          }
        }
      } catch (e) {
        // Safe fallback
      }
    };
    if (currentGPS.lat && currentGPS.lng) {
      fetchAddress();
    }
  }, [currentGPS.lat, currentGPS.lng]);

  // Satellite simulation ticks
  useEffect(() => {
    const interval = setInterval(() => {
      setSatellites(prev => {
        const delta = Math.random() > 0.5 ? 1 : -1;
        const next = prev + delta;
        return next >= 6 && next <= 16 ? next : prev;
      });
      setSignalStrength(prev => {
        const r = Math.random();
        if (r < 0.05) return 'MARGINAL';
        if (r < 0.2) return 'OPTIMAL';
        return 'STRONG';
      });
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const headingDirection = (h: number) => {
    if (h >= 337 || h < 23) return 'N';
    if (h >= 23 && h < 67) return 'NE';
    if (h >= 67 && h < 112) return 'E';
    if (h >= 112 && h < 157) return 'SE';
    if (h >= 157 && h < 202) return 'S';
    if (h >= 202 && h < 247) return 'SW';
    if (h >= 247 && h < 292) return 'W';
    return 'NW';
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto p-4 space-y-4 font-sans text-xs">
      
      {/* Overview Stat Ring Card */}
      <div className={`p-4 rounded-2xl border flex flex-col gap-3 ${
        isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-gray-50 border-gray-100'
      }`}>
        <div className="flex items-center gap-2 border-b border-zinc-800/10 dark:border-zinc-800/40 pb-2 mb-1">
          <Orbit className="h-4 w-4 text-emerald-500 animate-spin-slow" />
          <span className="font-mono font-black uppercase tracking-wider text-emerald-500 text-[10px]">GNSS Space Segment</span>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-0.5">
            <span className="text-[9px] text-gray-400 uppercase font-mono tracking-wider">Active Constellation</span>
            <div className="text-sm font-black font-mono">GPS + GLONASS</div>
          </div>
          <div className="space-y-0.5">
            <span className="text-[9px] text-gray-400 uppercase font-mono tracking-wider">SVs Locked</span>
            <div className="text-sm font-black font-mono text-emerald-400">{satellites} Satellites</div>
          </div>
          <div className="space-y-0.5">
            <span className="text-[9px] text-gray-400 uppercase font-mono tracking-wider">Positioning Fix</span>
            <div className="text-sm font-black font-mono text-emerald-400">3D-TACTICAL RTK</div>
          </div>
          <div className="space-y-0.5">
            <span className="text-[9px] text-gray-400 uppercase font-mono tracking-wider">Signal Quality</span>
            <div className={`text-sm font-black font-mono ${
              signalStrength === 'STRONG' ? 'text-emerald-400' : signalStrength === 'OPTIMAL' ? 'text-sky-400' : 'text-amber-500 animate-pulse'
            }`}>{signalStrength}</div>
          </div>
        </div>
      </div>

      {/* Navigation Telemetry Values */}
      <div className={`p-4 rounded-2xl border flex flex-col gap-3.5 ${
        isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-gray-50 border-gray-100'
      }`}>
        <div className="flex items-center gap-2 border-b border-zinc-800/10 dark:border-zinc-800/40 pb-2">
          <Activity className="h-4 w-4 text-sky-500" />
          <span className="font-mono font-black uppercase tracking-wider text-sky-500 text-[10px]">Real-time Telemetry Sensors</span>
        </div>

        <div className="space-y-2 font-mono">
          <div className="flex justify-between items-center py-1.5 border-b border-zinc-800/10 dark:border-white/5">
            <span className="text-gray-400">LATITUDE</span>
            <span className={`font-extrabold text-sm ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {(currentGPS?.lat ?? 24.1940).toFixed(6)}° N
            </span>
          </div>
          
          <div className="flex justify-between items-center py-1.5 border-b border-zinc-800/10 dark:border-white/5">
            <span className="text-gray-400">LONGITUDE</span>
            <span className={`font-extrabold text-sm ${isDark ? 'text-white' : 'text-zinc-900'}`}>
              {(currentGPS?.lng ?? 21.7366).toFixed(6)}° E
            </span>
          </div>

          <div className="flex justify-between items-center py-1.5 border-b border-zinc-800/10 dark:border-white/5">
            <span className="text-gray-400">TRUE HEADING</span>
            <span className="font-bold text-emerald-400 text-sm">
              {currentGPS?.heading ?? 0}° {headingDirection(currentGPS?.heading ?? 0)}
            </span>
          </div>

          <div className="flex justify-between items-center py-1.5 border-b border-zinc-800/10 dark:border-white/5">
            <span className="text-gray-400">BAROMETRIC ALTITUDE</span>
            <span className="font-bold text-amber-500 text-sm">
              342.5 m
            </span>
          </div>

          <div className="flex justify-between items-center py-1.5 border-b border-zinc-800/10 dark:border-white/5">
            <span className="text-gray-400">computed VELOCITY</span>
            <span className="font-bold text-sky-400 text-sm">
              0.0 km/h
            </span>
          </div>

          <div className="flex justify-between items-center py-1.5">
            <span className="text-gray-400">HORIZONTAL ACCURACY</span>
            <span className="font-bold text-purple-400 text-sm">
              ± 1.4 m
            </span>
          </div>
        </div>
      </div>

      {/* Geocoding details */}
      <div className={`p-4 rounded-2xl border flex flex-col gap-3 ${
        isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-gray-50 border-gray-100'
      }`}>
        <div className="flex items-center gap-2 border-b border-zinc-800/10 dark:border-zinc-800/40 pb-2">
          <MapPin className="h-4 w-4 text-indigo-400" />
          <span className="font-mono font-black uppercase tracking-wider text-indigo-400 text-[10px]">Geographic Geocoding</span>
        </div>

        <div className="space-y-1.5 font-mono">
          <div className="flex justify-between">
            <span className="text-gray-400">NEAREST CITY:</span>
            <span className={`font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>{geocodedAddress.city}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">REGION STATE:</span>
            <span className={`font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>{geocodedAddress.state}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">COUNTRY GRID:</span>
            <span className={`font-bold ${isDark ? 'text-white' : 'text-zinc-900'}`}>{geocodedAddress.country}</span>
          </div>
        </div>
      </div>

      {/* Off-grid Antenna specifications */}
      <div className="p-4 rounded-2xl border border-dashed border-zinc-800/60 dark:border-zinc-800 text-[10px] font-mono text-gray-400 leading-relaxed space-y-1">
        <div className="text-emerald-500 font-extrabold uppercase tracking-wide flex items-center gap-1.5 mb-1 text-[11px]">
          <Radio className="h-3.5 w-3.5" /> Antenna Specifications
        </div>
        <div>RF Front-End: Max 1.2W Pulse L1/L2 Frequency</div>
        <div>RTK Correction Stream: NTRIP Off-Grid Mesh Relay</div>
        <div>Continuous GPS lock guarantees real-time visual alignment.</div>
      </div>

    </div>
  );
}
