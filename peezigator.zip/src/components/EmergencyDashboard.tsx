import React, { useState, useEffect, useRef } from 'react';
import { 
  Phone, AlertTriangle, Wifi, ShieldAlert, Radio, Signal, SignalHigh, X, Copy, Check,
  Share2, ArrowRight, User, Heart, Settings, Trash2, Plus, Clock, Compass, Activity, CheckCircle, RefreshCw
} from 'lucide-react';
import { Waypoint } from '../types';

interface EmergencyDashboardProps {
  currentGPS: {
    lat: number;
    lng: number;
    heading: number;
    x: number;
    y: number;
  };
  batteryLevel: number;
  batteryCharging: boolean;
  isDark: boolean;
  onClose: () => void;
  addToast: (msg: string) => void;
  onActivePanelChange?: (panel: string) => void;
}

// Structured SOS Message format
interface SOSReport {
  id: string;
  timestampUtc: string;
  timestampLocal: string;
  latitude: number;
  longitude: number;
  altitude: number; // simulated
  speed: number; // simulated
  heading: number;
  accuracy: number; // simulated
  batteryLevel: number;
  batteryCharging: boolean;
  userName: string;
  medicalNotes: string;
  emergencyContacts: { name: string; phone: string }[];
  status: 'queued' | 'transmitting' | 'delivered';
  channelUsed: 'Satellite Link' | 'Cellular' | 'Wi-Fi' | 'None';
  attempts: number;
}

// Official Offline Rescue Contacts structure
interface RescueContact {
  id: string;
  name: string;
  category: 'Universal' | 'Maritime' | 'Mountain Rescue' | 'Civil Protection' | 'Medical/Other' | 'Emergency Embassy Numbers';
  number: string;
  description: string;
  icon: string;
}

export default function EmergencyDashboard({
  currentGPS,
  batteryLevel,
  batteryCharging,
  isDark,
  onClose,
  addToast,
  onActivePanelChange
}: EmergencyDashboardProps) {
  // Tabs within Emergency Dashboard
  const [emergencyTab, setEmergencyTab] = useState<'beacon' | 'contacts' | 'profile' | 'satcom'>('beacon');

  // --- 1. CONFIGURABLE NETWORK STATES & COMS PRIORITY SIMULATION ---
  const [wifiAvailable, setWifiAvailable] = useState<boolean>(false);
  const [cellularAvailable, setCellularAvailable] = useState<boolean>(true);
  const [cellularSignalStrength, setCellularSignalStrength] = useState<'none' | 'low' | 'high'>('low');
  
  // Satellite configurations
  const [satAvailable, setSatAvailable] = useState<boolean>(true);
  const [satProvider, setSatProvider] = useState<'native' | 'garmin' | 'iridium'>('native');
  const [pairedDevices, setPairedDevices] = useState<{ id: string; name: string; type: string; battery: number; connected: boolean }[]>([
    { id: 'dev1', name: 'Garmin inReach Mini 2', type: 'External Satellite Link', battery: 89, connected: false },
    { id: 'dev2', name: 'Iridium GO! Exec Relay', type: 'High-Volume Sat Link', battery: 64, connected: false }
  ]);

  // Determine current active channel based on priority rules: Wi-Fi > Cellular > Satellite > None (Queued)
  const getActiveChannel = (): { name: 'Wi-Fi' | 'Cellular' | 'Satellite Link' | 'None'; speed: string; reliability: string } => {
    if (wifiAvailable) {
      return { name: 'Wi-Fi', speed: 'High (Internet)', reliability: 'Stable' };
    }
    if (cellularAvailable && cellularSignalStrength !== 'none') {
      return { name: 'Cellular', speed: 'Medium (Carrier)', reliability: cellularSignalStrength === 'low' ? 'Intermittent' : 'Stable' };
    }
    if (satAvailable) {
      return { name: 'Satellite Link', speed: 'SDR Low (Orbital SDR)', reliability: 'Line-of-Sight Dependent' };
    }
    return { name: 'None', speed: 'N/A', reliability: 'Absolute Off-Grid' };
  };

  const activeChannel = getActiveChannel();

  // --- 2. OFFLINE PERSISTENCE (QUEUE, PROFILE & CONTACTS) ---
  const [medicalNotes, setMedicalNotes] = useState<string>(() => {
    return localStorage.getItem('peezigator_medical_notes') || 'Blood Type: O-Negative | Severe Penicillin Allergy. Wearer of cardiac monitor pacemaker.';
  });
  const [userName, setUserName] = useState<string>(() => {
    return localStorage.getItem('peezigator_user_name') || 'Captain Jack Miller';
  });
  const [customContacts, setCustomContacts] = useState<{ name: string; phone: string }[]>(() => {
    const saved = localStorage.getItem('peezigator_emergency_contacts');
    return saved ? JSON.parse(saved) : [
      { name: 'Sarah Miller (Spouse)', phone: '+1 (555) 902-1430' },
      { name: 'Dr. Aaron Chen (Cardiologist)', phone: '+1 (555) 481-9921' }
    ];
  });

  // Save profile helpers
  useEffect(() => {
    localStorage.setItem('peezigator_medical_notes', medicalNotes);
  }, [medicalNotes]);

  useEffect(() => {
    localStorage.setItem('peezigator_user_name', userName);
  }, [userName]);

  useEffect(() => {
    localStorage.setItem('peezigator_emergency_contacts', JSON.stringify(customContacts));
  }, [customContacts]);

  // SOS Reports Queue
  const [sosReports, setSosReports] = useState<SOSReport[]>(() => {
    const saved = localStorage.getItem('peezigator_sos_queue');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('peezigator_sos_queue', JSON.stringify(sosReports));
  }, [sosReports]);

  // --- 3. CONFIRMATION SLIDER STATE ---
  const [sliderPosition, setSliderPosition] = useState<number>(0);
  const isDragging = useRef<boolean>(false);
  const sliderTrackRef = useRef<HTMLDivElement>(null);

  const [activeSOS, setActiveSOS] = useState<boolean>(() => {
    return sosReports.some(r => r.status === 'transmitting' || r.status === 'queued');
  });

  // Live telemetry parameters (Altitude, Heading, Accuracy, Speed)
  const [simulatedAltitude] = useState<number>(1428); // Alpine Altitude meters
  const [simulatedSpeed] = useState<number>(0.2); // Walking pace km/h
  const [simulatedAccuracy] = useState<number>(1.8); // High-precision 1.8m

  // --- 4. SECURE SOS DISPATCH ENGINE ---
  const triggerSOSBeacon = () => {
    // Collect coordinates immediately
    const utcTime = new Date().toUTCString();
    const localTime = new Date().toLocaleString();
    
    const newReport: SOSReport = {
      id: `SOS-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestampUtc: utcTime,
      timestampLocal: localTime,
      latitude: currentGPS.lat,
      longitude: currentGPS.lng,
      altitude: simulatedAltitude,
      speed: simulatedSpeed,
      heading: currentGPS.heading,
      accuracy: simulatedAccuracy,
      batteryLevel: batteryLevel,
      batteryCharging: batteryCharging,
      userName: userName,
      medicalNotes: medicalNotes,
      emergencyContacts: customContacts,
      status: activeChannel.name === 'None' ? 'queued' : 'transmitting',
      channelUsed: activeChannel.name,
      attempts: 1
    };

    setSosReports(prev => [newReport, ...prev]);
    setActiveSOS(true);
    addToast(activeChannel.name === 'None' 
      ? '🚨 Emergency queued locally! Connecting transmitter...' 
      : `🚨 SOS Beacon Broadcasted via ${activeChannel.name}!`
    );
  };

  // Simulated recursive transmission background worker
  useEffect(() => {
    const interval = setInterval(() => {
      setSosReports(prevReports => {
        let modified = false;
        const next = prevReports.map(report => {
          if (report.status === 'queued' && activeChannel.name !== 'None') {
            modified = true;
            return {
              ...report,
              status: 'transmitting',
              channelUsed: activeChannel.name,
              attempts: report.attempts + 1
            };
          }
          if (report.status === 'transmitting') {
            modified = true;
            // 60% chance to succeed transmission with each tick
            const delivered = Math.random() > 0.4;
            return {
              ...report,
              status: delivered ? 'delivered' : 'transmitting',
              attempts: report.attempts + 1
            };
          }
          return report;
        });
        if (modified) {
          return next;
        }
        return prevReports;
      });
    }, 4500);

    return () => clearInterval(interval);
  }, [activeChannel.name]);

  // Cancel/Abort SOS beacon
  const cancelSOSBeacon = (id: string) => {
    setSosReports(prev => prev.filter(r => r.id !== id));
    // check if any transmitting/queued left
    setTimeout(() => {
      setSosReports(current => {
        const remaining = current.some(r => r.status === 'transmitting' || r.status === 'queued');
        setActiveSOS(remaining);
        return current;
      });
    }, 100);
    addToast('Emergency beacon transmission aborted.');
  };

  // Clear entire delivery history
  const clearHistory = () => {
    setSosReports(prev => prev.filter(r => r.status !== 'delivered'));
    addToast('Distress transmission history cleared.');
  };

  // --- 5. TACTILE SLIDER DRAG HANDLERS ---
  const handleSliderStart = () => {
    isDragging.current = true;
  };

  const handleSliderMove = (clientX: number) => {
    if (!isDragging.current || !sliderTrackRef.current) return;
    const rect = sliderTrackRef.current.getBoundingClientRect();
    const offset = clientX - rect.left - 24; // offset thumb width
    const maxOffset = rect.width - 56; // track bounds minus thumb size
    const percentage = Math.min(Math.max(0, (offset / maxOffset) * 100), 100);
    setSliderPosition(percentage);

    if (percentage >= 98) {
      isDragging.current = false;
      setSliderPosition(100);
      triggerSOSBeacon();
      // Snapback after successful slide
      setTimeout(() => setSliderPosition(0), 1000);
    }
  };

  const handleSliderEnd = () => {
    if (!isDragging.current) return;
    isDragging.current = false;
    if (sliderPosition < 98) {
      // Return thumb back to start smoothly
      setSliderPosition(0);
    }
  };

  // Touch listener hooks
  useEffect(() => {
    const handleTouchMove = (e: TouchEvent) => {
      if (isDragging.current) {
        handleSliderMove(e.touches[0].clientX);
      }
    };
    const handleTouchEnd = () => handleSliderEnd();
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleTouchEnd);
    return () => {
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [sliderPosition]);

  // Mouse listener hooks
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging.current) {
        handleSliderMove(e.clientX);
      }
    };
    const handleMouseUp = () => handleSliderEnd();
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [sliderPosition]);

  // --- 6. EMERGENCY MESSAGING FORMAT GENERATOR ---
  const formatReportText = (report: SOSReport): string => {
    return `=========================================\n` +
           `🚨 EMERGENCY SOS - IMMEDIATE SAR REQUIRED\n` +
           `=========================================\n` +
           `IDENTIFIER: ${report.id}\n` +
           `NAME: ${report.userName || 'Unknown Explorer'}\n` +
           `COORDINATES:\n` +
           `  LATITUDE:  ${report.latitude.toFixed(5)}°N\n` +
           `  LONGITUDE: ${report.longitude.toFixed(5)}°E\n` +
           `  ALTITUDE:  ${report.altitude}m (ASL)\n` +
           `  HEADING:   ${report.heading}°\n` +
           `  ACCURACY:  +/- ${report.accuracy}m\n` +
           `\n` +
           `DEVICE TELEMETRY:\n` +
           `  BATTERY:   ${report.batteryLevel}% ${report.batteryCharging ? '(Solar/Charging)' : '(Discharging)'}\n` +
           `  TIMESTAMP: ${report.timestampUtc}\n` +
           `  LOCAL:     ${report.timestampLocal}\n` +
           `\n` +
           `MEDICAL PROFILES:\n` +
           `  ${report.medicalNotes || 'No notes specified'}\n` +
           `\n` +
           `EMERGENCY CONTACTS:\n` +
           report.emergencyContacts.map((c, idx) => `  [${idx+1}] ${c.name}: ${c.phone}`).join('\n') + `\n` +
           `\n` +
           `This location was generated automatically by the Peezigator Off-Grid Rescue Module.\n` +
           `=========================================`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    addToast('Tactical distress payload copied.');
  };

  // --- 7. OFFLINE EMERGENCY DIRECTORY DATABASE ---
  const OFFICIAL_CONTACTS: RescueContact[] = [
    // UNIVERSAL
    { id: 'c1', name: 'US & Canada Emergency (911)', category: 'Universal' as any, number: '911', description: 'Universal North American dispatch for Police, Fire, and Ambulance.', icon: '🇺🇸' },
    { id: 'c2', name: 'EU General Emergency (112)', category: 'Universal' as any, number: '112', description: 'Universal European Union emergency service dispatch.', icon: '🇪🇺' },
    { id: 'c3', name: 'UK Emergency Service (999)', category: 'Universal' as any, number: '999', description: 'Universal United Kingdom civil defense and emergency service.', icon: '🇬🇧' },
    { id: 'c4', name: 'Australia Emergency (000)', category: 'Universal' as any, number: '000', description: 'Universal Australian primary emergency service number.', icon: '🇦🇺' },
    { id: 'c5', name: 'New Zealand Emergency (111)', category: 'Universal' as any, number: '111', description: 'Universal New Zealand primary emergency service number.', icon: '🇳🇿' },
    { id: 'c6', name: 'Japan Emergency Police (110)', category: 'Universal' as any, number: '110', description: 'National police dispatch for emergency incidents in Japan.', icon: '🇯🇵' },
    { id: 'c7', name: 'Japan Emergency Medical (119)', category: 'Universal' as any, number: '119', description: 'National ambulance and fire dispatch in Japan.', icon: '🇯🇵' },

    // MOUNTAIN RESCUE
    { id: 'mr1', name: 'Swiss Air Rescue - REGA', category: 'Mountain Rescue' as any, number: '1414', description: 'Specialized Swiss Alpine helicopter rescue, avalanche SAR, and high-altitude air medical evacuation.', icon: '🇨🇭' },
    { id: 'mr2', name: 'French High Mountain Gendarmerie (PGHM Chamonix)', category: 'Mountain Rescue' as any, number: '+33 4 50 53 00 55', description: 'Peloton de Gendarmerie de Haute Montagne in Chamonix, specializing in Mont Blanc & Alpine region SAR.', icon: '🇫🇷' },
    { id: 'mr3', name: 'Austrian Mountain Rescue (Bergrettung)', category: 'Mountain Rescue' as any, number: '140', description: 'Austrian national rescue service for alpine and wilderness mountaineering emergencies.', icon: '🇦🇹' },
    { id: 'mr4', name: 'Italian Mountain & Cave Rescue (CNSAS)', category: 'Mountain Rescue' as any, number: '118', description: 'Corpo Nazionale Soccorso Alpino e Speleologico for Italian Alps, Dolomites, and deep cave extractions.', icon: '🇮🇹' },
    { id: 'mr5', name: 'US Rocky Mountain Rescue Group', category: 'Mountain Rescue' as any, number: '+1 303-441-1500', description: 'Specialist volunteer group for alpine search, rock, and avalanche rescue in Colorado Rockies.', icon: '🏔️' },
    { id: 'mr6', name: 'Yosemite Search & Rescue (YOSAR)', category: 'Mountain Rescue' as any, number: '+1 209-372-0200', description: 'Elite search & rescue team for high-angle granite walls, swiftwater, and wilderness tracking.', icon: '🌲' },
    { id: 'mr7', name: 'Denali National Park Ranger Station / SAR', category: 'Mountain Rescue' as any, number: '+1 907-733-2231', description: 'High-altitude mountain rangers for Mt. Denali and vast Alaskan sub-arctic backcountry rescue.', icon: '🏔️' },
    { id: 'mr8', name: 'Himalayan Rescue Association (Nepal HRA)', category: 'Mountain Rescue' as any, number: '+977 1-4440276', description: 'Emergency medical aid and rescue coordination on Everest, Annapurna, and Himalayan routes.', icon: '🇳🇵' },
    { id: 'mr9', name: 'Parks Canada National SAR Dispatch', category: 'Mountain Rescue' as any, number: '+1 877-852-3100', description: 'Mountain safety and wilderness incident rescue dispatch across Canadian Rockies and national parks.', icon: '🇨🇦' },
    { id: 'mr10', name: 'Mountain Rescue England & Wales (MREW)', category: 'Mountain Rescue' as any, number: '999', description: 'National voluntary organization coordinating upland SAR teams. Dial 999 and ask for Mountain Rescue.', icon: '🇬🇧' },
    { id: 'mr11', name: 'Scottish Mountain Rescue (SMR)', category: 'Mountain Rescue' as any, number: '999', description: 'Upland rescue teams across Scottish Highlands. Dial 999, ask for Police, then ask for Mountain Rescue.', icon: '🏴󠁧󠁢󠁳󠁣󠁴󠁿' },
    { id: 'mr12', name: 'New Zealand Land Search & Rescue (LandSAR)', category: 'Mountain Rescue' as any, number: '111', description: 'National volunteer wilderness tracking, cave search, alpine, and canine SAR squads.', icon: '🇳🇿' },
    { id: 'mr13', name: 'Andes Rescue Coordination (Chile Socorro Andino)', category: 'Mountain Rescue' as any, number: '+56 2 2699 4000', description: 'Andean Mountain Rescue Corps (Socorro Andino) for high-altitude cordillera SAR.', icon: '🇨🇱' },

    // MARITIME / COAST GUARD
    { id: 'mc1', name: 'US Coast Guard Search & Rescue', category: 'Maritime' as any, number: '+1 202-372-2100', description: 'National maritime search, emergency coastal vessels, and open ocean helicopter rescues.', icon: '🇺🇸' },
    { id: 'mc2', name: 'UK Maritime & Coastguard Agency', category: 'Maritime' as any, number: '999', description: 'HM Coastguard for UK territorial waters, offshore emergency, and coastal cliffs.', icon: '🇬🇧' },
    { id: 'mc3', name: 'International Coast Guard Dispatch', category: 'Maritime' as any, number: '19', description: 'General international coastal protection, marine rescue, and harbor safety operations.', icon: '⚓' },
    { id: 'mc4', name: 'Royal National Lifeboat Institution (RNLI)', category: 'Maritime' as any, number: '999', description: 'Volunteer lifeboats saving lives at sea around the coasts of UK and Ireland.', icon: '🇮🇪' },

    // CIVIL PROTECTION
    { id: 'cp1', name: 'Civil Protection Agency', category: 'Civil Protection' as any, number: '112', description: 'National disaster management, hazard safety, and shelter coordination.', icon: '🛡️' },
    { id: 'cp2', name: 'FEMA Disaster Assistance (US)', category: 'Civil Protection' as any, number: '+1 800-621-3362', description: 'Federal Emergency Management Agency for disaster response and recovery assistance.', icon: '🇺🇸' },

    // MEDICAL & SATELLITE
    { id: 'ms1', name: 'Global Garmin IERCC (Satellite SOS)', category: 'Medical/Other' as any, number: '+1 936-582-3190', description: 'International Emergency Response Coordination Center for standard active satellite beacons (inReach/GEOS).', icon: '🛰️' },
    { id: 'ms2', name: 'Air Ambulance Worldwide Dispatch', category: 'Medical/Other' as any, number: '+1 727-784-8400', description: 'Emergency medical repatriation flight crews and mobile intensive care units.', icon: '✈️' },
    { id: 'ms3', name: 'International Red Cross Committee', category: 'Medical/Other' as any, number: '133', description: 'Humanitarian emergency response, relief distribution, and medical aid.', icon: '❌' },
    { id: 'ms4', name: 'Red Crescent Emergency Relief', category: 'Medical/Other' as any, number: '115', description: 'Regional humanitarian relief and medical emergency support.', icon: '🌙' },
    { id: 'ms5', name: 'WHO Health Emergencies Programme', category: 'Medical/Other' as any, number: '+41 22 791 2111', description: 'World Health Organization global health crisis and epidemic response unit.', icon: '🇺🇳' },

    // EMBASSY
    { id: 'eb1', name: 'US Emergency Embassy Hotline', category: 'Emergency Embassy Numbers' as any, number: '+1 202-501-4444', description: 'Consular crisis support for overseas travelers and foreign nationals.', icon: '🇺🇸' },
    { id: 'eb2', name: 'EU Consular Emergency Bureau', category: 'Emergency Embassy Numbers' as any, number: '+32 2 281 5600', description: 'European Union multi-nation citizen emergency assistance desk.', icon: '🇪🇺' },
    { id: 'eb3', name: 'UK Emergency Travel/Consular Help', category: 'Emergency Embassy Numbers' as any, number: '+44 20 7008 5000', description: 'Consular support for British nationals in crisis abroad.', icon: '🇬🇧' }
  ];

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('All');

  const filteredContacts = OFFICIAL_CONTACTS.filter(contact => {
    const matchesSearch = contact.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          contact.number.includes(searchQuery) ||
                          contact.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'All' || contact.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className={`h-full flex flex-col font-sans select-none overflow-hidden ${
      isDark ? 'bg-[#08131F] text-zinc-100' : 'bg-zinc-50 text-zinc-900'
    }`}>
      
      {/* 1. COMPACT DASHBOARD MONITOR HEADER */}
      <div className={`p-4 border-b flex flex-col gap-3.5 ${
        isDark ? 'bg-[#111827]/90 border-zinc-800/80' : 'bg-white border-zinc-250 shadow-sm'
      }`}>
        {/* Real-time coordinates dashboard panel */}
        <div className="flex justify-between items-center">
          <div>
            <span className="text-[10px] font-mono tracking-widest opacity-60 uppercase block text-[#00E676] font-extrabold">ACTIVE LOCATION PAYLOAD</span>
            <span className="text-sm font-sans font-black tracking-tight text-white">
              {(currentGPS?.lat ?? 24.1940).toFixed(5)}°N, {(currentGPS?.lng ?? 21.7366).toFixed(5)}°E
            </span>
            <span className="text-[9px] font-mono text-[#00E676] font-semibold block mt-0.5">
              Accuracy: &lt;{simulatedAccuracy}m (ASL: {simulatedAltitude}m)
            </span>
          </div>
          
          {/* Signal summary bubble */}
          <div className="text-right">
            <span className="text-[10px] font-mono tracking-widest opacity-60 uppercase block text-zinc-400 font-extrabold">OUTBOUND PATH</span>
            <div className="flex items-center gap-1.5 justify-end mt-1">
              {activeChannel.name === 'Wi-Fi' && <Wifi className="h-4 w-4 text-[#00E676] animate-pulse" />}
              {activeChannel.name === 'Cellular' && <Signal className="h-4 w-4 text-[#1976D2] animate-pulse" />}
              {activeChannel.name === 'Satellite Link' && <Radio className="h-4 w-4 text-amber-500 animate-pulse animate-spin-slow" />}
              {activeChannel.name === 'None' && <ShieldAlert className="h-4 w-4 text-red-500 animate-bounce" />}
              <span className={`text-[10px] font-mono font-black uppercase tracking-wider ${
                activeChannel.name === 'None' ? 'text-red-500' : 'text-[#00E676]'
              }`}>
                {activeChannel.name === 'None' ? 'OFFLINE QUEUE' : activeChannel.name}
              </span>
            </div>
          </div>
        </div>

        {/* Tactical Sub-tabs Navigation */}
        <div className={`grid grid-cols-4 gap-1 p-1 rounded-xl ${isDark ? 'bg-[#182433]' : 'bg-zinc-100'}`}>
          {[
            { id: 'beacon', label: 'SOS Beacon' },
            { id: 'contacts', label: 'Directory' },
            { id: 'profile', label: 'Distress Profile' },
            { id: 'satcom', label: 'Satcom Link' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setEmergencyTab(tab.id as any)}
              className={`py-2 text-[10px] font-bold uppercase rounded-lg transition-all cursor-pointer text-center ${
                emergencyTab === tab.id
                  ? (isDark ? 'bg-[#00E676] text-black font-black shadow-lg' : 'bg-[#00C853] text-white shadow-md font-bold')
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 2. DYNAMIC TAB CONTAINER CONTENT */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4">

        {/* ================= SOS BEACON CONSOLE TAB ================= */}
        {emergencyTab === 'beacon' && (
          <div className="space-y-4">
            
            {/* ONE TAP TACTILE TRIGGER SLIDER */}
            {!activeSOS ? (
              <div className={`p-4 rounded-2xl border text-center space-y-3.5 ${
                isDark ? 'bg-red-950/10 border-red-900/40' : 'bg-red-50/40 border-red-100'
              }`}>
                <div className="space-y-1">
                  <div className="inline-flex p-2 bg-red-500/10 rounded-full text-red-500">
                    <ShieldAlert className="h-6 w-6 animate-pulse" />
                  </div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-red-500">ONE-TAP EMERGENCY DISPATCH</h3>
                  <p className="text-[10px] leading-relaxed text-zinc-400 max-w-xs mx-auto">
                    Requires slide confirmation to mitigate false alarms. Instantly builds tactical payload and transmits through available telemetry gateways.
                  </p>
                </div>

                {/* Confirm Slide Track */}
                <div 
                  ref={sliderTrackRef}
                  className="h-12 w-full rounded-full bg-zinc-900 border border-zinc-800/60 relative p-1 select-none overflow-hidden"
                >
                  {/* Slider Progress Fill */}
                  <div 
                    className="absolute inset-y-0 left-0 bg-red-600 rounded-full transition-all duration-75"
                    style={{ width: `calc(${sliderPosition}% + 40px)` }}
                  />

                  {/* Centered Instructions text */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <span className="text-[10px] font-mono font-black uppercase tracking-widest text-zinc-300 animate-pulse">
                      {sliderPosition > 5 ? `${Math.round(sliderPosition)}% RELEASE` : 'SLIDE RIGHT TO RESCUE'}
                    </span>
                  </div>

                  {/* Tactile Grab Thumb */}
                  <div
                    onMouseDown={handleSliderStart}
                    onTouchStart={handleSliderStart}
                    className="h-10 w-10 rounded-full bg-white text-red-600 shadow-xl flex items-center justify-center cursor-grab active:cursor-grabbing relative z-10 transition-transform"
                    style={{ transform: `translateX(${sliderPosition * 0.01 * (sliderTrackRef.current ? sliderTrackRef.current.clientWidth - 48 : 280)}px)` }}
                  >
                    <ArrowRight className="h-5 w-5 shrink-0 stroke-[2.5]" />
                  </div>
                </div>
              </div>
            ) : (
              <div className={`p-4 rounded-2xl border text-center space-y-4 relative overflow-hidden ${
                isDark ? 'bg-red-950/20 border-red-500' : 'bg-red-50 border-red-400'
              }`}>
                {/* Background radar waves */}
                <span className="animate-ping absolute left-1/2 top-8 inline-flex h-20 w-20 rounded-full bg-red-500 opacity-20 -translate-x-1/2" />

                <div className="space-y-1 relative z-10">
                  <div className="inline-flex p-3 bg-red-600 rounded-full text-white animate-bounce shadow-xl">
                    <Radio className="h-6 w-6 animate-spin-slow" />
                  </div>
                  <h3 className="text-sm font-black uppercase tracking-widest text-red-500 animate-pulse">
                    SOS BEACON BEAM ACTIVE
                  </h3>
                  <p className="text-[10px] leading-relaxed text-zinc-400">
                    Your location payload is being broadcasted on loop. Transmitters will continue firing indefinitely until manual deactivation.
                  </p>
                </div>

                {/* Signal Transmission indicators */}
                <div className="p-3 bg-black/45 rounded-xl border border-red-950 text-left space-y-2 font-mono text-[10px]">
                  <div className="flex justify-between">
                    <span className="text-zinc-500">BEACON ENGINE:</span>
                    <span className="text-emerald-400 font-bold">PEEZIGATOR-TX200</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">COORDINATES:</span>
                    <span className="text-white font-bold">{(currentGPS?.lat ?? 24.1940).toFixed(5)}°N, {(currentGPS?.lng ?? 21.7366).toFixed(5)}°E</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">GATEWAY ROUTER:</span>
                    <span className="text-amber-400 font-extrabold uppercase">{activeChannel.name}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    const activeReports = sosReports.filter(r => r.status === 'transmitting' || r.status === 'queued');
                    if (activeReports.length > 0) {
                      cancelSOSBeacon(activeReports[0].id);
                    } else {
                      setActiveSOS(false);
                    }
                  }}
                  className="w-full bg-red-600 hover:bg-red-700 text-white text-[10px] font-black py-2.5 uppercase tracking-widest rounded-xl transition-all cursor-pointer"
                >
                  ABORT ALL RESCUE TRANSMISSIONS
                </button>
              </div>
            )}

            {/* CONFIRM SLIDER END */}
            {/* OFFLINE BLE MESH SYNC QUICK ACCESSIBILITY LINK CARD */}
            <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
              isDark ? 'bg-blue-950/10 border-blue-900/30' : 'bg-blue-50/40 border-blue-100'
            }`}>
              <div className="space-y-1 text-left">
                <div className="flex items-center gap-1.5">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                  </span>
                  <h4 className="text-[10px] font-black uppercase tracking-wider text-blue-400">OFF-GRID BLE PEER SYNCHRONIZATION</h4>
                </div>
                <p className="text-[9.5px] leading-relaxed text-zinc-400">
                  No internet? Use Bluetooth Low Energy (BLE) mesh linking to automatically sync emergency waypoints and evacuation paths with nearby off-grid Peezigator users.
                </p>
              </div>
              <button 
                onClick={() => {
                  onClose();
                  if (onActivePanelChange) onActivePanelChange('sync');
                }}
                className={`px-3 py-2 rounded-xl font-mono font-black text-[9px] uppercase border tracking-wider transition-all duration-150 shrink-0 w-full sm:w-auto text-center cursor-pointer ${
                  isDark 
                    ? 'bg-blue-500/10 border-blue-500/25 text-blue-400 hover:bg-blue-500/20' 
                    : 'bg-blue-50 border-blue-250 text-blue-700 hover:bg-blue-100'
                }`}
              >
                OPEN MESH SYNC
              </button>
            </div>

            {/* DYNAMIC EMERGENCY QUEUE STATUS & TRANSMISSION FEED */}
            <div className="space-y-2 text-left">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono tracking-widest uppercase font-black text-zinc-400 flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5 text-zinc-500" /> Distress Transmission Logs
                </span>
                {sosReports.some(r => r.status === 'delivered') && (
                  <button 
                    onClick={clearHistory}
                    className="text-[9px] font-mono font-bold text-red-400 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="h-3 w-3" /> Clear Delivered
                  </button>
                )}
              </div>

              {sosReports.length === 0 ? (
                <div className="p-8 rounded-2xl text-center border border-dashed border-zinc-800 text-zinc-500">
                  <Activity className="h-8 w-8 mx-auto stroke-[1.2] mb-1.5 opacity-40" />
                  <p className="text-[10px] font-mono">No distress events logged. Transmitters standby.</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {sosReports.map(report => (
                    <div 
                      key={report.id}
                      className={`p-3 rounded-xl border flex flex-col gap-2.5 transition-all text-left font-mono text-[10px] ${
                        report.status === 'queued' 
                          ? 'bg-zinc-950/60 border-amber-600/50 shadow-amber-950/10'
                          : report.status === 'transmitting'
                            ? 'bg-red-950/20 border-red-500/50 animate-pulse'
                            : 'bg-emerald-950/10 border-emerald-900/35'
                      }`}
                    >
                      <div className="flex justify-between items-start border-b border-zinc-850/20 pb-1.5">
                        <div className="space-y-0.5">
                          <span className="font-black text-white">{report.id}</span>
                          <span className="block text-[8px] text-zinc-500">{report.timestampLocal}</span>
                        </div>
                        
                        {/* Status tag */}
                        <div className="flex items-center gap-1.5">
                          <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase ${
                            report.status === 'queued'
                              ? 'bg-amber-600/20 text-amber-500 border border-amber-600/30'
                              : report.status === 'transmitting'
                                ? 'bg-red-600 text-white font-black'
                                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}>
                            {report.status}
                          </span>
                          
                          {(report.status === 'queued' || report.status === 'transmitting') && (
                            <button
                              onClick={() => cancelSOSBeacon(report.id)}
                              className="p-1 rounded bg-zinc-900 hover:bg-zinc-850 text-red-400 border border-zinc-800"
                              title="Cancel Distress Event"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[9.5px]">
                        <div><span className="text-zinc-500">COORDS:</span> <span className="text-zinc-350">{report.latitude.toFixed(5)}°, {report.longitude.toFixed(5)}°</span></div>
                        <div><span className="text-zinc-500">ALTITUDE:</span> <span className="text-zinc-350">{report.altitude}m</span></div>
                        <div><span className="text-zinc-500">GATEWAY:</span> <span className="text-zinc-350 font-bold uppercase">{report.channelUsed}</span></div>
                        <div><span className="text-zinc-500">ATTEMPTS:</span> <span className="text-zinc-350">{report.attempts} bursts</span></div>
                      </div>

                      {/* Display live routing feedback */}
                      <div className="p-1.5 bg-black/40 rounded border border-zinc-900 text-[9px] text-zinc-400">
                        {report.status === 'queued' && (
                          <span className="text-amber-500 font-semibold">
                            ⚠️ Outbound blocked. Payload queued in local flash. Standing by for satellite orbital window or cellular handover...
                          </span>
                        )}
                        {report.status === 'transmitting' && (
                          <span className="text-red-400 animate-pulse font-semibold">
                            📡 Transmitting distress telemetry packages over SDR relay gateway. Awaiting ground station ack handshake...
                          </span>
                        )}
                        {report.status === 'delivered' && (
                          <span className="text-emerald-400 font-semibold flex items-center gap-1">
                            <CheckCircle className="h-3.5 w-3.5" /> Handshake success. Coordinates synced on SAR tactical system.
                          </span>
                        )}
                      </div>

                      {/* Action buttons on log row */}
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => copyToClipboard(formatReportText(report))}
                          className="flex-1 py-1 rounded border border-zinc-800 bg-zinc-900 text-zinc-300 font-bold hover:text-white flex items-center justify-center gap-1 text-[8.5px]"
                        >
                          <Copy className="h-3 w-3" /> COPY FULL PAYLOAD
                        </button>
                        <a
                          href={`sms:?&body=${encodeURIComponent(formatReportText(report))}`}
                          className="px-2 py-1 rounded border border-zinc-800 bg-zinc-900 text-emerald-400 font-bold hover:bg-zinc-850 flex items-center justify-center gap-1 text-[8.5px]"
                        >
                          💬 SMS DISPATCH
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================= EMERGENCY CONTACT DIRECTORY TAB ================= */}
        {emergencyTab === 'contacts' && (
          <div className="space-y-4">
            
            {/* Search and filter controls */}
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Search rescue agencies, rescue units..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-xs outline-none focus:ring-1 ${
                  isDark 
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-100 focus:ring-green-500' 
                    : 'bg-zinc-100 border-zinc-200 text-zinc-900 focus:ring-sky-600'
                }`}
              />

              <div className="flex flex-wrap gap-1">
                {['All', 'Universal', 'Mountain Rescue', 'Maritime', 'Civil Protection', 'Medical/Other', 'Emergency Embassy Numbers'].map(category => (
                  <button
                    key={category}
                    onClick={() => setFilterCategory(category)}
                    className={`px-2 py-1.5 rounded-lg text-[8px] font-bold uppercase border transition-all cursor-pointer ${
                      filterCategory === category
                        ? (isDark ? 'bg-[#00E676] text-black border-[#00E676] font-extrabold' : 'bg-[#00C853] text-white border-[#00C853] font-semibold')
                        : (isDark ? 'bg-[#182433] border-zinc-800 text-zinc-400' : 'bg-zinc-100 border-zinc-200 text-zinc-600')
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Contacts list */}
            <div className="space-y-2">
              {filteredContacts.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 font-mono text-xs">
                  No registered agencies matching criteria.
                </div>
              ) : (
                filteredContacts.map(contact => (
                  <div
                    key={contact.id}
                    className={`p-3 rounded-2xl border flex items-center justify-between gap-3 text-left ${
                      isDark ? 'bg-zinc-900/40 border-zinc-850' : 'bg-zinc-50/50 border-zinc-200'
                    }`}
                  >
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm">{contact.icon}</span>
                        <h4 className="text-xs font-bold uppercase">{contact.name}</h4>
                        <span className={`px-1.5 py-0.5 rounded-[4px] text-[7px] font-mono font-bold uppercase ${
                          contact.category === 'Universal' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                          contact.category === 'Mountain Rescue' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                          contact.category === 'Maritime' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                          contact.category === 'Civil Protection' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                          contact.category === 'Medical/Other' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' :
                          'bg-zinc-500/10 text-zinc-400 border border-zinc-500/20'
                        }`}>
                          {contact.category}
                        </span>
                      </div>
                      <p className="text-[10px] leading-relaxed text-zinc-400">{contact.description}</p>
                      <span className="text-[10px] font-mono font-bold text-emerald-500 block">NUM: {contact.number}</span>
                    </div>

                    <a
                      href={`tel:${contact.number}`}
                      className={`h-10 w-10 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border cursor-pointer ${
                        isDark 
                          ? 'bg-zinc-900 border-green-950 text-green-400 hover:bg-zinc-800' 
                          : 'bg-sky-50 border-sky-150 text-sky-700 hover:bg-sky-100'
                      }`}
                      title={`Call ${contact.name}`}
                    >
                      <Phone className="h-4.5 w-4.5 shrink-0" />
                    </a>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ================= DISTRESS PROFILE TAB ================= */}
        {emergencyTab === 'profile' && (
          <div className="space-y-4">
            
            {/* User credentials */}
            <div className="space-y-3 p-3.5 rounded-2xl border text-left bg-zinc-900/10 border-zinc-850">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase border-b border-zinc-800 pb-2 mb-2 text-zinc-400">
                <User className="h-4 w-4 text-emerald-500" /> Identity Information
              </div>
              
              <div className="space-y-1">
                <label className="text-[9px] font-mono text-zinc-400 block">Explorer Full Name</label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs outline-none ${
                    isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-zinc-50 border-zinc-200 text-zinc-900'
                  }`}
                  placeholder="e.g. Captain Jack Miller"
                />
              </div>
            </div>

            {/* Medical notes and profile parameters */}
            <div className="space-y-3 p-3.5 rounded-2xl border text-left bg-zinc-900/10 border-zinc-850">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase border-b border-zinc-800 pb-2 mb-2 text-zinc-400">
                <Heart className="h-4 w-4 text-red-500" /> Vital Medical Profile Notes
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-mono text-zinc-400 block">Survival Medical Context</label>
                <textarea
                  value={medicalNotes}
                  onChange={(e) => setMedicalNotes(e.target.value)}
                  rows={3}
                  className={`w-full px-3 py-2 rounded-xl text-xs outline-none resize-none font-mono ${
                    isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-zinc-50 border-zinc-200 text-zinc-900'
                  }`}
                  placeholder="Insert blood type, pharmaceutical allergies, preexisting heart conditions..."
                />
                <span className="text-[9px] leading-relaxed text-zinc-500 font-mono block">
                  * This data is packed directly into distress messages to facilitate custom medication setups.
                </span>
              </div>
            </div>

            {/* Editable emergency contact directory */}
            <div className="space-y-3 p-3.5 rounded-2xl border text-left bg-zinc-900/10 border-zinc-850">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-2 mb-2 text-zinc-400">
                <span className="text-xs font-bold uppercase flex items-center gap-1.5">
                  <Phone className="h-4 w-4 text-cyan-400" /> Next-of-Kin Contacts
                </span>
                
                {/* Add new contact button */}
                <button
                  onClick={() => {
                    setCustomContacts(prev => [...prev, { name: 'Emergency Contact', phone: '' }]);
                  }}
                  className="px-2 py-0.5 rounded border border-zinc-800 text-[8px] font-mono font-bold uppercase hover:bg-zinc-800"
                >
                  <Plus className="h-3 w-3 inline mr-0.5" /> ADD
                </button>
              </div>

              {customContacts.length === 0 ? (
                <p className="text-[10px] text-zinc-500 font-mono text-center">No secondary emergency numbers mapped.</p>
              ) : (
                <div className="space-y-2">
                  {customContacts.map((contact, idx) => (
                    <div key={idx} className="flex gap-1.5 items-center">
                      <input
                        type="text"
                        value={contact.name}
                        onChange={(e) => {
                          const updated = [...customContacts];
                          updated[idx].name = e.target.value;
                          setCustomContacts(updated);
                        }}
                        className={`flex-1 px-2 py-1.5 rounded-lg text-[10.5px] font-bold ${
                          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-zinc-50 border-zinc-200 text-zinc-900'
                        }`}
                        placeholder="Contact Name"
                      />
                      <input
                        type="text"
                        value={contact.phone}
                        onChange={(e) => {
                          const updated = [...customContacts];
                          updated[idx].phone = e.target.value;
                          setCustomContacts(updated);
                        }}
                        className={`flex-1 px-2 py-1.5 rounded-lg text-[10.5px] font-mono ${
                          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-zinc-50 border-zinc-200 text-zinc-900'
                        }`}
                        placeholder="Cell number / SAT call"
                      />
                      
                      <button
                        onClick={() => {
                          setCustomContacts(prev => prev.filter((_, i) => i !== idx));
                        }}
                        className="p-1.5 rounded-lg bg-zinc-900 border border-zinc-850 hover:bg-zinc-850 text-red-400 cursor-pointer"
                        title="Remove Contact"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================= SATCOM LINK DETAILS TAB ================= */}
        {emergencyTab === 'satcom' && (
          <div className="space-y-4">
            
            {/* Satcom active status block */}
            <div className={`p-4 rounded-2xl border text-left space-y-3 ${
              isDark ? 'bg-zinc-900/20 border-zinc-850' : 'bg-zinc-50 border-zinc-200'
            }`}>
              <div className="flex justify-between items-center">
                <span className="text-xs font-black uppercase tracking-wider text-zinc-400">SATCOM LINK STATUS</span>
                <span className={`h-2 w-2 rounded-full ${satAvailable ? 'bg-emerald-500' : 'bg-red-500'} animate-pulse`}></span>
              </div>

              {/* orbital passes simulated stats */}
              <div className="grid grid-cols-2 gap-3 font-mono text-[10px]">
                <div className="p-2.5 rounded-xl bg-black/30 border border-zinc-900">
                  <span className="text-zinc-500 uppercase text-[8px] block">ACTIVE CONSTELLATION</span>
                  <span className="text-white font-bold block">Iridium / SARSAT</span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/30 border border-zinc-900">
                  <span className="text-zinc-500 uppercase text-[8px] block">ORBITAL PASSES</span>
                  <span className="text-white font-bold block">3 Sats Visible</span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/30 border border-zinc-900">
                  <span className="text-zinc-500 uppercase text-[8px] block">UPLINK FREQUENCY</span>
                  <span className="text-white font-bold block">1616.0 MHz (S-Band)</span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/30 border border-zinc-900">
                  <span className="text-zinc-500 uppercase text-[8px] block">LAST HANDSHAKE</span>
                  <span className="text-white font-bold block">14 mins ago</span>
                </div>
              </div>
            </div>

            {/* Simulators for communication availability */}
            <div className={`p-3.5 rounded-2xl border text-left space-y-3 bg-zinc-900/10 border-zinc-850`}>
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase border-b border-zinc-800 pb-2 mb-2 text-zinc-400">
                <Settings className="h-4 w-4 text-cyan-400" /> Channel Simulation Control Panel
              </div>
              <p className="text-[9.5px] leading-relaxed text-zinc-400">
                Simulate off-grid environments by toggling specific carrier states. The Emergency Engine dynamically computes priority.
              </p>

              <div className="space-y-2.5">
                {/* Wi-Fi toggle */}
                <div className="flex items-center justify-between">
                  <div className="text-left font-mono text-[10px]">
                    <span className="block font-bold">1. Wi-Fi Connection</span>
                    <span className="text-[8px] text-zinc-500">Router, base camps, village internet</span>
                  </div>
                  <button
                    onClick={() => setWifiAvailable(!wifiAvailable)}
                    className={`px-3 py-1 rounded-lg text-[9px] font-mono font-bold uppercase transition-all ${
                      wifiAvailable ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                    }`}
                  >
                    {wifiAvailable ? 'CONNECTED' : 'DISCONNECTED'}
                  </button>
                </div>

                {/* Cellular carrier toggle */}
                <div className="flex items-center justify-between">
                  <div className="text-left font-mono text-[10px]">
                    <span className="block font-bold">2. Cellular Coverage</span>
                    <span className="text-[8px] text-zinc-500">GSM/LTE carrier network</span>
                  </div>
                  <div className="flex gap-1">
                    {['none', 'low', 'high'].map(strength => (
                      <button
                        key={strength}
                        onClick={() => {
                          if (strength === 'none') {
                            setCellularAvailable(false);
                            setCellularSignalStrength('none');
                          } else {
                            setCellularAvailable(true);
                            setCellularSignalStrength(strength as any);
                          }
                        }}
                        className={`px-2 py-1 rounded text-[8px] font-mono uppercase font-bold border ${
                          (strength === 'none' && !cellularAvailable) || (strength !== 'none' && cellularAvailable && cellularSignalStrength === strength)
                            ? 'bg-cyan-500 text-black border-cyan-500'
                            : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                        }`}
                      >
                        {strength}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Satellite availability toggle */}
                <div className="flex items-center justify-between">
                  <div className="text-left font-mono text-[10px]">
                    <span className="block font-bold">3. Satellite Receiver</span>
                    <span className="text-[8px] text-zinc-500">Global COSPAS/SDR radio hardware</span>
                  </div>
                  <button
                    onClick={() => setSatAvailable(!satAvailable)}
                    className={`px-3 py-1 rounded-lg text-[9px] font-mono font-bold uppercase transition-all ${
                      satAvailable ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                    }`}
                  >
                    {satAvailable ? 'ACTIVE' : 'INACTIVE'}
                  </button>
                </div>
              </div>
            </div>

            {/* Paired external satellite hardware */}
            <div className={`p-3.5 rounded-2xl border text-left space-y-3 bg-zinc-900/10 border-zinc-850`}>
              <div className="text-xs font-bold uppercase border-b border-zinc-800 pb-2 mb-2 text-zinc-400">
                Paired Bluetooth Satellite Communicators
              </div>

              <div className="space-y-2">
                {pairedDevices.map(device => (
                  <div 
                    key={device.id}
                    className={`p-2.5 rounded-xl border flex items-center justify-between text-left ${
                      device.connected 
                        ? 'border-emerald-500 bg-emerald-950/10' 
                        : 'border-zinc-850 bg-zinc-900/20'
                    }`}
                  >
                    <div>
                      <span className="text-[10px] font-bold block">{device.name}</span>
                      <span className="text-[8px] text-zinc-500 font-mono block">{device.type} (Battery: {device.battery}%)</span>
                    </div>

                    <button
                      onClick={() => {
                        setPairedDevices(prev => prev.map(d => {
                          if (d.id === device.id) {
                            return { ...d, connected: !d.connected };
                          }
                          return d;
                        }));
                        addToast(`${device.name} connection toggled.`);
                      }}
                      className={`px-2.5 py-1 rounded text-[8.5px] font-mono font-bold uppercase ${
                        device.connected 
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                          : 'bg-zinc-850 border border-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {device.connected ? 'DISCONNECT' : 'PAIR DEVICE'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 3. COMS ENGINE FOOTER WARNING */}
      <div className={`p-3 border-t text-[9px] font-mono leading-relaxed text-center opacity-60 ${
        isDark ? 'bg-zinc-950 border-zinc-900' : 'bg-zinc-50 border-zinc-200'
      }`}>
        PEEZIGATOR OFFGRID BEACON MODULE v1.8 • AUTOMATIC GATEWAY SELECTION ENABLED • SECURE STORE & FORWARD IN PROGRESS
      </div>
    </div>
  );
}
