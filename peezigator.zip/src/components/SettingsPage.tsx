/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppSettings } from '../types';
import { Settings, Shield, Bell, Moon, Sun, ToggleLeft, CloudOff, Info, Compass, Volume2, VolumeX } from 'lucide-react';

interface SettingsPageProps {
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
  voiceLanguage?: string;
  onSetVoiceLanguage?: (lang: string) => void;
  voiceVolume?: number;
  onSetVoiceVolume?: (volume: number) => void;
  voiceMuted?: boolean;
  onSetVoiceMuted?: (muted: boolean) => void;
  onActivePanelChange?: (panel: string) => void;
}

const LANGUAGES = [
  { code: 'en-US', label: 'English (US)' },
  { code: 'es-ES', label: 'Español' },
  { code: 'fr-FR', label: 'Français' },
  { code: 'de-DE', label: 'Deutsch' },
];

export default function SettingsPage({
  settings,
  onUpdateSettings,
  voiceLanguage = 'en-US',
  onSetVoiceLanguage,
  voiceVolume = 0.85,
  onSetVoiceVolume,
  voiceMuted = false,
  onSetVoiceMuted,
  onActivePanelChange,
}: SettingsPageProps) {
  const isDark = settings.theme === 'dark';

  const toggleTheme = () => {
    onUpdateSettings({
      ...settings,
      theme: isDark ? 'light' : 'dark',
    });
  };

  const toggleGPS = () => {
    onUpdateSettings({
      ...settings,
      gpsHighAccuracy: !settings.gpsHighAccuracy,
    });
  };

  const toggleUnit = (unit: 'km' | 'miles') => {
    onUpdateSettings({
      ...settings,
      distanceUnit: unit,
    });
  };

  const toggleNotifications = () => {
    onUpdateSettings({
      ...settings,
      notificationsEnabled: !settings.notificationsEnabled,
    });
  };

  const toggleOfflineMode = () => {
    onUpdateSettings({
      ...settings,
      offlineModeActive: !settings.offlineModeActive,
    });
  };

  const containerBg = isDark ? 'bg-[#08131F] text-white' : 'bg-zinc-50 text-zinc-900';
  const blockBorderClass = isDark ? 'border-zinc-800/80 bg-[#182433]' : 'border-zinc-200 bg-white';
  const cardTitleColor = isDark ? 'text-[#00E676]' : 'text-[#00C853]';

  return (
    <div className={`p-4 space-y-6 overflow-y-auto h-full flex flex-col justify-start ${containerBg}`}>
      
      {/* Title */}
      <div>
        <h3 className="text-sm font-sans font-extrabold uppercase tracking-widest text-[#00E676]">
          SYSTEM PREFERENCES
        </h3>
        <p className="text-[10px] text-gray-500 mt-1 uppercase font-mono">PEEZIGATOR CONSOLE V1.0.5</p>
      </div>

      {/* QUICK DISTANCE MEASUREMENT TOGGLE */}
      <div className={`p-5 rounded-2xl border ${blockBorderClass} space-y-4 shadow-md border-l-4 ${isDark ? 'border-l-[#00E676]' : 'border-l-[#00C853]'}`}>
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <h4 className="text-sm font-black tracking-wide flex items-center gap-2">
              <Compass className={`h-4.5 w-4.5 ${isDark ? 'text-[#00E676]' : 'text-[#00C853]'}`} />
              QUICK DISTANCE MEASUREMENT
            </h4>
            <span className="block text-xs text-zinc-400 leading-normal">
              Switch the global distance unit on the fly. All telemetry meters, active trail planners, waypoints, navigation directions, and the dynamic dashboard will recalculate instantly.
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
          <button
            onClick={() => toggleUnit('km')}
            className={`p-3 rounded-xl border transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
              settings.distanceUnit === 'km'
                ? (isDark ? 'bg-[#00E676]/10 border-[#00E676] text-[#00E676] font-bold' : 'bg-[#00C853]/10 border-[#00C853] text-[#00C853] font-bold')
                : (isDark ? 'border-zinc-850 bg-zinc-900/10 text-gray-400' : 'border-zinc-200 bg-white text-gray-500')
            }`}
          >
            <span className="text-[14px]">Metric (km)</span>
            <span className="text-[9px] uppercase tracking-wider font-mono opacity-60">Kilometers</span>
          </button>
          
          <button
            onClick={() => toggleUnit('miles')}
            className={`p-3 rounded-xl border transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
              settings.distanceUnit === 'miles'
                ? (isDark ? 'bg-[#00E676]/10 border-[#00E676] text-[#00E676] font-bold' : 'bg-[#00C853]/10 border-[#00C853] text-[#00C853] font-bold')
                : (isDark ? 'border-zinc-850 bg-zinc-900/10 text-gray-400' : 'border-zinc-200 bg-white text-gray-500')
            }`}
          >
            <span className="text-[14px]">Imperial (mi)</span>
            <span className="text-[9px] uppercase tracking-wider font-mono opacity-60">Miles</span>
          </button>
        </div>
      </div>

      {/* Offline Mode Switcher */}
      <div className={`p-5 rounded-2xl border ${blockBorderClass} flex items-center justify-between shadow-md`}>
        <div className="space-y-1 pr-4">
          <h4 className="text-sm font-bold flex items-center gap-2">
            <CloudOff className="h-4 w-4 text-amber-500" />
            SIMULATE HARD OFFLINE STATE
          </h4>
          <span className="block text-xs text-zinc-400 leading-normal">
            Turn on to simulate deep wilderness with absolute zero internet. Non-cached map boxes will show coordinate grids only.
          </span>
        </div>
        <button
          onClick={toggleOfflineMode}
          className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
            settings.offlineModeActive ? 'bg-amber-600' : 'bg-gray-700'
          }`}
        >
          <span
            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
              settings.offlineModeActive ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* Light / Dark Mode Toggle selection */}
      <div className={`p-5 rounded-2xl border ${blockBorderClass} space-y-3 shadow-md`}>
        <h4 className="text-sm font-bold flex items-center gap-2">
          {isDark ? <Moon className="h-4 w-4 text-green-400" /> : <Sun className="h-4 w-4 text-amber-500" />}
          DISPLAY SCHEME
        </h4>
        
        <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
          <button
            onClick={() => onUpdateSettings({ ...settings, theme: 'light' })}
            className={`p-3 rounded-xl border transition-all flex items-center justify-center gap-2 cursor-pointer ${
              !isDark
                ? 'bg-sky-50 border-sky-400 text-sky-800 font-bold'
                : 'border-gray-800 hover:bg-zinc-800/20 text-gray-400'
            }`}
          >
            <Sun className="h-4 w-4" /> LIGHT MODE (Sea Blue)
          </button>
          
          <button
            onClick={() => onUpdateSettings({ ...settings, theme: 'dark' })}
            className={`p-3 rounded-xl border transition-all flex items-center justify-center gap-2 cursor-pointer ${
              isDark
                ? 'bg-green-950/40 border-green-500 text-green-300 font-bold'
                : 'border-gray-200 hover:bg-gray-50 text-gray-400'
            }`}
          >
            <Moon className="h-4 w-4" /> DARK MODE (Night Vision)
          </button>
        </div>
      </div>

      {/* GPS Settings config */}
      <div className={`p-5 rounded-2xl border ${blockBorderClass} space-y-3.5 shadow-md`}>
        <h4 className="text-sm font-bold flex items-center gap-2">
          <Settings className="h-4 w-4" /> GPS & TELEMETRY PREFERENCES
        </h4>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="block text-xs font-bold uppercase tracking-wider">High Accuracy Satellites</span>
              <span className="block text-[11px] text-gray-400 leading-normal">
                Uses differential GNSS + Glonass arrays. Multiplies battery consumption in remote domains.
              </span>
            </div>
            <button
              onClick={toggleGPS}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                settings.gpsHighAccuracy ? (isDark ? 'bg-green-500' : 'bg-sky-600') : 'bg-gray-700'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.gpsHighAccuracy ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <hr className="border-gray-700/10" />

          {/* Tactical Power Saver Mode */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5 pr-4">
              <span className="block text-xs font-bold uppercase tracking-wider">Tactical Power Saver</span>
              <span className="block text-[11px] text-gray-400 leading-normal">
                Throttles background GPS/Compass telemetry ping intervals. Triples off-grid device battery endurance.
              </span>
            </div>
            <button
              onClick={() => onUpdateSettings({ ...settings, powerSaverMode: !settings.powerSaverMode })}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                settings.powerSaverMode ? (isDark ? 'bg-green-500' : 'bg-sky-600') : 'bg-gray-700'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.powerSaverMode ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <hr className="border-gray-700/10" />

          {/* Unit selection */}
          <div className="flex items-center justify-between">
            <div>
              <span className="block text-xs font-bold uppercase tracking-wider">Distance Units</span>
              <span className="block text-[11px] text-gray-400">Preferred units for mapping scales and routes.</span>
            </div>

            <div className="inline-flex rounded-lg border border-gray-700/20 overflow-hidden bg-black/15 text-xs">
              <button
                onClick={() => toggleUnit('km')}
                className={`px-3 py-1.5 transition-all text-[11px] font-bold cursor-pointer ${
                  settings.distanceUnit === 'km'
                    ? (isDark ? 'bg-green-500 text-black' : 'bg-[#006ca5] text-white')
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                METRIC (KM)
              </button>
              <button
                onClick={() => toggleUnit('miles')}
                className={`px-3 py-1.5 transition-all text-[11px] font-bold cursor-pointer ${
                  settings.distanceUnit === 'miles'
                    ? (isDark ? 'bg-green-500 text-black' : 'bg-[#006ca5] text-white')
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                IMPERIAL (MI)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Notifications Preferences */}
      <div className={`p-5 rounded-2xl border ${blockBorderClass} flex items-center justify-between shadow-md`}>
        <div className="space-y-0.5 pr-4">
          <h4 className="text-sm font-bold flex items-center gap-2">
            <Bell className="h-4 w-4" /> ALERTS & COLLISION WARNINGS
          </h4>
          <span className="block text-[11px] text-gray-400 leading-normal">
            Notify me of severe terrain grade changes, heading misalignment, and battery warnings.
          </span>
        </div>
        <button
          onClick={toggleNotifications}
          className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
            settings.notificationsEnabled ? (isDark ? 'bg-green-500' : 'bg-sky-600') : 'bg-gray-700'
          }`}
        >
          <span
            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
              settings.notificationsEnabled ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* Voice Navigation Guidance Preferences */}
      <div className={`p-5 rounded-2xl border ${blockBorderClass} space-y-4 shadow-md`}>
        <h4 className="text-sm font-bold flex items-center gap-2">
          {voiceMuted ? <VolumeX className="h-4 w-4 text-red-500" /> : <Volume2 className="h-4 w-4 text-emerald-500 animate-pulse" />}
          VOICE GUIDANCE & SYNTH VOICE
        </h4>

        <div className="flex items-center justify-between">
          <div>
            <span className="block text-xs font-bold uppercase tracking-wider">Mute Voice Instructions</span>
            <span className="block text-[11px] text-gray-400">Silences the automatic text-to-speech routing announcements.</span>
          </div>
          <button
            onClick={() => onSetVoiceMuted?.(!voiceMuted)}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              voiceMuted ? 'bg-[#EF4444]' : (isDark ? 'bg-[#00E676]' : 'bg-[#00C853]')
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                !voiceMuted ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        <hr className="border-gray-700/10" />

        <div className="flex flex-col gap-3 font-mono text-xs">
          <div className="flex items-center justify-between">
            <span className="font-sans text-xs">Voice Language Selection:</span>
            <select
              value={voiceLanguage}
              onChange={(e) => onSetVoiceLanguage?.(e.target.value)}
              className={`border rounded p-1.5 outline-none font-bold text-[11px] cursor-pointer ${
                isDark ? 'bg-zinc-950 border-zinc-800 text-white' : 'bg-white border-gray-200 text-gray-800'
              }`}
            >
              {LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.label}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between gap-4">
            <span className="font-sans text-xs whitespace-nowrap">Voice Volume:</span>
            <input 
              type="range"
              min="0.1"
              max="1.0"
              step="0.1"
              value={voiceVolume}
              onChange={(e) => onSetVoiceVolume?.(parseFloat(e.target.value))}
              disabled={voiceMuted}
              className="flex-1 max-w-sm accent-emerald-500"
            />
            <span className="font-bold min-w-8 text-right">{Math.round(voiceVolume * 100)}%</span>
          </div>
        </div>
      </div>

      {/* Security and Privacy */}
      <div className={`p-5 rounded-2xl border ${blockBorderClass} space-y-3 shadow-md`}>
        <h4 className="text-sm font-bold flex items-center gap-2 text-white">
          <Shield className="h-4 w-4 text-[#00E676]" /> OFFLINE DATA PRIVACY
        </h4>
        <p className="text-[11px] text-zinc-400 leading-relaxed">
          Peezigator is strictly <strong>local-first</strong>. All route coordinates, waypoint locations, downloaded map frames, and private notes are kept safely in secure device storage. Telemetry is never aggregated to surveillance networks.
        </p>
      </div>

      {/* EXPEDITION PIN & EXPLORER PROFILE MANAGEMENT */}
      <div className={`p-5 rounded-2xl border ${blockBorderClass} space-y-4 shadow-md`}>
        <h4 className="text-sm font-sans font-extrabold uppercase tracking-widest text-[#00E676] flex items-center gap-2">
          <Compass className="h-4 w-4 text-[#00E676]" /> EXPEDITION PORTAL
        </h4>
        <span className="block text-xs text-zinc-400 leading-normal">
          Access your recorded off-grid coordinates, custom pinpoints, and tactical explorer identity profile.
        </span>

        <div className="grid grid-cols-2 gap-2.5 text-xs font-semibold">
          <button
            onClick={() => onActivePanelChange?.('waypoints')}
            className={`p-3.5 rounded-xl border transition-all flex flex-col items-center justify-center gap-2 cursor-pointer bg-zinc-950/40 hover:bg-zinc-900 ${
              isDark ? 'border-zinc-800 text-zinc-200 hover:text-white' : 'border-zinc-200 text-zinc-750'
            }`}
          >
            <span className="text-xl">📍</span>
            <span className="text-[10px] uppercase font-sans font-bold tracking-wider">Waypoint Pins</span>
          </button>
          
          <button
            onClick={() => onActivePanelChange?.('profile')}
            className={`p-3.5 rounded-xl border transition-all flex flex-col items-center justify-center gap-2 cursor-pointer bg-zinc-950/40 hover:bg-zinc-900 ${
              isDark ? 'border-zinc-800 text-zinc-200 hover:text-white' : 'border-zinc-200 text-zinc-750'
            }`}
          >
            <span className="text-xl">🥾</span>
            <span className="text-[10px] uppercase font-sans font-bold tracking-wider">Explorer Profile</span>
          </button>
        </div>
      </div>

      {/* Safety warning */}
      <div className="p-4 bg-amber-500/10 border border-amber-500/25 rounded-2xl text-[11px] font-mono leading-relaxed text-amber-500/90 flex items-start gap-2">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <div>
          <span>⚠️ <strong>PEEZIGATOR WILDERNESS CONSOLE DISCLAIMER:</strong></span>
          <p className="mt-1">
            Do not rely solely on digital mapping during extreme off-grid expeditions. Ensure you maintain backup analog topographical print charts and magnetic compass gear at all times.
          </p>
        </div>
      </div>

    </div>
  );
}
