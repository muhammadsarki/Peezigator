/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { 
  Compass, ZoomIn, ZoomOut, Navigation, Crosshair, MapPin, Eye, Lock, 
  Volume2, VolumeX, Globe, Play, Square, Circle, ChevronRight, Activity, 
  Trash, Save, ArrowRight, ShieldAlert, Check, Search, Map as MapIcon,
  Sun, Cloud, CloudRain, Wind, Thermometer, Info, Pin, Share2, CloudOff, Download,
  X, Radio, Layers, Plus, Target
} from 'lucide-react';
import { OfflineMap, Waypoint, Route, AppSettings, NavigationMode } from '../types';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import DeviceCompass from './Compass';
import ScaleBar from './ScaleBar';

// Haversine Distance helper
const getHaversineDistance = (p1: [number, number], p2: [number, number]) => {
  const rad = Math.PI / 180;
  const R = 6371; // Earth's radius in km
  const dLat = (p2[0] - p1[0]) * rad;
  const dLng = (p2[1] - p1[1]) * rad;
  const val = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(p1[0] * rad) * Math.cos(p2[0] * rad) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(val), Math.sqrt(1 - val));
  return R * c;
};

// Traditional topographic military map scales from Zoom level
const getTraditionalScale = (zoom: number) => {
  const scales: { [key: number]: string } = {
    19: '1:500',
    18: '1:1,000',
    17: '1:2,500',
    16: '1:5,000',
    15: '1:10,000',
    14: '1:24,000',
    13: '1:50,000',
    12: '1:100,000',
    11: '1:250,000',
    10: '1:500,000',
    9: '1:1,000,000',
    8: '1:2,500,000',
    7: '1:5,000,000',
    6: '1:10,000,000',
    5: '1:25,000,000',
  };
  return scales[zoom] || `1:${Math.round(40000000 / Math.pow(2, zoom)).toLocaleString()}`;
};

interface InteractiveMapProps {
  offlineMaps: OfflineMap[];
  waypoints: Waypoint[];
  routes: Route[];
  selectedRoute: Route | null;
  selectedWaypoint: Waypoint | null;
  onSelectWaypoint: (wp: Waypoint | null) => void;
  onMapClickToAddWaypoint: (x: number, y: number, lat: number, lng: number) => void;
  settings: AppSettings;
  currentGPS: { x: number; y: number; lat: number; lng: number; heading: number };
  onUpdateGPS: (gps: { x: number; y: number; lat: number; lng: number; heading: number }) => void;
  // Route builder hooks
  routeBuilderActive: boolean;
  routeBuilderPoints: { x: number; y: number }[];
  onAddRouteBuilderPoint: (pt: { x: number; y: number }) => void;
  onToggleRouteBuilder: (active: boolean) => void;
  onClearRouteBuilderPoints: () => void;
  // Navigation controls
  navigationActive: boolean;
  onToggleNavigation: (active: boolean) => void;
  voiceMuted: boolean;
  onSetVoiceMuted: (muted: boolean) => void;
  voiceVolume: number;
  onSetVoiceVolume: (volume: number) => void;
  voiceLanguage: string;
  onSetVoiceLanguage: (lang: string) => void;
  onActivePanelChange?: (panel: string) => void;
  onUpdateSettings?: (settings: AppSettings) => void;
  activePanel: string;
}

const getMapStyle = (type: string, theme: string): maplibregl.StyleSpecification | string => {
  switch (type) {
    case 'satellite':
      return {
        version: 8,
        sources: {
          'satellite-tiles': {
            type: 'raster',
            tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'],
            tileSize: 256
          },
          'vector-overlay': {
            type: 'vector',
            tiles: ['https://demotiles.maplibre.org/tiles/{z}/{x}/{y}.pbf'],
            maxzoom: 14
          }
        },
        layers: [
          {
            id: 'satellite-layer',
            type: 'raster',
            source: 'satellite-tiles',
            minzoom: 0,
            maxzoom: 22
          },
          {
            id: 'vector-roads',
            type: 'line',
            source: 'vector-overlay',
            'source-layer': 'transportation',
            paint: {
              'line-color': '#ffffff',
              'line-width': 1.5,
              'line-opacity': 0.7
            }
          }
        ]
      };
    case 'hybrid':
      return {
        version: 8,
        sources: {
          'satellite-tiles': {
            type: 'raster',
            tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'],
            tileSize: 256
          },
          'overlay-boundaries': {
            type: 'raster',
            tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}'],
            tileSize: 256
          },
          'overlay-roads': {
            type: 'raster',
            tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}'],
            tileSize: 256
          }
        },
        layers: [
          {
            id: 'satellite-layer',
            type: 'raster',
            source: 'satellite-tiles',
            minzoom: 0,
            maxzoom: 22
          },
          {
            id: 'boundaries-layer',
            type: 'raster',
            source: 'overlay-boundaries',
            minzoom: 0,
            maxzoom: 22,
            paint: { 'raster-opacity': 0.85 }
          },
          {
            id: 'roads-layer',
            type: 'raster',
            source: 'overlay-roads',
            minzoom: 0,
            maxzoom: 22,
            paint: { 'raster-opacity': 0.85 }
          }
        ]
      };
    case 'terrain':
      return {
        version: 8,
        sources: {
          'terrain-tiles': {
            type: 'raster',
            tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'],
            tileSize: 256
          },
          'terrain-dem': {
            type: 'raster-dem',
            tiles: ['https://demotiles.maplibre.org/terrain-tiles/{z}/{x}/{y}.png'],
            tileSize: 256,
            maxzoom: 12
          },
          'vector-overlay': {
            type: 'vector',
            tiles: ['https://demotiles.maplibre.org/tiles/{z}/{x}/{y}.pbf'],
            maxzoom: 14
          }
        },
        layers: [
          {
            id: 'terrain-layer',
            type: 'raster',
            source: 'terrain-tiles',
            minzoom: 0,
            maxzoom: 22
          },
          {
            id: 'hillshade-layer',
            type: 'hillshade',
            source: 'terrain-dem',
            paint: {
              'hillshade-shadow-color': '#1e293b',
              'hillshade-illumination-direction': 315,
              'hillshade-exaggeration': 0.85
            }
          },
          {
            id: 'vector-roads',
            type: 'line',
            source: 'vector-overlay',
            'source-layer': 'transportation',
            paint: {
              'line-color': '#475569',
              'line-width': 1.2,
              'line-opacity': 0.5
            }
          }
        ],
        terrain: {
          source: 'terrain-dem',
          exaggeration: 1.5
        }
      };
    case 'dark':
      return 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json';
    case 'light':
      return 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json';
    case 'standard':
    default:
      return theme === 'dark'
        ? 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json'
        : 'https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json';
  }
};

const LANGUAGES = [
  { code: 'en-US', label: 'English (US)' },
  { code: 'es-ES', label: 'Español' },
  { code: 'fr-FR', label: 'Français' },
  { code: 'de-DE', label: 'Deutsch' },
];

export default function InteractiveMap({
  offlineMaps,
  waypoints,
  routes,
  selectedRoute,
  selectedWaypoint,
  onSelectWaypoint,
  onMapClickToAddWaypoint,
  settings,
  currentGPS,
  onUpdateGPS,
  routeBuilderActive,
  routeBuilderPoints,
  onAddRouteBuilderPoint,
  onToggleRouteBuilder,
  onClearRouteBuilderPoints,
  navigationActive,
  onToggleNavigation,
  voiceMuted,
  onSetVoiceMuted,
  voiceVolume,
  onSetVoiceVolume,
  voiceLanguage,
  onSetVoiceLanguage,
  onActivePanelChange,
  onUpdateSettings,
  activePanel,
}: InteractiveMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const [mapInstance, setMapInstance] = useState<maplibregl.Map | null>(null);

  // Map Tile layer types
  const [mapType, setMapType] = useState<'standard' | 'satellite' | 'hybrid' | 'terrain' | 'dark' | 'light'>('standard');
  const [layersOpen, setLayersOpen] = useState<boolean>(false);
  const [mapZoom, setMapZoom] = useState<number>(13);
  const [followUser, setFollowUser] = useState<boolean>(true);
  const [mapRotation, setMapRotation] = useState<number>(0);
  const [mapTilt, setMapTilt] = useState<number>(0);
  const [autoRotate, setAutoRotate] = useState<boolean>(false);
  const [isCompassSynced, setIsCompassSynced] = useState<boolean>(false);
  const [compassHeading, setCompassHeading] = useState<number>(0);
  const [isRealGps, setIsRealGps] = useState<boolean>(false);

  // Search Address input state
  const [searchInput, setSearchInput] = useState<string>('');
  const [searchResults, setSearchResults] = useState<{lat: number; lng: number; name: string}[]>([]);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  // Custom Tap Destination Dropped Pin details
  const [droppedPin, setDroppedPin] = useState<{ lat: number; lng: number; name: string } | null>(null);
  const [calculatedRoute, setCalculatedRoute] = useState<[number, number][]>([]);
  const [routeStats, setRouteStats] = useState<{ distance: number; duration: string; eta: string } | null>(null);

  // Live Position simulated variables
  const [gpsSourceState, setGpsSourceState] = useState<'real' | 'simulated'>('real');
  const [currentSpeed, setCurrentSpeed] = useState<number>(0); // in km/h
  const [currentAltitude, setCurrentAltitude] = useState<number>(342); // in m
  const [currentAccuracy, setCurrentAccuracy] = useState<number>(1.4); // in m

  // Live real GPS tracking details
  const [gpsLoading, setGpsLoading] = useState<boolean>(true);
  const [permissionDenied, setPermissionDenied] = useState<boolean>(false);
  const [gpsDisabled, setGpsDisabled] = useState<boolean>(false);
  const [geocodedAddress, setGeocodedAddress] = useState<{ city: string; state: string; country: string } | null>(null);

  // Active Placement or Interactive values
  const [isPlacingWaypoint, setIsPlacingWaypoint] = useState<boolean>(false);

  // Navigation Turn-by-Turn directives
  const [navStepIndex, setNavStepIndex] = useState<number>(0);
  const [navInstructions, setNavInstructions] = useState<string[]>([]);
  const [navNextInstruction, setNavNextInstruction] = useState<string>('Proceed to starting coordinates.');
  const [navDistanceRemaining, setNavDistanceRemaining] = useState<number>(0);
  const [navTimeRemaining, setNavTimeRemaining] = useState<string>('0m');
  const [navEta, setNavEta] = useState<string>('--:--');

  // Collapsible Telemetry Panel (hidden by default to prevent map clutter)
  const [telemetryExpanded, setTelemetryExpanded] = useState<boolean>(false);
  const [quickActionsOpen, setQuickActionsOpen] = useState<boolean>(false);
  const [isBottomSheetExpanded, setIsBottomSheetExpanded] = useState<boolean>(false);
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState<boolean>(false);

  // Real-time distance scale bar
  const [scaleData, setScaleData] = useState<{ width: number; label: string } | null>(null);
  const updateScaleRef = useRef<() => void>(() => {});

  const updateScale = () => {
    const map = mapRef.current;
    if (!map) return;

    // Target a maximum pixel width for our scale bar, e.g., 100px
    const maxPx = 100;
    const container = map.getContainer();
    const width = container.clientWidth || 400;
    const height = container.clientHeight || 400;

    const y = height / 2;
    const x = width / 2;

    const latLng1 = map.unproject([x, y]);
    const latLng2 = map.unproject([x + maxPx, y]);
    const distanceInKm = getHaversineDistance([latLng1.lat, latLng1.lng], [latLng2.lat, latLng2.lng]);
    const distanceInMeters = distanceInKm * 1000;

    if (!distanceInMeters || isNaN(distanceInMeters)) return;

    let chosenDistance = 0;
    let label = '';
    let scaleWidth = 0;

    if (settings.distanceUnit === 'miles') {
      const distanceInMiles = distanceInMeters / 1609.344;
      if (distanceInMiles < 0.1) {
        const distanceInFeet = distanceInMeters * 3.28084;
        const niceFeet = [10, 20, 50, 100, 200, 500];
        let feet = niceFeet[0];
        for (const f of niceFeet) {
          if (distanceInFeet >= f) {
            feet = f;
          }
        }
        chosenDistance = feet / 3.28084;
        label = `${feet} ft`;
      } else {
        const niceMiles = [0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000];
        let miles = niceMiles[0];
        for (const m of niceMiles) {
          if (distanceInMiles >= m) {
            miles = m;
          }
        }
        chosenDistance = miles * 1609.344;
        label = `${miles} mi`;
      }
    } else {
      if (distanceInMeters < 1000) {
        const niceMeters = [1, 2, 5, 10, 20, 50, 100, 200, 500];
        let meters = niceMeters[0];
        for (const m of niceMeters) {
          if (distanceInMeters >= m) {
            meters = m;
          }
        }
        chosenDistance = meters;
        label = `${meters} m`;
      } else {
        const distanceInKm = distanceInMeters / 1000;
        const niceKm = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000];
        let km = niceKm[0];
        for (const k of niceKm) {
          if (distanceInKm >= k) {
            km = k;
          }
        }
        chosenDistance = km * 1000;
        label = `${km} km`;
      }
    }

    scaleWidth = (chosenDistance / distanceInMeters) * maxPx;
    setScaleData({
      width: Math.round(scaleWidth),
      label
    });
  };

  // Keep ref updated to avoid stale closures in Leaflet events
  useEffect(() => {
    updateScaleRef.current = updateScale;
  });

  // Trigger scale update on unit change or when map finishes rendering
  useEffect(() => {
    updateScale();
  }, [settings.distanceUnit]);

  // Trigger Leaflet map container layout adjustment when activePanel switches
  useEffect(() => {
    const map = mapRef.current;
    if (map) {
      setTimeout(() => {
        map.resize();
        updateScale();
      }, 300); // Wait for CSS transition timing
    }
  }, [activePanel]);

  // Convert canvas x/y (0-100) to latitude/longitude and vice versa
  const baseLat = 24.0000;
  const baseLng = 21.5000;
  const latConversion = 0.01;
  const lngConversion = 0.013;

  const canvasToCoords = (x: number, y: number) => {
    return {
      lat: baseLat + y * latConversion,
      lng: baseLng + x * lngConversion,
    };
  };

  const coordsToCanvas = (lat: number, lng: number) => {
    return {
      x: (lng - baseLng) / lngConversion,
      y: (lat - baseLat) / latConversion,
    };
  };

  // HTML5 Sound Synth Voice Guidances
  const speakInstruction = (text: string) => {
    if (voiceMuted || typeof window === 'undefined' || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = voiceLanguage;
      utterance.volume = voiceVolume;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("Speech Synthesis Voice failed to trigger: ", e);
    }
  };

  // 1. WATCH POSITION REAL GPS TRIGGER
  useEffect(() => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      setGpsDisabled(true);
      setGpsLoading(false);
      return;
    }

    let watchId: number;

    if (gpsSourceState === 'real') {
      setIsRealGps(true);
      setGpsLoading(true);
      setPermissionDenied(false);
      setGpsDisabled(false);

      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const speedKmh = pos.coords.speed ? pos.coords.speed * 3.6 : 0; 
          const altitude = pos.coords.altitude || 215;
          const accuracy = pos.coords.accuracy || 2.1;
          const heading = pos.coords.heading !== null && !isNaN(pos.coords.heading) ? pos.coords.heading : (currentGPS.heading || 0);

          setCurrentSpeed(Math.round(speedKmh));
          setCurrentAltitude(Math.round(altitude));
          setCurrentAccuracy(parseFloat(accuracy.toFixed(1)));
          setGpsLoading(false);
          setPermissionDenied(false);
          setGpsDisabled(false);

          const canvasPoint = coordsToCanvas(lat, lng);
          onUpdateGPS({
            x: Math.max(0, Math.min(100, canvasPoint.x)),
            y: Math.max(0, Math.min(100, canvasPoint.y)),
            lat,
            lng,
            heading: Math.round(heading)
          });

          // Center map on user's current position immediately after the first location is detected
          if (mapRef.current && followUser) {
            mapRef.current.jumpTo({ center: [lng, lat], zoom: mapRef.current.getZoom() });
          }
        },
        (err) => {
          console.warn('Real GPS coordinate acquisition issues:', err.message);
          setGpsLoading(false);
          if (err.code === err.PERMISSION_DENIED) {
            setPermissionDenied(true);
            setIsRealGps(false);
          } else {
            setGpsDisabled(true);
            setIsRealGps(false);
          }
        },
        { enableHighAccuracy: true, maximumAge: 1000, timeout: 12000 }
      );
    } else {
      setIsRealGps(false);
      setGpsLoading(false);
    }

    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, [gpsSourceState, followUser]);

  // 1B. REVERSE GEOCODING OF LOCATION
  const lastGeocodedCoordsRef = useRef<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    if (!currentGPS.lat || !currentGPS.lng) return;

    let shouldFetch = false;
    if (!lastGeocodedCoordsRef.current) {
      shouldFetch = true;
    } else {
      const dist = getHaversineDistance(
        [currentGPS.lat, currentGPS.lng],
        [lastGeocodedCoordsRef.current.lat, lastGeocodedCoordsRef.current.lng]
      );
      if (dist > 0.5) { // fetch every 500 meters of movement
        shouldFetch = true;
      }
    }

    if (shouldFetch) {
      lastGeocodedCoordsRef.current = { lat: currentGPS.lat, lng: currentGPS.lng };
      
      const fetchAddress = async () => {
        try {
          const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${currentGPS.lat}&lon=${currentGPS.lng}&zoom=10&addressdetails=1`);
          if (response.ok) {
            const data = await response.json();
            if (data && data.address) {
              const addr = data.address;
              const city = addr.city || addr.town || addr.village || addr.municipality || addr.suburb || 'Tactical Base';
              const state = addr.state || addr.region || addr.county || 'Remote Region';
              const country = addr.country || 'Global Grid';
              setGeocodedAddress({ city, state, country });
            }
          }
        } catch (e) {
          console.warn("Offline reverse geocoding fallback active:", e);
          setGeocodedAddress({
            city: 'Tactical Base',
            state: 'Remote Sector',
            country: 'Off-grid Territory'
          });
        }
      };

      fetchAddress();
    }
  }, [currentGPS.lat, currentGPS.lng]);

  // 2. INITIALIZE MAPLIBRE GL MAP
  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Use current GPS coordinates to set initial map view
    const initialLat = currentGPS.lat || 24.1940;
    const initialLng = currentGPS.lng || 21.7366;

    const map = new maplibregl.Map({
      container: mapContainerRef.current,
      style: {
        version: 8,
        sources: {
          'carto-voyager': {
            type: 'raster',
            tiles: [
              'https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
              'https://b.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
              'https://c.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'
            ],
            tileSize: 256
          }
        },
        layers: [
          {
            id: 'carto-voyager-layer',
            type: 'raster',
            source: 'carto-voyager'
          }
        ]
      },
      center: [initialLng, initialLat],
      zoom: 13,
      attributionControl: false
    });

    mapRef.current = map;
    setMapInstance(map);

    // Wait until map style loads to draw custom layers
    map.on('style.load', () => {
      updateLayers();
    });

    // Event listeners
    map.on('zoom', () => {
      setMapZoom(map.getZoom());
    });

    map.on('dragstart', () => {
      setFollowUser(false);
    });

    map.on('rotatestart', () => {
      setIsCompassSynced(false);
      setAutoRotate(false);
    });

    // Handle long-press (contextmenu) anywhere to create a waypoint / drop a pin
    map.on('contextmenu', (e) => {
      const { lng, lat } = e.lngLat;
      setDroppedPin({
        lat,
        lng,
        name: `Dropped Pin (${lat.toFixed(4)}, ${lng.toFixed(4)})`
      });
      setIsBottomSheetExpanded(true);
      speakInstruction("Dropped pin at coordinates");
    });

    // Set map click logic to handle waypoint additions or dropped pins
    map.on('click', (e) => {
      const { lng, lat } = e.lngLat;
      const canvasPos = coordsToCanvas(lat, lng);

      // Map control or custom placement trigger Check
      const isPlacing = document.getElementById('btn-drop-pin-active')?.getAttribute('data-placing') === 'true';

      if (isPlacing) {
        onMapClickToAddWaypoint(
          parseFloat(canvasPos.x.toFixed(1)),
          parseFloat(canvasPos.y.toFixed(1)),
          lat,
          lng
        );
      } else {
        // Drop temporary destination pin
        setDroppedPin({
          lat,
          lng,
          name: `Dropped Pin (${lat.toFixed(4)}, ${lng.toFixed(4)})`
        });
      }
    });

    return () => {
      map.remove();
      mapRef.current = null;
      setMapInstance(null);
    };
  }, []);

  // 3. REACTIVE LAYER MANAGEMENTS
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const style = getMapStyle(mapType, settings.theme);
    map.setStyle(style);
  }, [mapType, settings.theme]);

  // Helper to re-render all vector layers
  const updateLayers = () => {
    const map = mapRef.current;
    if (!map || !map.isStyleLoaded()) return;

    // 1. Update routing layers
    const activeRouteSourceId = 'active-navigation-route';
    if (calculatedRoute.length > 0) {
      const coordinates = calculatedRoute.map(coord => [coord[1], coord[0]]);
      const geojson: GeoJSON.Feature = {
        type: 'Feature',
        properties: {},
        geometry: {
          type: 'LineString',
          coordinates
        }
      };

      if (map.getSource(activeRouteSourceId)) {
        (map.getSource(activeRouteSourceId) as maplibregl.GeoJSONSource).setData(geojson);
      } else {
        map.addSource(activeRouteSourceId, { type: 'geojson', data: geojson });
        map.addLayer({
          id: 'active-route-glow-bg',
          type: 'line',
          source: activeRouteSourceId,
          layout: { 'line-join': 'round', 'line-cap': 'round' },
          paint: { 'line-color': '#3b82f6', 'line-width': 14, 'line-opacity': 0.25 }
        });
        map.addLayer({
          id: 'active-route-glow-mid',
          type: 'line',
          source: activeRouteSourceId,
          layout: { 'line-join': 'round', 'line-cap': 'round' },
          paint: { 'line-color': '#60a5fa', 'line-width': 9, 'line-opacity': 0.6 }
        });
        map.addLayer({
          id: 'active-route-core',
          type: 'line',
          source: activeRouteSourceId,
          layout: { 'line-join': 'round', 'line-cap': 'round' },
          paint: { 'line-color': '#00d2ff', 'line-width': 4, 'line-opacity': 1.0 }
        });
      }

      // Fit map bounds to show route nicely if navigation is just started
      if (!navigationActive) {
        const lngs = calculatedRoute.map(c => c[1]);
        const lats = calculatedRoute.map(c => c[0]);
        const minLng = Math.min(...lngs);
        const maxLng = Math.max(...lngs);
        const minLat = Math.min(...lats);
        const maxLat = Math.max(...lats);
        map.fitBounds([[minLng, minLat], [maxLng, maxLat]], { padding: 50 });
      }
    } else {
      ['active-route-glow-bg', 'active-route-glow-mid', 'active-route-core'].forEach(id => {
        if (map.getLayer(id)) map.removeLayer(id);
      });
      if (map.getSource(activeRouteSourceId)) map.removeSource(activeRouteSourceId);
    }

    // 2. Update route builder layers
    const builderSourceId = 'route-builder-route';
    if (routeBuilderActive && routeBuilderPoints.length > 0) {
      const coordinates = routeBuilderPoints.map(p => {
        const itemCoords = canvasToCoords(p.x, p.y);
        return [itemCoords.lng, itemCoords.lat];
      });
      const geojson: GeoJSON.Feature = {
        type: 'Feature',
        properties: {},
        geometry: { type: 'LineString', coordinates }
      };

      if (map.getSource(builderSourceId)) {
        (map.getSource(builderSourceId) as maplibregl.GeoJSONSource).setData(geojson);
      } else {
        map.addSource(builderSourceId, { type: 'geojson', data: geojson });
        map.addLayer({
          id: 'route-builder-line',
          type: 'line',
          source: builderSourceId,
          layout: { 'line-join': 'round', 'line-cap': 'round' },
          paint: {
            'line-color': '#f43f5e',
            'line-width': 5,
            'line-opacity': 0.8,
            'line-dasharray': [2, 2]
          }
        });
      }
    } else {
      if (map.getLayer('route-builder-line')) map.removeLayer('route-builder-line');
      if (map.getSource(builderSourceId)) map.removeSource(builderSourceId);
    }

    // 3. Update offline maps bounds layers
    const offlineSourceId = 'offline-maps-boundaries';
    if (offlineMaps.length > 0) {
      const features = offlineMaps.map(region => {
        const minCorner = canvasToCoords(region.boundingBox.minX, region.boundingBox.minY);
        const maxCorner = canvasToCoords(region.boundingBox.maxX, region.boundingBox.maxY);
        const coords = [
          [minCorner.lng, minCorner.lat],
          [maxCorner.lng, minCorner.lat],
          [maxCorner.lng, maxCorner.lat],
          [minCorner.lng, maxCorner.lat],
          [minCorner.lng, minCorner.lat]
        ];
        return {
          type: 'Feature',
          properties: {},
          geometry: { type: 'Polygon', coordinates: [coords] }
        };
      });

      const geojson: GeoJSON.FeatureCollection = {
        type: 'FeatureCollection',
        features: features as any
      };

      if (map.getSource(offlineSourceId)) {
        (map.getSource(offlineSourceId) as maplibregl.GeoJSONSource).setData(geojson);
      } else {
        map.addSource(offlineSourceId, { type: 'geojson', data: geojson });
        const color = settings.theme === 'dark' ? '#22c55e' : '#0284c7';
        map.addLayer({
          id: 'offline-bounds-fill',
          type: 'fill',
          source: offlineSourceId,
          paint: { 'fill-color': color, 'fill-opacity': 0.04 }
        });
        map.addLayer({
          id: 'offline-bounds-outline',
          type: 'line',
          source: offlineSourceId,
          paint: { 'line-color': color, 'line-width': 1.5, 'line-dasharray': [3, 3] }
        });
      }
    } else {
      ['offline-bounds-fill', 'offline-bounds-outline'].forEach(id => {
        if (map.getLayer(id)) map.removeLayer(id);
      });
      if (map.getSource(offlineSourceId)) map.removeSource(offlineSourceId);
    }
  };

  useEffect(() => {
    updateLayers();
  }, [calculatedRoute, routeBuilderActive, routeBuilderPoints, offlineMaps, settings.theme, mapType]);

  // 4. MAP ROTATION & FOLLOW-USER EFFECT
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (followUser) {
      map.easeTo({ center: [currentGPS.lng, currentGPS.lat], zoom: map.getZoom() });
    }

    if (isCompassSynced) {
      setMapRotation(360 - compassHeading);
    } else if (autoRotate) {
      setMapRotation(360 - currentGPS.heading);
    }
  }, [currentGPS.lat, currentGPS.lng, currentGPS.heading, compassHeading, isCompassSynced, followUser, autoRotate]);

  // Set MapLibre bearing and pitch directly on input changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    map.setBearing(mapRotation);
    map.setPitch(mapTilt);
  }, [mapRotation, mapTilt]);

  // 5. DRAW AND UPDATE MAP ITEMS (Markers, Waypoints, Route Draftings, Routes)
  const waypointMarkersRef = useRef<{ [id: string]: maplibregl.Marker }>({});
  const userMarkerRef = useRef<maplibregl.Marker | null>(null);
  const droppedPinMarkerRef = useRef<maplibregl.Marker | null>(null);

  // Waypoints effect
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // Styles categorizations switcher helper
    const getCategoryHexColor = (cat: string) => {
      switch (cat) {
        case 'Campsite': return '#eab308';
        case 'Water Source': return '#3b82f6';
        case 'Checkpoint': return '#e11d48';
        case 'Harbor': return '#06b6d4';
        case 'Landmark': return '#a855f7';
        case 'Emergency Point': return '#ef4444';
        case 'Hazard': return '#f97316';
        default: return '#10b981';
      }
    };

    // Remove old waypoint markers
    Object.values(waypointMarkersRef.current).forEach((marker) => (marker as maplibregl.Marker).remove());
    waypointMarkersRef.current = {};

    // Draw waypoints
    waypoints.forEach((wp) => {
      const hex = getCategoryHexColor(wp.category);
      const isSelected = selectedWaypoint?.id === wp.id;
      
      const el = document.createElement('div');
      el.className = 'custom-waypoint-container';
      el.innerHTML = `
        <div class="relative flex items-center justify-center cursor-pointer">
          ${isSelected ? `<div class="absolute w-10 h-10 rounded-full animate-ping bg-opacity-30" style="background-color: ${hex}"></div>` : ''}
          <div class="h-7 w-7 rounded-full border-2 border-white flex items-center justify-center text-white text-[10px] font-black shadow-lg shadow-black/40" style="background-color: ${hex}">
            ${wp.category[0]}
          </div>
          <div class="absolute bottom-8 bg-black/90 text-white border border-gray-800 text-[8px] font-mono whitespace-nowrap px-1.5 py-0.5 rounded shadow ${isSelected ? 'border-amber-400 font-bold' : ''}">
            ${wp.name}
          </div>
        </div>
      `;

      el.addEventListener('click', (e) => {
        e.stopPropagation();
        onSelectWaypoint(wp);
      });

      const marker = new maplibregl.Marker({ element: el })
        .setLngLat([wp.longitude, wp.latitude])
        .addTo(map);

      waypointMarkersRef.current[wp.id] = marker;
    });
  }, [waypoints, selectedWaypoint]);

  // User Current Location indicator marker effect
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
      userMarkerRef.current = null;
    }

    const headingRotation = currentGPS.heading;
    const el = document.createElement('div');
    el.className = 'user-gps-nav-marker-container';
    el.innerHTML = `
      <div class="relative flex items-center justify-center">
        <!-- Accuracy / Pulse glow rings -->
        <div class="absolute w-16 h-16 rounded-full bg-[#00E676]/15 animate-ping opacity-60"></div>
        <div class="absolute w-12 h-12 rounded-full bg-[#00E676]/25 animate-pulse"></div>
        
        <!-- Inner solid pulsing brand emerald green core dot with heading beacon wedge -->
        <div class="relative h-6 w-6 bg-[#00E676] border-2 border-white rounded-full flex items-center justify-center shadow-[0_0_12px_rgba(0,230,118,0.8)] transition-transform animate-in zoom-in duration-300" style="transform: rotate(${headingRotation}deg)">
          <div class="absolute top-[-5px] w-0 h-0 border-l-[3px] border-l-transparent border-r-[3px] border-r-transparent border-b-[6px] border-b-[#00C853]"></div>
          <div class="h-2 w-2 bg-white rounded-full"></div>
        </div>
      </div>
    `;

    const marker = new maplibregl.Marker({ element: el })
      .setLngLat([currentGPS.lng, currentGPS.lat])
      .addTo(map);

    userMarkerRef.current = marker;
  }, [currentGPS.lat, currentGPS.lng, currentGPS.heading, settings.theme]);

  // Dropped Destination Pin marker effect
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (droppedPinMarkerRef.current) {
      droppedPinMarkerRef.current.remove();
      droppedPinMarkerRef.current = null;
    }

    if (droppedPin) {
      const el = document.createElement('div');
      el.className = 'dropped-pin-marker-container';
      el.innerHTML = `
        <div class="relative flex flex-col items-center justify-center">
          <span class="animate-ping absolute w-8 h-8 rounded-full bg-rose-500/30"></span>
          <div class="text-rose-500 drop-shadow-lg">
            <svg class="h-8 w-8 filter drop-shadow-md fill-current" viewBox="0 0 24 24">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
            </svg>
          </div>
          <div class="absolute top-[32px] bg-neutral-900 border border-neutral-700 text-white rounded px-2 py-0.5 text-[9px] font-mono tracking-tight shadow whitespace-nowrap">
            Dropped Destination Pin
          </div>
        </div>
      `;

      const marker = new maplibregl.Marker({ element: el })
        .setLngLat([droppedPin.lng, droppedPin.lat])
        .addTo(map);

      droppedPinMarkerRef.current = marker;

      // PAN TO DROPPED PIN
      map.easeTo({ center: [droppedPin.lng, droppedPin.lat], zoom: map.getZoom() });
    }
  }, [droppedPin]);

  // 7. ROUTE PLANNING & DISTANCE CALC TO DROPPED PIN
  const lastCalculatedStartCoords = useRef<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    if (!droppedPin) {
      setCalculatedRoute([]);
      setRouteStats(null);
      lastCalculatedStartCoords.current = null;
      return;
    }

    const startLat = currentGPS.lat;
    const startLng = currentGPS.lng;

    // Recalculate route automatically only when user's location changes significantly (>15 meters)
    let shouldRecalculate = false;
    if (!lastCalculatedStartCoords.current) {
      shouldRecalculate = true;
    } else {
      const distFromPrev = getHaversineDistance(
        [startLat, startLng],
        [lastCalculatedStartCoords.current.lat, lastCalculatedStartCoords.current.lng]
      );
      if (distFromPrev > 0.015) { // 15 meters
        shouldRecalculate = true;
      }
    }

    if (!shouldRecalculate && calculatedRoute.length > 0) {
      return; // Skip recalculating on microscopic GPS jitters
    }

    lastCalculatedStartCoords.current = { lat: startLat, lng: startLng };

    const endLat = droppedPin.lat;
    const endLng = droppedPin.lng;

    // Generate smart path array with checkpoints
    const startPt: [number, number] = [startLat, startLng];
    const endPt: [number, number] = [endLat, endLng];

    // Smart route generating algorithm representing roads or trails
    const path: [number, number][] = [startPt];
    const segments = 4;
    const latDiff = (endLat - startLat) / segments;
    const lngDiff = (endLng - startLng) / segments;

    for (let i = 1; i < segments; i++) {
      const targetBaseLat = startLat + latDiff * i;
      const targetBaseLng = startLng + lngDiff * i;
      const wave = Math.sin(i * 1.5) * 0.06 * Math.abs(latDiff + lngDiff);
      path.push([targetBaseLat + wave, targetBaseLng - wave]);
    }
    path.push(endPt);

    setCalculatedRoute(path);

    let totalDist = 0;
    for (let i = 0; i < path.length - 1; i++) {
      totalDist += getHaversineDistance(path[i], path[i+1]);
    }

    // Convert estimated speed based on navigation modes
    const speedMappingKmh = 35; // default hybrid speed
    const durationHrs = totalDist / speedMappingKmh;
    const totalMins = Math.round(durationHrs * 60);
    const durationStr = totalMins > 60 
      ? `${Math.floor(totalMins / 60)}h ${totalMins % 60}m` 
      : `${totalMins} mins`;

    // Estimate progress ETA
    const etaDate = new Date();
    etaDate.setMinutes(etaDate.getMinutes() + totalMins);
    const hours = String(etaDate.getHours()).padStart(2, '0');
    const mins = String(etaDate.getMinutes()).padStart(2, '0');
    
    setRouteStats({
      distance: totalDist,
      duration: durationStr,
      eta: `${hours}:${mins}`
    });

    // Create Navigation Instructions
    const customInst = [
      'Head northeast along the trail.',
      'In 600m, turn sharp left onto Ridge Track.',
      'Take the canyon path down for 1.2km.',
      'Prepare to turn towards the coordinate coordinates.',
      'Welcome! Arrived safely at selected destination.'
    ];
    setNavInstructions(customInst);

  }, [droppedPin, currentGPS.lat, currentGPS.lng]);

  // 8. TANK NAVIGATION GUIDANCES PROGRESS MOVEMENT SIMULATORS
  const navIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (!navigationActive) {
      if (navIntervalRef.current) {
        clearInterval(navIntervalRef.current);
        navIntervalRef.current = null;
      }
      return;
    }

    speakInstruction("System ready, starting route guidance. Please follow direction cues.");

    let step = 0;
    setNavStepIndex(0);
    setNavNextInstruction(navInstructions[0] || 'Keep following the active path.');

    const totalSeconds = 25; // complete entire path in 25 ticks
    const navInterval = setInterval(() => {
      if (gpsSourceState === 'real') {
        // Real-time GPS navigation tracker
        if (droppedPin) {
          const distToDest = getHaversineDistance([currentGPS.lat, currentGPS.lng], [droppedPin.lat, droppedPin.lng]);
          setNavDistanceRemaining(distToDest);
          const subSec = Math.round(distToDest * 2); // 1km = 2mins
          setNavTimeRemaining(subSec > 60 ? `${Math.floor(subSec / 60)}h ${subSec % 60}m` : `${subSec}m`);

          if (distToDest < 0.02) { // 20 meters to destination
            clearInterval(navInterval);
            onToggleNavigation(false);
            setDroppedPin(null);
            setCalculatedRoute([]);
            speakInstruction("Congratulations! You have successfully completed this navigation course.");
            return;
          }

          // Progressively update instruction based on distance remaining
          const routeTotal = routeStats?.distance || 1;
          const fraction = Math.min(1, Math.max(0, 1 - distToDest / routeTotal));
          const activeStep = Math.min(calculatedRoute.length - 1, Math.floor(fraction * calculatedRoute.length));
          setNavStepIndex(activeStep);

          const segmentIndex = Math.min(activeStep, navInstructions.length - 1);
          const directText = navInstructions[segmentIndex] || 'Keep following the active path.';
          if (directText !== navNextInstruction) {
            setNavNextInstruction(directText);
            speakInstruction(directText);
          }
        }
      } else {
        // Simulated path progression
        step++;
        
        if (step >= calculatedRoute.length) {
          clearInterval(navInterval);
          onToggleNavigation(false);
          setDroppedPin(null);
          setCalculatedRoute([]);
          speakInstruction("Congratulations! You have successfully completed this navigation course.");
          return;
        }

        setNavStepIndex(step);
        const activeCoords = calculatedRoute[step];

        // Update currentGPS coordinates to follow active simulated navigation points with heading
        const prevCoords = calculatedRoute[step - 1];
        const dy = activeCoords[0] - prevCoords[0];
        const dx = activeCoords[1] - prevCoords[1];
        const theta = Math.atan2(dy, dx) * 180 / Math.PI;
        const angle = (90 - theta) % 360;

        onUpdateGPS({
          x: coordsToCanvas(activeCoords[0], activeCoords[1]).x,
          y: coordsToCanvas(activeCoords[0], activeCoords[1]).y,
          lat: activeCoords[0],
          lng: activeCoords[1],
          heading: Math.round(angle < 0 ? angle + 360 : angle)
        });

        // Update HUD values
        const segmentIndex = Math.min(step, navInstructions.length - 1);
        const directText = navInstructions[segmentIndex];
        setNavNextInstruction(directText);
        speakInstruction(directText);

        // Remaining distance/ETA
        if (routeStats) {
          const factor = (calculatedRoute.length - step) / calculatedRoute.length;
          const subDist = routeStats.distance * factor;
          const subSec = Math.round(subDist * 2); // 1km = 2mins
          setNavDistanceRemaining(subDist);
          setNavTimeRemaining(subSec > 60 ? `${Math.floor(subSec / 60)}h ${subSec % 60}m` : `${subSec}m`);
        }
      }
    }, 3500);

    navIntervalRef.current = navInterval as any;

    return () => {
      if (navInterval) clearInterval(navInterval);
    };

  }, [navigationActive, calculatedRoute]);

  // 9. MAP CONTROLS ACTIONS HANDLERS
  const handleZoomIn = () => {
    mapRef.current?.zoomIn();
  };

  const handleZoomOut = () => {
    mapRef.current?.zoomOut();
  };

  const handleRecenter = () => {
    setMapRotation(0);
    setAutoRotate(false);
    setIsCompassSynced(false);
    if (mapRef.current) {
      mapRef.current.easeTo({ center: [currentGPS.lng, currentGPS.lat], zoom: 14 });
    }
  };

  // Switch GPS simulated coordinates source triggers
  const toggleGpsSource = () => {
    const nextSource = gpsSourceState === 'simulated' ? 'real' : 'simulated';
    setGpsSourceState(nextSource);
    speakInstruction(`Switched telemetry to ${nextSource} coordinate fix`);
  };

  // 10. ADDRESS & GPS SEARCH EXECUTER SUBMISSIONS
  const handleSearchTrigger = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;

    setIsSearching(true);
    const term = searchInput.toLowerCase().trim();

    // Let's parse coordinate strings
    const coordExp = /(-?\d+\.?\d*)\s*,\s*(-?\d+\.?\d*)/;
    const match = term.match(coordExp);

    if (match) {
      const parsedLat = parseFloat(match[1]);
      const parsedLng = parseFloat(match[2]);

      if (!isNaN(parsedLat) && !isNaN(parsedLng)) {
        setDroppedPin({
          lat: parsedLat,
          lng: parsedLng,
          name: `Searched Coordinate: [${parsedLat.toFixed(4)}, ${parsedLng.toFixed(4)}]`
        });
        setIsSearching(false);
        setSearchInput('');
        return;
      }
    }

    // Try finding predefined local waypoints or map regions
    const matchingWp = waypoints.find(w => w.name.toLowerCase().includes(term) || w.category.toLowerCase().includes(term));
    if (matchingWp) {
      setDroppedPin({
        lat: matchingWp.latitude,
        lng: matchingWp.longitude,
        name: matchingWp.name
      });
      setIsSearching(false);
      setSearchInput('');
      return;
    }

    const matchingRegion = offlineMaps.find(m => m.name.toLowerCase().includes(term) || m.region.toLowerCase().includes(term));
    if (matchingRegion) {
      const centerCoords = canvasToCoords(
        (matchingRegion.boundingBox.minX + matchingRegion.boundingBox.maxX) / 2,
        (matchingRegion.boundingBox.minY + matchingRegion.boundingBox.maxY) / 2
      );
      mapRef.current?.easeTo({ center: [centerCoords.lng, centerCoords.lat], zoom: 13 });
      setIsSearching(false);
      setSearchInput('');
      return;
    }

    // Call free OpenStreetMap Nominatim API for real global geocoding
    try {
      const resp = await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=3&q=${encodeURIComponent(searchInput)}`);
      const payload = await resp.json();

      if (payload && payload.length > 0) {
        const results = payload.map((item: any) => ({
          lat: parseFloat(item.lat),
          lng: parseFloat(item.lon),
          name: item.display_name
        }));
        
        setSearchResults(results);
      } else {
        setSearchResults([]);
      }
    } catch (err) {
      console.warn("Global geocode failed, using local lookup fallback.", err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSelectSearchResult = (res: { lat: number; lng: number; name: string }) => {
    setDroppedPin({
      lat: res.lat,
      lng: res.lng,
      name: res.name
    });
    setSearchResults([]);
    setSearchInput('');
  };

  // Weather lookup computed variables
  const weather = React.useMemo(() => {
    const lat = currentGPS.lat;
    const lng = currentGPS.lng;
    const seed = Math.abs(Math.sin(lat * 7.7 + lng * 4.4));
    
    let condition = "Sunny & Calm";
    let temp = Math.round(26 + seed * 14); 
    let humidity = Math.round(10 + (1 - seed) * 25);
    let windSpeed = Math.round(4 + seed * 30);
    let statusColor = "text-amber-400";
    let weatherType: 'sunny' | 'cloudy' | 'windy' | 'rainy' | 'harsh' = 'sunny';
    
    if (seed < 0.22) {
      condition = "Overcast Clouds";
      temp = Math.round(22 + seed * 10);
      humidity = Math.round(35 + seed * 45);
      windSpeed = Math.round(10 + seed * 12);
      statusColor = "text-blue-400";
      weatherType = 'cloudy';
    } else if (seed > 0.82) {
      condition = "Severe Sandstorm Risk";
      temp = Math.round(38 + (seed - 0.8) * 15);
      humidity = Math.round(5 + (1 - seed) * 12);
      windSpeed = Math.round(38 + (seed - 0.8) * 90);
      statusColor = "text-red-500 animate-pulse font-bold";
      weatherType = 'harsh';
    } else if (seed > 0.58) {
      condition = "Dry Gusty Wind";
      temp = Math.round(32 + seed * 6);
      humidity = Math.round(12 + seed * 15);
      windSpeed = Math.round(22 + seed * 25);
      statusColor = "text-orange-400";
      weatherType = 'windy';
    } else if (seed < 0.38) {
      condition = "Passing Desert Shower";
      temp = Math.round(23 + seed * 8);
      humidity = Math.round(55 + seed * 25);
      windSpeed = Math.round(14 + seed * 20);
      statusColor = "text-sky-450";
      weatherType = 'rainy';
    }
    return { condition, temp, humidity, windSpeed, statusColor, weatherType };
  }, [currentGPS.lat, currentGPS.lng]);

  // Caching simulator status helpers
  const checkCoordinatesIsDownloaded = (lat: number, lng: number) => {
    if (!settings.offlineModeActive) return true;
    const canvasPos = coordsToCanvas(lat, lng);
    return offlineMaps.some(
      (m) =>
        m.downloadStatus === 'downloaded' &&
        canvasPos.x >= m.boundingBox.minX &&
        canvasPos.x <= m.boundingBox.maxX &&
        canvasPos.y >= m.boundingBox.minY &&
        canvasPos.y <= m.boundingBox.maxY
    );
  };

  const isDark = settings.theme === 'dark';
  const cardBgClass = isDark ? 'bg-zinc-950/90 border-green-950/60 text-white backdrop-blur-strong' : 'bg-white/95 border-gray-200 text-gray-800 backdrop-blur-md';

  // Helper to generate stable terrain descriptions based on coordinates
  const getStableTerrain = (lat: number, lng: number) => {
    const hash = Math.round(Math.abs(Math.sin(lat + lng) * 100));
    const types = [
      "Alpine Forest Tundra", 
      "Granite Rock Canyon", 
      "Arid Desert Sand Dunes", 
      "Moist Forest Meadow", 
      "Rocky Scree Slope", 
      "Savannah Grassland"
    ];
    return types[hash % types.length];
  };

  // Helper to generate stable elevation values based on coordinates
  const getStableElevation = (lat: number, lng: number) => {
    const hash = Math.abs(Math.cos(lat) * Math.sin(lng));
    const elevationMeters = Math.round(hash * 1850 + 120);
    if (settings.distanceUnit === 'miles') {
      return `${Math.round(elevationMeters * 3.28084).toLocaleString()} ft`;
    }
    return `${elevationMeters.toLocaleString()} m`;
  };

  // Helper to generate stable place names
  const getStablePlaceName = (lat: number, lng: number) => {
    const hash = Math.abs(Math.sin(lat) * Math.cos(lng) * 10000);
    const prefixes = ["Ridge", "Summit", "Canyon", "Valley", "Meadow", "Plateau", "Pass", "Springs", "Crest", "Basin"];
    const adjectives = ["Golden", "Shadow", "Alpine", "Zion", "Sahara", "Highland", "Echo", "Crimson", "Emerald", "Sierra"];
    const adj = adjectives[Math.floor(hash) % adjectives.length];
    const pre = prefixes[Math.floor(hash * 3.1) % prefixes.length];
    return `${adj} ${pre} Area`;
  };

  const handleShareCoords = (lat: number, lng: number) => {
    const text = `PEEZIGATOR GRID SYSTEM PIN: ${lat.toFixed(6)}°N, ${lng.toFixed(6)}°E - Elevation: ${getStableElevation(lat, lng)}`;
    navigator.clipboard.writeText(text);
    // Raise custom toast
    const toastEvent = new CustomEvent('peezigator_toast', { detail: 'Grid pin coordinates copied to clipboard!' });
    window.dispatchEvent(toastEvent);
  };

  const scaleLabel = scaleData?.label || "100 m";
  const scaleWidthPx = scaleData?.width || 100;

  return (
    <div className={`relative h-full w-full overflow-hidden flex flex-col ${isDark ? 'bg-black' : 'bg-gray-50'}`}>
      
      {/* Hidden legacy node to ensure Leaflet on click event works for waypoint placing callback context */}
      <div id="btn-drop-pin-active" data-placing={isPlacingWaypoint} className="hidden" />

      {/* ========================================================= */}
      {/* REAL-TIME MAP VIEWPORT - Occupies 100% of the screen     */}
      {/* ========================================================= */}
      <div 
        ref={mapContainerRef} 
        id="peezigator-viewport" 
        className="absolute inset-0 w-full h-full z-0 cursor-crosshair animate-in fade-in duration-300"
      />

      {/* Waypoint placement HUD prompt */}
      {isPlacingWaypoint && (
        <div className="absolute top-16 left-4 right-4 z-40 bg-rose-600 border border-rose-500 text-white px-4 py-2 rounded-full shadow-2xl text-[10px] font-mono font-black uppercase tracking-widest flex items-center justify-between gap-2 animate-bounce">
          <span>📍 TAP THE MAP VIEWPORT TO PIN WAYPOINT</span>
          <button 
            onClick={() => setIsPlacingWaypoint(false)}
            className="bg-black/35 hover:bg-black/50 px-2 py-0.5 rounded-full text-[9px] cursor-pointer"
          >
            CANCEL
          </button>
        </div>
      )}

      {/* GPS SAT-LOCK LOADING OVERLAY */}
      {gpsLoading && gpsSourceState === 'real' && (
        <div className="absolute inset-0 bg-black/92 z-50 flex flex-col items-center justify-center p-6 text-center select-none font-mono">
          <div className="relative mb-6">
            <Compass className="h-16 w-16 text-emerald-500 animate-spin-slow" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-6 w-6 rounded-full bg-emerald-500/20 animate-ping"></div>
            </div>
          </div>
          <h3 className="text-lg font-mono font-black uppercase tracking-widest text-emerald-400">
            Acquiring Satellite Lock
          </h3>
          <p className="text-xs font-mono text-gray-400 mt-2 max-w-sm leading-relaxed">
            Peezigator Fused Location Provider is requesting fine location permissions and establishing a direct high-accuracy GPS fix...
          </p>
          <div className="mt-6 flex items-center gap-2 bg-zinc-950 px-3 py-1.5 rounded-lg border border-green-950/40 font-mono text-[9px] text-green-300">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>PROVIDER: GOOGLE FUSED LOCATION</span>
          </div>
        </div>
      )}

      {/* ACCESS_FINE_LOCATION PERMISSION EXPLANATION OVERLAY */}
      {permissionDenied && gpsSourceState === 'real' && (
        <div className="absolute inset-0 bg-black/95 z-50 flex flex-col items-center justify-center p-6 text-center select-none font-mono">
          <div className="h-16 w-16 rounded-full bg-red-950/50 border border-red-500 flex items-center justify-center text-red-500 mb-6 text-3xl font-extrabold animate-bounce">
            ⚠️
          </div>
          <h3 className="text-base font-black uppercase tracking-widest text-red-500">
            Android fine location permission denied
          </h3>
          <div className="bg-zinc-900/60 border border-zinc-800 p-4 rounded-xl text-left max-w-md mt-4 space-y-2">
            <p className="text-xs text-gray-350 leading-relaxed">
              Peezigator requires <span className="text-red-400 font-bold">ACCESS_FINE_LOCATION</span> (GPS) and <span className="text-red-400 font-bold">ACCESS_COARSE_LOCATION</span> (Network) runtime permissions to provide offline backcountry navigation.
            </p>
            <p className="text-[11px] text-gray-400 leading-relaxed">
              Without location access, map tracking, compass orientation, and turn-by-turn off-grid routing are completely offline and unavailable.
            </p>
          </div>
          <p className="text-xs text-gray-400 mt-4">
            Please allow Location Permissions in your browser/device settings.
          </p>
          <button
            onClick={() => {
              setGpsSourceState('simulated');
              setTimeout(() => setGpsSourceState('real'), 150);
            }}
            className="mt-6 px-6 py-3 bg-gradient-to-r from-red-600 to-rose-700 hover:opacity-90 active:scale-95 text-white font-bold text-xs uppercase tracking-widest rounded-xl transition-all cursor-pointer shadow-lg"
          >
            Grant Permissions / Retry Fix
          </button>
        </div>
      )}

      {/* LOCATION SERVICES (GPS RECEIVER) INACTIVE OVERLAY */}
      {gpsDisabled && gpsSourceState === 'real' && (
        <div className="absolute inset-0 bg-black/95 z-50 flex flex-col items-center justify-center p-6 text-center select-none font-mono">
          <div className="h-16 w-16 rounded-full bg-yellow-950/50 border border-yellow-500 flex items-center justify-center text-yellow-500 mb-6 text-3xl font-extrabold animate-pulse">
            📡
          </div>
          <h3 className="text-base font-black uppercase tracking-widest text-yellow-500">
            Location Services (GPS) Disabled
          </h3>
          <div className="bg-zinc-900/60 border border-zinc-800 p-4 rounded-xl text-left max-w-md mt-4 space-y-2">
            <p className="text-xs text-gray-350 leading-relaxed">
              Your device's high-accuracy hardware GPS receiver is currently disabled or unable to find a clear satellite line of sight.
            </p>
            <p className="text-[11px] text-gray-400 leading-relaxed text-yellow-400/80">
              Please enable Location Services (GPS) in your device settings and ensure you have a clear view of the sky. Network fallback will be used when possible, but offline performance requires GPS.
            </p>
          </div>
          <div className="mt-6 flex gap-3">
            <button
              onClick={() => {
                setGpsSourceState('simulated');
              }}
              className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer"
            >
              Simulated Mode
            </button>
            <button
              onClick={() => {
                setGpsSourceState('simulated');
                setTimeout(() => setGpsSourceState('real'), 150);
              }}
              className="px-5 py-2.5 bg-gradient-to-r from-yellow-500 to-amber-600 hover:opacity-90 text-black font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg"
            >
              Retry GPS Connection
            </button>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SEARCH OVERLAY - Premium Top Floating Bar                 */}
      {/* ========================================================= */}
      {activePanel === 'map' && (
        <div className="absolute top-4 left-4 right-4 z-40 flex flex-col items-center animate-in fade-in slide-in-from-top-2 duration-200">
        <div className="flex items-center w-full gap-2.5">
          <form 
            onSubmit={handleSearchTrigger} 
            className={`flex items-center flex-1 h-11 px-3.5 rounded-full border shadow-2xl transition-all ${
              isDark ? 'bg-[#182433]/95 border-zinc-800 text-[#00E676] focus-within:border-[#00E676]' : 'bg-white border-zinc-200 text-zinc-800 focus-within:border-[#00C853]'
            }`}
          >
            <Search className="h-4 w-4 text-gray-400 shrink-0 mr-2" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search grid nodes, pins, peaks..."
              className={`flex-1 bg-transparent border-none outline-none font-sans text-xs placeholder:text-gray-400 ${isDark ? 'text-white font-medium' : 'text-zinc-900 font-medium'}`}
            />
            {searchInput && (
              <button 
                type="button" 
                onClick={() => { setSearchInput(''); setSearchResults([]); }}
                className="text-[10px] font-sans font-bold text-gray-400 hover:text-red-500 px-2 shrink-0 mr-1 cursor-pointer"
              >
                CLEAR
              </button>
            )}
            <button 
              type="submit"
              className={`px-3.5 py-1.5 rounded-full text-[9px] font-sans font-extrabold uppercase shrink-0 transition-all cursor-pointer ${
                isDark ? 'bg-[#00E676] hover:bg-[#00C853] text-black' : 'bg-[#00C853] hover:bg-emerald-700 text-white'
              }`}
            >
              {isSearching ? '...' : 'FIND'}
            </button>
          </form>

          {/* Single small status-color-coded icon in the map corner that expands into a detailed diagnostics panel when tapped */}
          <button
            type="button"
            onClick={() => setIsDiagnosticsOpen(true)}
            className={`h-11 w-11 rounded-full border shadow-2xl flex items-center justify-center shrink-0 transition-all hover:scale-105 active:scale-95 cursor-pointer relative ${
              isDark ? 'bg-[#182433]/95 border-zinc-800 text-[#00E676] hover:text-[#00E676]' : 'bg-white border-zinc-200 text-zinc-800 hover:text-[#00C853]'
            }`}
            title="GPS Status - Tap for Diagnostics"
          >
            {/* Status-color-coded pulsing light background indicator */}
            <span className={`absolute top-0 right-0 h-3 w-3 rounded-full border border-white dark:border-zinc-950 shadow-md ${
              ((!gpsLoading || gpsSourceState === 'simulated') && !permissionDenied && !gpsDisabled) 
                ? 'bg-emerald-500 shadow-[0_0_6px_rgba(16,185,129,0.8)]' 
                : 'bg-amber-500 animate-pulse shadow-[0_0_6px_rgba(245,158,11,0.8)]'
            }`} />
            
            {/* Dynamic premium navigation icon */}
            <Navigation className={`h-4 w-4 ${
              ((!gpsLoading || gpsSourceState === 'simulated') && !permissionDenied && !gpsDisabled) 
                ? 'text-emerald-400 rotate-45' 
                : 'text-amber-500 animate-pulse'
            }`} />
          </button>
        </div>

        {/* Live Nominatim Dropdown Search results */}
        {searchResults.length > 0 && (
          <div className={`mt-2 w-full rounded-2xl border shadow-2xl p-2 z-50 text-xs font-mono max-h-48 overflow-y-auto ${cardBgClass}`}>
            <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold block px-2.5 pb-1">Geocoding Matches:</span>
            {searchResults.map((res, index) => (
              <button
                key={index}
                type="button"
                onClick={() => handleSelectSearchResult(res)}
                className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center gap-2 border-b last:border-none cursor-pointer ${
                  isDark ? 'hover:bg-white/10 border-white/5' : 'hover:bg-gray-100 border-gray-100'
                }`}
              >
                <MapPin className="h-4 w-4 shrink-0 text-sky-500" />
                <span className="truncate">{res.name}</span>
              </button>
            ))}
          </div>
        )}
      </div>
      )}

      {/* BACKDROP TAP-AWAY OVERLAY FOR QUICK ACTIONS MENU */}
      {quickActionsOpen && (
        <div 
          className="absolute inset-0 z-30 bg-black/20 backdrop-blur-[1px] animate-in fade-in duration-200" 
          onClick={() => {
            setQuickActionsOpen(false);
            speakInstruction("Quick actions menu closed");
          }}
        />
      )}

      {/* DYNAMIC SCALE BAR RULER (Bottom-Left) */}
      <ScaleBar 
        map={mapInstance} 
        isDark={isDark} 
        distanceUnit={settings.distanceUnit === 'km' ? 'kilometers' : 'miles'} 
      />

      {/* FLOATING COMPASS NEEDLE INDICATOR (Top Right) */}
      <div 
        className={`absolute top-[76px] right-4 z-40 h-14 w-14 rounded-full border shadow-2xl flex items-center justify-center cursor-pointer transition-all duration-300 ${
          isDark 
            ? 'bg-[#111c2a]/95 border-zinc-800 text-[#00E676] shadow-[0_4px_20px_rgba(0,0,0,0.5)]' 
            : 'bg-white border-zinc-200 text-zinc-800 shadow-[0_4px_15px_rgba(0,0,0,0.1)]'
        }`}
        onClick={() => {
          if (mapRef.current) {
            mapRef.current.easeTo({ bearing: 0, pitch: 0 });
          }
          speakInstruction("Map orientation reset to North");
        }}
        title="True North Compass - Click to reset map bearing"
      >
        {/* Compass dial tick marks */}
        <div className="absolute inset-1 rounded-full border border-dashed border-zinc-500/20"></div>
        {/* Compass Needle */}
        <div 
          className="relative w-2.5 h-10 transition-transform duration-150 ease-out flex flex-col justify-between items-center"
          style={{ transform: `rotate(${currentGPS.heading || 0}deg)` }}
        >
          {/* North pointer (Red) */}
          <div className="w-0 h-0 border-l-[4.5px] border-l-transparent border-r-[4.5px] border-r-transparent border-b-[20px] border-b-rose-500"></div>
          {/* South pointer (Silver/White) */}
          <div className="w-0 h-0 border-l-[4.5px] border-l-transparent border-r-[4.5px] border-r-transparent border-t-[20px] border-t-zinc-400"></div>
        </div>
        {/* Center pivot pin */}
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full border z-10 shadow ${
          isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-white border-zinc-300'
        }`}></div>
        {/* Small cardinal directions */}
        <span className="absolute top-1 text-[8px] font-black font-mono text-rose-500">N</span>
        <span className="absolute bottom-1 text-[8px] font-black font-mono text-zinc-400">S</span>
        <span className="absolute left-1.5 text-[8px] font-black font-mono text-zinc-500">W</span>
        <span className="absolute right-1.5 text-[8px] font-black font-mono text-zinc-500">E</span>
      </div>

      {/* BEAUTIFUL RIGHT-HAND SIDE CONTROL DOCK (Mockup Inspired) */}
      {!quickActionsOpen ? (
        <div className="absolute right-4 top-1/2 -translate-y-1/2 z-40 flex flex-col gap-3 select-none items-center">
          {/* 1. LAYERS BUTTON */}
          <button
            onClick={() => {
              // Cycle through map types
              const mapTypes: ('standard' | 'satellite' | 'hybrid' | 'terrain' | 'dark' | 'light')[] = [
                'standard', 'satellite', 'hybrid', 'terrain', 'dark', 'light'
              ];
              const nextIndex = (mapTypes.indexOf(mapType) + 1) % mapTypes.length;
              setMapType(mapTypes[nextIndex]);
              speakInstruction(`Map layer updated to ${mapTypes[nextIndex]}`);
            }}
            className={`h-11 w-11 rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-110 active:scale-95 cursor-pointer border ${
              isDark 
                ? 'bg-[#111c2a]/95 border-zinc-800 text-[#00E676] hover:border-[#38B6FF]' 
                : 'bg-white border-zinc-200 text-zinc-800 hover:bg-gray-50'
            }`}
            title="Cycle Map Layers"
          >
            <Layers className="h-5 w-5" />
          </button>

          {/* 2. COMPASS BEARING BUTTON */}
          <button
            onClick={() => {
              setIsCompassSynced(!isCompassSynced);
              if (mapRef.current) {
                mapRef.current.easeTo({ bearing: 0, pitch: 0 });
              }
              speakInstruction("Map orientation reset to North");
            }}
            className={`h-11 w-11 rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-110 active:scale-95 cursor-pointer border ${
              isDark 
                ? 'bg-[#111c2a]/95 border-zinc-800 text-[#00E676] hover:border-[#38B6FF]' 
                : 'bg-white border-zinc-200 text-zinc-800 hover:bg-gray-50'
            }`}
            title="Reset Map Orientation"
          >
            <div 
              className="w-1 h-6 relative transition-transform duration-150 ease-out flex flex-col justify-between items-center"
              style={{ transform: `rotate(${mapRotation}deg)` }}
            >
              <div className="w-[3px] h-[10px] bg-red-500 rounded-t-full"></div>
              <div className="w-[3px] h-[10px] bg-zinc-400 rounded-b-full"></div>
            </div>
          </button>

          {/* 3. TARGET LOCATOR BUTTON */}
          <button
            onClick={() => {
              const nextFollow = !followUser;
              setFollowUser(nextFollow);
              if (nextFollow) {
                if (mapRef.current) {
                  mapRef.current.easeTo({ center: [currentGPS.lng, currentGPS.lat], zoom: 15 });
                }
                speakInstruction("Follow My Location activated");
              } else {
                speakInstruction("Follow My Location deactivated");
              }
            }}
            className={`h-11 w-11 rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-110 active:scale-95 cursor-pointer border ${
              followUser 
                ? 'bg-[#00E676] text-black border-[#00E676] shadow-[0_0_12px_rgba(0,230,118,0.5)]' 
                : isDark 
                  ? 'bg-[#111c2a]/95 border-zinc-800 text-[#00E676] hover:border-[#38B6FF]' 
                  : 'bg-white border-zinc-200 text-[#00C853] hover:bg-gray-50'
            }`}
            title={followUser ? "Follow My Location: ON" : "Follow My Location: OFF"}
          >
            <Crosshair className="h-5 w-5" />
          </button>

          {/* 4. PLUS / QUICK ACTION BUTTON */}
          <button
            onClick={() => {
              setQuickActionsOpen(true);
              speakInstruction("Quick actions menu opened");
            }}
            className="h-11 w-11 rounded-full bg-[#38B6FF] border border-[#38B6FF]/30 text-white flex items-center justify-center hover:scale-110 active:scale-95 transition-all cursor-pointer shadow-[0_0_15px_rgba(56,182,255,0.4)]"
            title="Quick Actions"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>
      ) : (
        /* EXPANDABLE QUICK ACTIONS PANEL */
        <div className="absolute bottom-20 right-4 z-40 font-sans flex flex-col items-end">
          <div 
            className={`transition-all duration-300 ease-out origin-bottom-right shadow-2xl border flex flex-col overflow-hidden w-[320px] sm:w-[350px] max-h-[500px] p-4 rounded-[2rem] ${
              isDark 
                ? 'bg-[#08131F]/95 border-zinc-800 text-white shadow-[0_25px_60px_rgba(0,0,0,0.85)]' 
                : 'bg-white border-gray-200 text-zinc-900 shadow-gray-200/50'
            }`}
          >
            <div className="flex flex-col gap-3 animate-in fade-in zoom-in-95 duration-250 overflow-y-auto max-h-full">
              {/* Header with Title and Close 'X' */}
              <div className="flex items-center justify-between border-b border-zinc-800/20 dark:border-zinc-800 pb-2 shrink-0">
                <span className="text-[10px] font-mono font-black tracking-wider text-emerald-500 uppercase">
                  ⚡ Off-Grid Map Engine Controls
                </span>
                <button
                  onClick={() => {
                    setQuickActionsOpen(false);
                    speakInstruction("Quick actions menu closed");
                  }}
                  className="text-zinc-400 hover:text-red-500 transition-colors font-mono text-xs font-black p-1 cursor-pointer"
                  title="Close Menu"
                >
                  ✕
                </button>
              </div>

              {/* 1. Top row status: Compass Alignment, Zoom, and Follow Location */}
              <div className="grid grid-cols-3 gap-2 border-b border-zinc-800/10 dark:border-zinc-800 pb-2.5">
                {/* A. Compass alignment */}
                <button
                  onClick={() => {
                    if (mapRotation !== 0) {
                      setMapRotation(0);
                      setAutoRotate(false);
                      setIsCompassSynced(false);
                      speakInstruction("Map orientation locked to True North");
                    } else {
                      setIsCompassSynced(true);
                      setAutoRotate(true);
                      speakInstruction("Map orientation synchronized to device compass");
                    }
                  }}
                  className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                    isCompassSynced 
                      ? 'border-red-500 bg-red-500/10 text-red-500 font-extrabold' 
                      : isDark ? 'border-zinc-800 bg-black/20 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                  }`}
                  title="Compass alignment toggle"
                >
                  <div 
                    className="transition-transform duration-200 ease-out h-5 w-5 flex items-center justify-center"
                    style={{ transform: `rotate(${-mapRotation}deg)` }}
                  >
                    <svg viewBox="0 0 100 100" className="w-5 h-5">
                      <polygon points="50,15 35,55 50,45" fill="#ef4444" />
                      <polygon points="50,15 65,55 50,45" fill="#ea580c" />
                      <polygon points="50,85 35,55 50,45" fill="currentColor" fillOpacity="0.5" />
                      <polygon points="50,85 65,55 50,45" fill="currentColor" fillOpacity="0.3" />
                      <circle cx="50" cy="50" r="5" fill="currentColor" />
                    </svg>
                  </div>
                  <span className="text-[8px] font-mono font-bold leading-none mt-0.5">Compass {mapRotation !== 0 ? `${Math.round(mapRotation)}°` : 'Sync'}</span>
                </button>

                {/* B. Zoom info & Scale indicator */}
                <div 
                  className={`p-2 rounded-xl border flex flex-col items-center justify-center text-center select-none ${
                    isDark ? 'border-zinc-800 bg-black/20 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                  }`}
                >
                  <span className="text-[10px] font-mono font-black text-emerald-500 leading-none">Z{mapZoom}</span>
                  <span className="text-[7px] font-mono font-semibold mt-1 opacity-75">{getTraditionalScale(mapZoom)}</span>
                </div>

                {/* C. Follow User Toggle */}
                <button
                  onClick={() => {
                    const nextFollow = !followUser;
                    setFollowUser(nextFollow);
                    if (nextFollow && mapRef.current) {
                      mapRef.current.easeTo({ center: [currentGPS.lng, currentGPS.lat], zoom: 15 });
                    }
                  }}
                  className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                    followUser 
                      ? 'border-[#00E676] bg-[#00E676]/10 text-[#00E676] font-extrabold shadow-[0_0_8px_rgba(0,230,118,0.25)]' 
                      : isDark ? 'border-zinc-800 bg-black/20 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                  }`}
                  title="Follow GPS Center"
                >
                  <Navigation className={`h-4.5 w-4.5 ${followUser ? 'fill-current' : ''}`} />
                  <span className="text-[8px] font-mono font-bold leading-none mt-0.5">GPS {followUser ? 'ON' : 'OFF'}</span>
                </button>
              </div>

              {/* 2. Map Styles Row/Grid (Standard, Satellite, Hybrid, Terrain, Dark, Light) */}
              <div className="flex flex-col gap-1.5 border-b border-zinc-800/10 dark:border-zinc-800 pb-2.5">
                <span className="text-[8px] font-mono font-black text-zinc-400 uppercase tracking-widest text-left pl-1">Map Layers (Styles)</span>
                <div className="grid grid-cols-3 gap-1.5 text-[8.5px] font-bold font-mono">
                  {[
                    { id: 'standard', label: 'Street', icon: '🗺️' },
                    { id: 'satellite', label: 'Satellite', icon: '🛰️' },
                    { id: 'hybrid', label: 'Hybrid', icon: '🌀' },
                    { id: 'terrain', label: 'Terrain', icon: '🏔️' },
                    { id: 'dark', label: 'Dark Mode', icon: '🌑' },
                    { id: 'light', label: 'Light Mode', icon: '☀️' },
                  ].map((style) => (
                    <button
                      key={style.id}
                      type="button"
                      onClick={() => {
                        setMapType(style.id as any);
                        speakInstruction(`Switched to ${style.label} map view`);
                      }}
                      className={`p-1.5 rounded-lg border flex items-center justify-start gap-1 cursor-pointer transition-all ${
                        mapType === style.id
                          ? 'border-[#00E676] bg-[#00E676]/10 text-[#00E676] font-extrabold'
                          : isDark
                            ? 'border-zinc-800/50 bg-black/15 text-zinc-400 hover:text-white'
                            : 'border-gray-200 bg-gray-50 text-gray-600 hover:text-zinc-900'
                      }`}
                    >
                      <span className="text-xs">{style.icon}</span>
                      <span className="truncate">{style.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Extra Tools Grid */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[8px] font-mono font-black text-zinc-400 uppercase tracking-widest text-left pl-1">System Utilities</span>
                <div className="grid grid-cols-3 gap-2 text-center text-[9px] font-bold font-mono">
                  {/* Create Waypoint */}
                  <button
                    type="button"
                    onClick={() => {
                      setIsPlacingWaypoint(!isPlacingWaypoint);
                      setQuickActionsOpen(false);
                      speakInstruction(isPlacingWaypoint ? "Cancelled waypoint placement" : "Select coordinates on map to create waypoint");
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                      isPlacingWaypoint 
                        ? 'border-sky-500 bg-sky-500/10 text-sky-400 font-extrabold shadow-[0_0_8px_rgba(56,189,248,0.3)]' 
                        : isDark ? 'border-zinc-800/60 bg-black/25 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <MapPin className="h-4 w-4 text-sky-400" />
                    <span className="leading-tight mt-0.5">Waypoint</span>
                  </button>

                  {/* SOS */}
                  <button
                    type="button"
                    onClick={() => {
                      const sosBtn = document.getElementById('btn-global-sos');
                      if (sosBtn) {
                        sosBtn.click();
                      } else {
                        window.dispatchEvent(new CustomEvent('peezigator_sos', { detail: true }));
                      }
                      setQuickActionsOpen(false);
                      speakInstruction("Emergency SOS signal broadcasted");
                    }}
                    className="p-2 rounded-xl border border-red-500/30 bg-red-950/20 text-red-400 flex flex-col items-center justify-center gap-1 cursor-pointer animate-pulse"
                  >
                    <ShieldAlert className="h-4 w-4 text-red-500" />
                    <span className="leading-tight mt-0.5 text-red-500">SOS</span>
                  </button>

                  {/* Offline maps Toggle */}
                  <button
                    type="button"
                    onClick={() => {
                      if (onUpdateSettings) {
                        onUpdateSettings({ ...settings, offlineModeActive: !settings.offlineModeActive });
                        speakInstruction(settings.offlineModeActive ? "Online connectivity restored" : "Offline Maps mode engaged");
                      }
                      setQuickActionsOpen(false);
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                      settings.offlineModeActive 
                        ? 'border-amber-500 bg-amber-500/10 text-amber-400 font-extrabold shadow-[0_0_8px_rgba(245,158,11,0.3)]' 
                        : isDark ? 'border-zinc-800/60 bg-black/25 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <CloudOff className="h-4 w-4 text-amber-500" />
                    <span className="leading-tight mt-0.5">Offline</span>
                  </button>

                  {/* Trips */}
                  <button
                    type="button"
                    onClick={() => {
                      onActivePanelChange?.('trips');
                      setQuickActionsOpen(false);
                      speakInstruction("Opening saved trips panel");
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                      isDark ? 'border-zinc-800/60 bg-black/25 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <Compass className="h-4 w-4 text-indigo-400" />
                    <span className="leading-tight mt-0.5">Trips</span>
                  </button>

                  {/* Nav Tools (Route Builder) */}
                  <button
                    type="button"
                    onClick={() => {
                      onToggleRouteBuilder(!routeBuilderActive);
                      setQuickActionsOpen(false);
                      speakInstruction(routeBuilderActive ? "Route building tools disabled" : "Route building tools activated");
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                      routeBuilderActive 
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-extrabold shadow-[0_0_8px_rgba(16,185,129,0.3)]' 
                        : isDark ? 'border-zinc-800/60 bg-black/25 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <Navigation className="h-4 w-4 text-sky-400" />
                    <span className="leading-tight mt-0.5">Nav Tools</span>
                  </button>

                  {/* Downloads */}
                  <button
                    type="button"
                    onClick={() => {
                      onActivePanelChange?.('downloads');
                      setQuickActionsOpen(false);
                      speakInstruction("Opening download region offline panel");
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                      isDark ? 'border-zinc-800/60 bg-black/25 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <Download className="h-4 w-4 text-teal-400" />
                    <span className="leading-tight mt-0.5">Packs</span>
                  </button>

                  {/* Telemetry */}
                  <button
                    type="button"
                    onClick={() => {
                      onActivePanelChange?.('telemetry');
                      setQuickActionsOpen(false);
                      speakInstruction("Opening navigation telemetry stats");
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                      isDark ? 'border-zinc-800/60 bg-black/25 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <Activity className="h-4 w-4 text-emerald-400" />
                    <span className="leading-tight mt-0.5">Telemetry</span>
                  </button>

                  {/* Diagnostics */}
                  <button
                    type="button"
                    onClick={() => {
                      setIsDiagnosticsOpen(true);
                      setQuickActionsOpen(false);
                      speakInstruction("Opening advanced GPS receiver diagnostics");
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                      isDiagnosticsOpen 
                        ? 'border-purple-500 bg-purple-500/10 text-purple-400 font-extrabold shadow-[0_0_8px_rgba(168,85,247,0.3)]' 
                        : isDark ? 'border-zinc-800/60 bg-black/25 text-zinc-300' : 'border-gray-200 bg-gray-50 text-gray-700'
                    }`}
                  >
                    <Radio className="h-4 w-4 text-emerald-400" />
                    <span className="leading-tight mt-0.5">Diagnostics</span>
                  </button>

                  {/* Close Action Menu */}
                  <button
                    type="button"
                    onClick={() => setQuickActionsOpen(false)}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                      isDark ? 'border-zinc-800 bg-black/25 text-red-400 hover:bg-zinc-900' : 'border-gray-200 bg-gray-50 text-red-500 hover:bg-gray-100'
                    }`}
                  >
                    <span className="text-sm font-black">✕</span>
                    <span className="leading-tight mt-0.5">Collapse</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* ACTIVE NAVIGATION OR LOCATION DETAILED DRAGGABLE SHEET     */}
      {/* ========================================================= */}
      {droppedPin && (
        <div className={`absolute bottom-0 left-0 right-0 z-40 ${
          isDark ? 'bg-[#030712] border-t border-zinc-900' : 'bg-white border-t border-gray-200'
        } rounded-t-[32px] shadow-[0_-15px_40px_rgba(0,0,0,0.5)] flex flex-col select-none transition-all duration-300 font-sans relative ${
          isBottomSheetExpanded ? 'h-[420px]' : 'h-[180px]'
        }`}>
          {/* Circular 48dp Close button in the top-right corner of bottom sheet */}
          <button
            onClick={() => {
              setDroppedPin(null);
              setCalculatedRoute([]);
              setIsBottomSheetExpanded(false);
            }}
            className={`absolute top-4 right-4 z-50 h-12 w-12 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 active:scale-95 shadow-xl border focus:outline-none ${
              isDark 
                ? 'bg-zinc-950 border-emerald-900/50 text-emerald-400 hover:bg-zinc-900 hover:text-emerald-300 shadow-emerald-950/20' 
                : 'bg-white border-gray-200 text-sky-850 hover:bg-gray-50 hover:text-sky-650 shadow-gray-200/50'
            }`}
            style={{ minWidth: '48px', minHeight: '48px' }}
            aria-label="Dismiss bottom sheet"
            title="Dismiss"
          >
            <X className="h-5 w-5 stroke-[2.5]" />
          </button>

          {/* Draggable Drag-Handle Area */}
          <div 
            onClick={() => setIsBottomSheetExpanded(!isBottomSheetExpanded)}
            className="w-full h-7 flex items-center justify-center cursor-pointer shrink-0"
          >
            <div className={`w-14 h-1.5 rounded-full ${isDark ? 'bg-zinc-800' : 'bg-gray-300'}`} />
          </div>

          {/* Collapsed Bottom Sheet header (Place name, coordinates, primary actions) */}
          <div className="px-5 pb-2.5 pr-18 flex justify-between items-start gap-4 shrink-0">
            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-mono text-emerald-500 font-bold uppercase tracking-wider block">
                TAPPED GRID COORDINATES
              </span>
              <h3 className="text-base font-black truncate tracking-tight">
                {getStablePlaceName(droppedPin.lat, droppedPin.lng)}
              </h3>
              <p className="text-xs font-mono text-zinc-500 mt-0.5">
                {droppedPin.lat.toFixed(6)}°N, {droppedPin.lng.toFixed(6)}°E
              </p>
            </div>

            {/* Quick Go / Stop navigation */}
            <div className="flex items-center gap-2 font-mono shrink-0">
              {!navigationActive ? (
                <button
                  onClick={() => onToggleNavigation(true)}
                  className="h-10 px-4 bg-emerald-500 hover:bg-emerald-600 text-black font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <Play className="h-3 w-3 fill-black text-black" /> GO
                </button>
              ) : (
                <button
                  onClick={() => onToggleNavigation(false)}
                  className="h-10 px-4 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <Square className="h-3 w-3 fill-white" /> STOP
                </button>
              )}
            </div>
          </div>

          {/* Scrollable details of the bottom sheet (only visible when expanded) */}
          {isBottomSheetExpanded && (
            <div className="flex-1 overflow-y-auto px-5 pb-5 space-y-4 font-mono animate-in fade-in duration-200">
              <hr className="border-zinc-800/10" />

              <div className="grid grid-cols-2 gap-3 text-xs">
                {/* Elevation */}
                <div className={`p-3 rounded-xl ${isDark ? 'bg-zinc-950/50' : 'bg-gray-100/50'}`}>
                  <span className="text-[9px] text-zinc-500 font-bold block uppercase">ELEVATION</span>
                  <span className="text-[13px] font-black mt-1 block">
                    {getStableElevation(droppedPin.lat, droppedPin.lng)}
                  </span>
                </div>

                {/* Terrain Type */}
                <div className={`p-3 rounded-xl ${isDark ? 'bg-zinc-950/50' : 'bg-gray-100/50'}`}>
                  <span className="text-[9px] text-zinc-500 font-bold block uppercase">TERRAIN TYPE</span>
                  <span className="text-[12px] font-black mt-1 block truncate">
                    {getStableTerrain(droppedPin.lat, droppedPin.lng)}
                  </span>
                </div>

                {/* Haversine Distance */}
                <div className={`p-3 rounded-xl ${isDark ? 'bg-zinc-950/50' : 'bg-gray-100/50'}`}>
                  <span className="text-[9px] text-zinc-500 font-bold block uppercase">HAIVERSINE RANGE</span>
                  <span className="text-[13px] font-black mt-1 block text-amber-500">
                    {settings.distanceUnit === 'miles' 
                      ? `${(getHaversineDistance([currentGPS?.lat ?? 24.1940, currentGPS?.lng ?? 21.7366], [droppedPin.lat, droppedPin.lng]) * 0.621371).toFixed(2)} mi` 
                      : `${getHaversineDistance([currentGPS?.lat ?? 24.1940, currentGPS?.lng ?? 21.7366], [droppedPin.lat, droppedPin.lng]).toFixed(2)} km`
                    }
                  </span>
                </div>

                {/* Simulated Region status */}
                <div className={`p-3 rounded-xl ${isDark ? 'bg-zinc-950/50' : 'bg-gray-100/50'}`}>
                  <span className="text-[9px] text-zinc-500 font-bold block uppercase">CACHED STATUS</span>
                  <span className={`text-[11px] font-bold mt-1 block ${
                    checkCoordinatesIsDownloaded(droppedPin.lat, droppedPin.lng) ? 'text-emerald-400' : 'text-yellow-500'
                  }`}>
                    {checkCoordinatesIsDownloaded(droppedPin.lat, droppedPin.lng) ? '✓ CACHED OFFLINE' : '⚠️ ONLINE ONLY'}
                  </span>
                </div>
              </div>

              {/* Expandable detailed buttons */}
              <div className="flex gap-2.5 pt-2 text-xs">
                {/* Save Waypoint Button */}
                <button
                  onClick={() => {
                    const canvasPos = coordsToCanvas(droppedPin.lat, droppedPin.lng);
                    onMapClickToAddWaypoint(
                      parseFloat(canvasPos.x.toFixed(1)),
                      parseFloat(canvasPos.y.toFixed(1)),
                      droppedPin.lat,
                      droppedPin.lng
                    );
                    setDroppedPin(null);
                    setIsBottomSheetExpanded(false);
                  }}
                  className="flex-1 py-3 bg-zinc-900 border border-zinc-800 text-gray-300 font-extrabold rounded-xl hover:bg-zinc-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer uppercase text-[10px]"
                >
                  <Save className="h-3.5 w-3.5 text-emerald-500" /> Save Pin
                </button>

                {/* Share Coordinates */}
                <button
                  onClick={() => handleShareCoords(droppedPin.lat, droppedPin.lng)}
                  className="flex-1 py-3 bg-zinc-900 border border-zinc-800 text-gray-300 font-extrabold rounded-xl hover:bg-zinc-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer uppercase text-[10px]"
                >
                  <Share2 className="h-3.5 w-3.5 text-sky-400" /> Share Pin
                </button>

                {/* Dismiss */}
                <button
                  onClick={() => {
                    setDroppedPin(null);
                    setCalculatedRoute([]);
                    setIsBottomSheetExpanded(false);
                  }}
                  className="px-4 py-3 bg-red-950/20 border border-red-900 text-red-400 font-extrabold rounded-xl hover:bg-red-950/45 transition-colors flex items-center justify-center cursor-pointer uppercase text-[10px]"
                >
                  Dismiss
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* ACTIVE TURN-BY-TURN HUD FOR TOP HEADER                    */}
      {/* ========================================================= */}
      {droppedPin && navigationActive && (
        <div className="absolute top-[68px] left-4 right-4 z-40 animate-in slide-in-from-top duration-300">
          <div 
            className={`h-[72px] px-4 rounded-2xl border shadow-xl flex items-center gap-3.5 backdrop-blur-md transition-all ${
              isDark ? 'border-emerald-500/40 bg-zinc-950/92 text-white' : 'border-sky-300 bg-white/95 text-zinc-900'
            }`}
            style={{ maxHeight: '80px' }}
          >
            {/* Next Turn Icon */}
            <div className={`h-11 w-11 shrink-0 rounded-xl flex items-center justify-center font-black text-xl border animate-pulse ${
              isDark 
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-400' 
                : 'bg-sky-100 border-sky-300 text-sky-800'
            }`}>
              {navNextInstruction.toLowerCase().includes('left') ? '↰' : 
               navNextInstruction.toLowerCase().includes('right') ? '↱' : 
               navNextInstruction.toLowerCase().includes('welcome') || navNextInstruction.toLowerCase().includes('arrived') ? '★' : '▲'}
            </div>
            
            {/* Instruction details */}
            <div className="flex-1 min-w-0 font-mono">
              <div className="flex items-center gap-1.5">
                <span className="text-[8.5px] tracking-widest text-emerald-400 font-bold uppercase leading-none block">
                  NEXT ROUTING CUE
                </span>
                <span className="text-[10px] text-gray-400 font-bold block bg-zinc-900/40 px-1 py-0.5 rounded border border-zinc-800/20">
                  {navDistanceRemaining > 0.5 
                    ? `${(navDistanceRemaining * 0.35).toFixed(1)} ${settings.distanceUnit === 'miles' ? 'mi' : 'km'}` 
                    : `${Math.round(navDistanceRemaining * 400)} m`
                  }
                </span>
              </div>
              <p className="text-[11px] font-black leading-snug truncate mt-0.5 text-ellipsis">
                {navNextInstruction}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* REAL-TIME DYNAMIC ZOOM & DISTANCE SCALE HUD (Bottom Left) */}
      {/* ========================================================= */}
      <div 
        className={`absolute left-6 z-30 pointer-events-auto select-none transition-all duration-300 p-2.5 rounded-xl border shadow-2xl flex flex-col gap-2 max-w-[150px] ${cardBgClass} ${
          activePanel !== 'map' 
            ? 'bottom-4' 
            : (droppedPin ? 'bottom-52' : 'bottom-24')
        }`}
      >
        <div className="flex flex-col gap-1 text-[9px] font-mono leading-none tracking-wider font-bold">
          <div className="flex items-center justify-between border-b border-zinc-850/20 dark:border-zinc-800/40 pb-1.5 mb-0.5">
            <span className="text-zinc-400">ZOOM:</span>
            <span className="text-emerald-500 font-black">Z{mapZoom}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-zinc-400">SCALE:</span>
            <span className="text-zinc-350">{getTraditionalScale(mapZoom)}</span>
          </div>
        </div>

        {scaleData && (
          <div className="flex flex-col items-center border-t border-zinc-850/20 dark:border-zinc-800/40 pt-1.5" style={{ width: `${Math.max(scaleData.width, 80)}px` }}>
            {/* Scale Label */}
            <span className="text-[8px] font-mono font-bold tracking-tight mb-1 whitespace-nowrap opacity-85">
              {scaleData.label}
            </span>
            
            {/* Graphic Scale Bar */}
            <div className="w-full flex items-end">
              {/* Left Notch */}
              <div className={`w-[2px] h-1.5 ${isDark ? 'bg-green-400' : 'bg-zinc-850'}`} style={{ minWidth: '2px' }}></div>
              {/* Horizontal Line */}
              <div className={`flex-1 h-[2px] ${isDark ? 'bg-green-400' : 'bg-zinc-850'}`}></div>
              {/* Right Notch */}
              <div className={`w-[2px] h-1.5 ${isDark ? 'bg-green-400' : 'bg-zinc-850'}`} style={{ minWidth: '2px' }}></div>
            </div>
          </div>
        )}
      </div>

      {/* GPS DIAGNOSTICS MODAL OVERLAY */}
      {isDiagnosticsOpen && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className={`w-full max-w-md rounded-3xl border p-6 flex flex-col shadow-2xl relative font-sans ${
            isDark ? 'bg-zinc-950 border-emerald-900/50 text-white' : 'bg-white border-gray-200 text-zinc-900'
          }`}>
            {/* Header */}
            <div className="flex items-center justify-between border-b border-zinc-800/10 pb-4 mb-4 pr-14 shrink-0 relative">
              <div className="flex items-center gap-2.5">
                <span className="text-xl">📡</span>
                <div className="text-left">
                  <h3 className="text-xs font-black font-mono tracking-widest uppercase text-emerald-500">
                    GPS RECEIVER DIAGNOSTICS
                  </h3>
                  <p className="text-[9px] font-mono text-zinc-500 uppercase">
                    Receiver hardware telemetry & state
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsDiagnosticsOpen(false)}
                className={`absolute top-0 right-0 h-12 w-12 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 active:scale-95 shadow-xl border focus:outline-none ${
                  isDark 
                    ? 'bg-zinc-950 border-emerald-900/50 text-emerald-400 hover:bg-zinc-900 hover:text-emerald-300 shadow-emerald-950/20' 
                    : 'bg-white border-gray-200 text-sky-850 hover:bg-gray-50 hover:text-sky-650 shadow-gray-200/50'
                }`}
                style={{ minWidth: '48px', minHeight: '48px' }}
                aria-label="Close Diagnostics"
                title="Close"
              >
                <X className="h-5 w-5 stroke-[2.5]" />
              </button>
            </div>

            {/* Diagnostic Fields */}
            <div className="flex-1 overflow-y-auto space-y-4 font-mono text-xs pr-1">
              
              {/* Overall status row */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-zinc-900/10 dark:bg-black/40 border border-zinc-800/10">
                <span className="font-bold text-zinc-500">RECEIVER STATE:</span>
                <div className="flex items-center gap-2">
                  <span className={`h-2.5 w-2.5 rounded-full ${(!gpsLoading || gpsSourceState === 'simulated') && !permissionDenied && !gpsDisabled ? 'bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]' : 'bg-amber-500 animate-pulse shadow-[0_0_8px_rgba(245,158,11,0.6)]'}`} />
                  <span className={`font-black uppercase text-[11px] ${(!gpsLoading || gpsSourceState === 'simulated') && !permissionDenied && !gpsDisabled ? 'text-emerald-400' : 'text-amber-500'}`}>
                    {((!gpsLoading || gpsSourceState === 'simulated') && !permissionDenied && !gpsDisabled) ? 'Connected' : 'Searching'}
                  </span>
                </div>
              </div>

              {/* Grid System / Signal Stats */}
              <div className="space-y-2 border border-zinc-800/10 rounded-2xl p-4 text-left">
                <span className="text-[9px] font-bold text-zinc-500 block uppercase tracking-wider">Telemetry Link</span>
                
                <div className="flex justify-between py-1 border-b border-zinc-800/5 last:border-b-0">
                  <span className="text-zinc-500">PROVIDER:</span>
                  <span className="font-black text-zinc-400 uppercase text-right">
                    {gpsSourceState === 'real' ? 'HTML5 Fused Location' : 'Simulated GPS Track'}
                  </span>
                </div>

                <div className="flex justify-between py-1 border-b border-zinc-800/5 last:border-b-0">
                  <span className="text-zinc-500">SIGNAL FEED:</span>
                  <span className="font-black text-zinc-400 uppercase text-right">
                    {gpsSourceState === 'real' ? 'Hardware GPS Chipset' : 'Simulated Waveform'}
                  </span>
                </div>

                <div className="flex justify-between py-1 border-b border-zinc-800/5 last:border-b-0">
                  <span className="text-zinc-500">SATELLITE FIX:</span>
                  <span className="font-black text-emerald-400 text-right">
                    {((!gpsLoading || gpsSourceState === 'simulated') && !permissionDenied && !gpsDisabled) ? '3D ACCURATE LOCK' : 'ACQUIRING FIX...'}
                  </span>
                </div>

                <div className="flex justify-between py-1 border-b border-zinc-800/5 last:border-b-0">
                  <span className="text-zinc-500">SATELLITES:</span>
                  <span className="font-black text-zinc-300 text-right">
                    {((!gpsLoading || gpsSourceState === 'simulated') && !permissionDenied && !gpsDisabled) 
                      ? (gpsSourceState === 'real' ? '14 LOCKED' : '16 SIMULATED') 
                      : 'SEARCHING SKY...'
                    }
                  </span>
                </div>
              </div>

              {/* Hardware Data Metrics */}
              <div className="space-y-2 border border-zinc-800/10 rounded-2xl p-4 text-left">
                <span className="text-[9px] font-bold text-zinc-500 block uppercase tracking-wider">Spatial Data Metrics</span>
                
                <div className="flex justify-between py-0.5">
                  <span className="text-zinc-500">LATITUDE:</span>
                  <span className="font-bold text-right">{(currentGPS?.lat || 24.1940).toFixed(6)}° N</span>
                </div>

                <div className="flex justify-between py-0.5">
                  <span className="text-zinc-500">LONGITUDE:</span>
                  <span className="font-bold text-right">{(currentGPS?.lng || 21.7366).toFixed(6)}° E</span>
                </div>

                <div className="flex justify-between py-0.5">
                  <span className="text-zinc-500">ACCURACY:</span>
                  <span className="font-bold text-sky-400 text-right">{currentAccuracy} m</span>
                </div>

                <div className="flex justify-between py-0.5">
                  <span className="text-zinc-500">ALTITUDE:</span>
                  <span className="font-bold text-right">
                    {settings.distanceUnit === 'miles' 
                      ? `${Math.round(currentAltitude * 3.28084).toLocaleString()} ft` 
                      : `${currentAltitude.toLocaleString()} m`
                    }
                  </span>
                </div>

                <div className="flex justify-between py-0.5">
                  <span className="text-zinc-500">CURRENT SPEED:</span>
                  <span className="font-bold text-right">
                    {settings.distanceUnit === 'miles' 
                      ? `${Math.round(currentSpeed * 0.621371)} mph` 
                      : `${currentSpeed} km/h`
                    }
                  </span>
                </div>

                <div className="flex justify-between py-0.5">
                  <span className="text-zinc-500">BEARING / HEADING:</span>
                  <span className="font-bold text-right">{currentGPS.heading || 0}° (True North)</span>
                </div>
              </div>

              {/* Status / Checks */}
              <div className="space-y-2 border border-zinc-800/10 rounded-2xl p-4 text-left">
                <span className="text-[9px] font-bold text-zinc-500 block uppercase tracking-wider">Permissions & Access</span>
                
                <div className="flex justify-between py-0.5">
                  <span className="text-zinc-500">ACCESS_FINE_LOCATION:</span>
                  <span className={`font-extrabold text-right ${permissionDenied ? 'text-red-500' : 'text-emerald-500'}`}>
                    {permissionDenied ? 'DENIED' : 'GRANTED'}
                  </span>
                </div>

                <div className="flex justify-between py-0.5">
                  <span className="text-zinc-500">HARDWARE RECEIVER:</span>
                  <span className={`font-extrabold text-right ${gpsDisabled ? 'text-amber-500' : 'text-emerald-500'}`}>
                    {gpsDisabled ? 'OFFLINE / SEARCHING' : 'ACTIVE'}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Actions Footer */}
            <div className="mt-5 pt-4 border-t border-zinc-800/10 flex gap-2.5 shrink-0 text-xs font-mono">
              <button
                type="button"
                onClick={() => {
                  toggleGpsSource();
                }}
                className="flex-1 py-3 bg-zinc-900 hover:bg-zinc-850 dark:bg-zinc-900 border border-zinc-800/80 text-zinc-350 hover:text-white font-bold uppercase rounded-xl transition-all cursor-pointer text-center text-[10px]"
              >
                Toggle {gpsSourceState === 'real' ? 'Simulated' : 'Real'} Mode
              </button>
              <button
                type="button"
                onClick={() => setIsDiagnosticsOpen(false)}
                className="flex-1 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90 text-black font-extrabold uppercase rounded-xl transition-all cursor-pointer text-center text-[10px]"
              >
                Close Logs
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
