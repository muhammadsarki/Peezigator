/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  User as UserIcon, Camera, Save, Info, Compass, Volume2, VolumeX, 
  Shield, Moon, Sun, CloudOff, Bell, Settings, Award, MapPin, Map, Navigation
} from 'lucide-react';
import { User, AppSettings } from '../types';
import { safeStorage } from '../utils/storage';

interface AuthModalProps {
  currentUser: User | null;
  onLogin?: (user: User) => void;
  onLogout?: () => void;
  onUpdateProfile: (updatedUser: User) => void;
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
  voiceLanguage?: string;
  onSetVoiceLanguage?: (lang: string) => void;
  voiceVolume?: number;
  onSetVoiceVolume?: (volume: number) => void;
  voiceMuted?: boolean;
  onSetVoiceMuted?: (muted: boolean) => void;
}

const PRESET_AVATARS = [
  '🏔️', '🏜️', '🌲', '⛺', '🧭', '🛶', '🎒', '🥾', '🦅', '🦁', '🌊', '⚓'
];

const LANGUAGES = [
  { code: 'en-US', label: 'English (US)' },
  { code: 'es-ES', label: 'Español' },
  { code: 'fr-FR', label: 'Français' },
  { code: 'de-DE', label: 'Deutsch' },
];

export default function AuthModal({
  currentUser,
  onUpdateProfile,
  settings,
  onUpdateSettings,
  voiceLanguage = 'en-US',
  onSetVoiceLanguage,
  voiceVolume = 0.85,
  onSetVoiceVolume,
  voiceMuted = false,
  onSetVoiceMuted,
}: AuthModalProps) {
  const isDark = settings.theme === 'dark';
  const [profileTab, setProfileTab] = useState<'profile' | 'settings'>('profile');
  
  // Profile editing fields
  const [editName, setEditName] = useState<string>(currentUser?.fullName || 'Offline Explorer');
  const [editAvatar, setEditAvatar] = useState<string>(currentUser?.profilePhoto || '🥾');
  const [successMessage, setSuccessMessage] = useState<string>('');

  React.useEffect(() => {
    if (currentUser) {
      setEditName(currentUser.fullName);
      setEditAvatar(currentUser.profilePhoto);
    }
  }, [currentUser]);

  const handleUpdateProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const updated: User = {
      ...currentUser,
      fullName: editName,
      profilePhoto: editAvatar,
    };

    safeStorage.setItem('peezigator_active_explorer', JSON.stringify(updated));
    onUpdateProfile(updated);
    setSuccessMessage('Profile updated successfully.');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  // Preference Handlers
  const toggleTheme = () => {
    onUpdateSettings({
      ...settings,
      theme: isDark ? 'light' : 'dark',
    });
  };

  const toggleGPS = () => {
    onUpdateSettings({
      ...settings,
      gpsHighAccuracy: !settings.gpsHighAccuracy,
    });
  };

  const toggleUnit = (unit: 'km' | 'miles') => {
    onUpdateSettings({
      ...settings,
      distanceUnit: unit,
    });
  };

  const toggleNotifications = () => {
    onUpdateSettings({
      ...settings,
      notificationsEnabled: !settings.notificationsEnabled,
    });
  };

  const toggleOfflineMode = () => {
    onUpdateSettings({
      ...settings,
      offlineModeActive: !settings.offlineModeActive,
    });
  };

  const containerBg = isDark ? 'bg-[#030712] text-gray-100' : 'bg-gray-50 text-gray-800';
  const blockClass = isDark ? 'bg-zinc-900/60 border border-zinc-800/80 rounded-2xl p-4' : 'bg-white border border-gray-200 rounded-2xl p-4';
  const inputClass = `w-full px-4 py-2.5 rounded-xl border text-sm transition-all outline-none ${
    isDark
      ? 'bg-zinc-950 border-zinc-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-zinc-100'
      : 'bg-white border-gray-300 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-gray-800'
  }`;

  return (
    <div className={`p-4 max-w-md mx-auto h-full flex flex-col justify-start overflow-y-auto ${containerBg} font-sans`}>
      
      {/* Tab Switcher */}
      <div className="flex border-b border-zinc-800/10 mb-5 gap-2 p-1 bg-zinc-900/30 rounded-xl">
        <button
          onClick={() => setProfileTab('profile')}
          className={`flex-1 py-2.5 text-xs font-black uppercase tracking-wider rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-2 ${
            profileTab === 'profile'
              ? (isDark ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-sky-500/10 text-sky-800 border border-sky-500/10')
              : 'text-zinc-500 hover:text-zinc-400'
          }`}
        >
          <UserIcon className="h-3.5 w-3.5" />
          Explorer Profile
        </button>
        <button
          onClick={() => setProfileTab('settings')}
          className={`flex-1 py-2.5 text-xs font-black uppercase tracking-wider rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-2 ${
            profileTab === 'settings'
              ? (isDark ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-sky-500/10 text-sky-800 border border-sky-500/10')
              : 'text-zinc-500 hover:text-zinc-400'
          }`}
        >
          <Settings className="h-3.5 w-3.5" />
          App Preferences
        </button>
      </div>

      {profileTab === 'profile' ? (
        <div className="space-y-5 animate-in fade-in duration-250">
          
          {/* Main User Info Box */}
          <div className={`${blockClass} text-center space-y-4`}>
            {/* Explorer badge avatar */}
            <div className="relative inline-block mx-auto">
              <div className="w-20 h-20 rounded-full border-2 border-dashed border-zinc-700 flex items-center justify-center text-4xl bg-zinc-950 shadow-inner">
                {editAvatar}
              </div>
              <div className="absolute bottom-0 right-0 p-1.5 bg-emerald-500 rounded-full text-black border-2 border-zinc-950">
                <Award className="h-3.5 w-3.5" />
              </div>
            </div>

            <div>
              <h3 className="text-lg font-black tracking-tight">{currentUser?.fullName || 'Offline Explorer'}</h3>
              <p className="text-xs text-zinc-500 font-mono mt-0.5">{currentUser?.email || 'explorer@peezigator.offgrid'}</p>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-zinc-950/80 border border-zinc-800 text-[9px] font-mono font-bold text-emerald-500 mt-2.5 uppercase tracking-wider">
                ✓ OFFLINE GPS SYNCED
              </div>
            </div>
          </div>

          {/* Quick Statistics Stats Grid */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className={`${blockClass} p-3 flex flex-col justify-center items-center`}>
              <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase tracking-wider">PINS PLACED</span>
              <span className="text-xl font-black text-emerald-400 mt-1">12</span>
            </div>
            <div className={`${blockClass} p-3 flex flex-col justify-center items-center`}>
              <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase tracking-wider">EXPEDITIONS</span>
              <span className="text-xl font-black text-sky-400 mt-1">4</span>
            </div>
            <div className={`${blockClass} p-3 flex flex-col justify-center items-center`}>
              <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase tracking-wider">DISTANCE</span>
              <span className="text-[15px] font-black text-amber-400 mt-1.5 truncate">
                {settings.distanceUnit === 'miles' ? '28.1 mi' : '45.2 km'}
              </span>
            </div>
          </div>

          {/* Edit Form */}
          <form onSubmit={handleUpdateProfileSubmit} className={`${blockClass} space-y-4`}>
            <h4 className="text-[10px] font-mono text-zinc-500 font-black uppercase tracking-widest">EDIT IDENTITY</h4>

            {successMessage && (
              <div className="p-3 text-xs bg-emerald-950/20 border border-emerald-800 text-emerald-400 rounded-xl font-mono text-center">
                ✓ {successMessage}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-mono text-zinc-400 mb-1 font-bold uppercase">Explorer Call Sign</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className={inputClass}
                  placeholder="Explorer Name"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-zinc-400 mb-2 font-bold uppercase">Select Avatar Icon</label>
                <div className="grid grid-cols-6 gap-2 text-xl p-2 bg-black/20 rounded-xl border border-zinc-800">
                  {PRESET_AVATARS.map((avatar) => (
                    <button
                      key={avatar}
                      type="button"
                      onClick={() => setEditAvatar(avatar)}
                      className={`p-1.5 rounded-lg text-center transition-all cursor-pointer ${
                        editAvatar === avatar
                          ? 'bg-emerald-500/20 border border-emerald-500'
                          : 'opacity-60 hover:opacity-100'
                      }`}
                    >
                      {avatar}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-black font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Save className="h-4 w-4" /> Save Profile Details
            </button>
          </form>

        </div>
      ) : (
        /* Settings Tab View (Integrated preferences from SettingsPage.tsx) */
        <div className="space-y-4 animate-in fade-in duration-250 pb-6">
          
          {/* Global Distance Unit Card */}
          <div className={`${blockClass} space-y-3`}>
            <div className="flex items-start gap-3">
              <Compass className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider">Distance Unit Preference</h4>
                <p className="text-[11px] text-zinc-500 mt-0.5 leading-normal">
                  Toggle on-the-fly calculation of metric versus imperial mapping distances, scale metrics, and telemetry readings.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-2 text-xs font-semibold pt-1">
              <button
                type="button"
                onClick={() => toggleUnit('km')}
                className={`p-2.5 rounded-xl border transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                  settings.distanceUnit === 'km'
                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400 font-bold'
                    : 'border-zinc-800 hover:bg-zinc-800/40 text-zinc-400'
                }`}
              >
                <span className="text-[13px]">Metric (km)</span>
                <span className="text-[8px] uppercase tracking-wider font-mono opacity-60">Kilometers</span>
              </button>
              
              <button
                type="button"
                onClick={() => toggleUnit('miles')}
                className={`p-2.5 rounded-xl border transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                  settings.distanceUnit === 'miles'
                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400 font-bold'
                    : 'border-zinc-800 hover:bg-zinc-800/40 text-zinc-400'
                }`}
              >
                <span className="text-[13px]">Imperial (mi)</span>
                <span className="text-[8px] uppercase tracking-wider font-mono opacity-60">Miles</span>
              </button>
            </div>
          </div>

          {/* Offline Mode Switcher */}
          <div className={`${blockClass} flex items-center justify-between`}>
            <div className="space-y-0.5 pr-4">
              <h4 className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                <CloudOff className="h-4 w-4 text-amber-500" />
                SIMULATE DEEP OFFLINE STATE
              </h4>
              <p className="text-[11px] text-zinc-500 leading-normal">
                Locks down cellular networks. Maps only render from locally downloaded offline packages.
              </p>
            </div>
            <button
              type="button"
              onClick={toggleOfflineMode}
              className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                settings.offlineModeActive ? 'bg-amber-600' : 'bg-zinc-800'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.offlineModeActive ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Light / Dark Mode Toggle */}
          <div className={`${blockClass} space-y-3`}>
            <h4 className="text-xs font-black uppercase tracking-wider flex items-center gap-2">
              {isDark ? <Moon className="h-4 w-4 text-emerald-400" /> : <Sun className="h-4 w-4 text-amber-500" />}
              DISPLAY COLOUR MAP
            </h4>
            
            <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, theme: 'light' })}
                className={`p-2 rounded-xl border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  !isDark
                    ? 'bg-sky-500/10 border-sky-400 text-sky-800 font-bold'
                    : 'border-zinc-800 hover:bg-zinc-850 text-zinc-400'
                }`}
              >
                <Sun className="h-4 w-4" /> LIGHT BLUE
              </button>
              
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, theme: 'dark' })}
                className={`p-2 rounded-xl border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  isDark
                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400 font-bold'
                    : 'border-zinc-800 hover:bg-zinc-850 text-zinc-400'
                }`}
              >
                <Moon className="h-4 w-4" /> NIGHT VISION
              </button>
            </div>
          </div>

          {/* GPS Accuracy & Power Mode */}
          <div className={`${blockClass} space-y-3.5`}>
            <h4 className="text-xs font-black uppercase tracking-wider flex items-center gap-2">
              <Settings className="h-4 w-4 text-zinc-400" /> GPS & EXPEDITION ACCURACY
            </h4>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="block font-bold">Differential Satellites (GLONASS)</span>
                  <span className="block text-[10px] text-zinc-500">Increases receiver sensitivity in canopy/canyons.</span>
                </div>
                <button
                  type="button"
                  onClick={toggleGPS}
                  className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    settings.gpsHighAccuracy ? 'bg-emerald-500' : 'bg-zinc-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      settings.gpsHighAccuracy ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              <hr className="border-zinc-800/45" />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="block font-bold">Tactical Power Saver</span>
                  <span className="block text-[10px] text-zinc-500">Throttles telemetry checks to triple battery duration.</span>
                </div>
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ ...settings, powerSaverMode: !settings.powerSaverMode })}
                  className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    settings.powerSaverMode ? 'bg-emerald-500' : 'bg-zinc-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      settings.powerSaverMode ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Voice Announcements Settings */}
          <div className={`${blockClass} space-y-3.5`}>
            <h4 className="text-xs font-black uppercase tracking-wider flex items-center gap-2">
              {voiceMuted ? <VolumeX className="h-4 w-4 text-red-500 animate-pulse" /> : <Volume2 className="h-4 w-4 text-emerald-500" />}
              VOICE NAVIGATION ANNOUNCER
            </h4>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <span className="block font-bold">Mute Navigation Speech Cues</span>
                  <span className="block text-[10px] text-zinc-500 font-normal">Silences direct turn-by-turn alerts.</span>
                </div>
                <button
                  type="button"
                  onClick={() => onSetVoiceMuted?.(!voiceMuted)}
                  className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    voiceMuted ? 'bg-rose-600' : 'bg-emerald-500'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      !voiceMuted ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {!voiceMuted && (
                <>
                  <hr className="border-zinc-800/45" />

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span>Synthesizer Language:</span>
                      <select
                        value={voiceLanguage}
                        onChange={(e) => onSetVoiceLanguage?.(e.target.value)}
                        className="bg-zinc-950 border border-zinc-800 text-zinc-100 rounded px-2 py-1 text-[11px] font-bold outline-none cursor-pointer"
                      >
                        {LANGUAGES.map((lang) => (
                          <option key={lang.code} value={lang.code}>
                            {lang.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center justify-between gap-4 pt-1">
                      <span className="whitespace-nowrap">Volume:</span>
                      <input 
                        type="range"
                        min="0.1"
                        max="1.0"
                        step="0.1"
                        value={voiceVolume}
                        onChange={(e) => onSetVoiceVolume?.(parseFloat(e.target.value))}
                        className="flex-1 accent-emerald-500 h-1 rounded-lg bg-zinc-800 cursor-pointer"
                      />
                      <span className="font-bold font-mono text-[10px] text-zinc-400 w-8 text-right">
                        {Math.round(voiceVolume * 100)}%
                      </span>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Safety Disclaimer Warning */}
          <div className="p-3.5 bg-amber-500/5 border border-amber-500/20 rounded-2xl text-[10px] font-mono leading-relaxed text-amber-500/80 flex gap-2">
            <Info className="h-4 w-4 shrink-0 mt-0.5 text-amber-500" />
            <div>
              <strong>PEEZIGATOR OFF-GRID MANUAL SAFETY RULE:</strong>
              <p className="mt-0.5">
                Always carry a standard military compass and topographical printed paper maps. Never rely 100% on battery-dependent software coordinates in remote wild domains!
              </p>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
