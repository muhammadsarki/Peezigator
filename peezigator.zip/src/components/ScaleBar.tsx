import React, { useEffect, useState } from 'react';
import maplibregl from 'maplibre-gl';

interface ScaleBarProps {
  map: maplibregl.Map | null;
  isDark: boolean;
  distanceUnit?: 'miles' | 'kilometers';
}

export default function ScaleBar({ map, isDark, distanceUnit = 'kilometers' }: ScaleBarProps) {
  const [scaleData, setScaleData] = useState<{ width: number; label: string } | null>(null);

  useEffect(() => {
    if (!map) return;

    const updateScale = () => {
      const bounds = map.getBounds();
      const canvas = map.getCanvas();
      if (!bounds || !canvas) return;

      const canvasWidth = canvas.width;
      const lat = map.getCenter().lat;
      const west = bounds.getWest();
      const east = bounds.getEast();

      // Haversine distance horizontally across the map at the center latitude
      const R = 6371000; // Earth radius in meters
      const dLon = (east - west) * Math.PI / 180;
      const latRad = lat * Math.PI / 180;
      const a = Math.cos(latRad) * Math.cos(latRad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      const distanceInMeters = R * c;

      if (!distanceInMeters || isNaN(distanceInMeters)) return;

      const metersPerPixel = distanceInMeters / canvasWidth;
      
      // We want the scale bar to be around 100 pixels wide on screen.
      // But maplibregl canvas might have a devicePixelRatio factor. Let's adjust for physical vs display pixels if needed.
      const displayWidth = canvas.clientWidth || (canvasWidth / (window.devicePixelRatio || 1));
      const metersPerDisplayPixel = distanceInMeters / displayWidth;

      const targetPx = 100; // target width in display pixels
      const distanceAtTargetPx = metersPerDisplayPixel * targetPx;

      let chosenDistance = 0;
      let label = '';

      if (distanceUnit === 'miles') {
        const distanceInMiles = distanceAtTargetPx / 1609.344;
        if (distanceInMiles < 0.1) {
          const distanceInFeet = distanceAtTargetPx * 3.28084;
          const niceFeet = [10, 20, 50, 100, 200, 500];
          let feet = niceFeet[0];
          for (const f of niceFeet) {
            if (distanceInFeet >= f) feet = f;
          }
          chosenDistance = feet / 3.28084;
          label = `${feet} ft`;
        } else {
          const niceMiles = [0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500];
          let miles = niceMiles[0];
          for (const m of niceMiles) {
            if (distanceInMiles >= m) miles = m;
          }
          chosenDistance = miles * 1609.344;
          label = `${miles} mi`;
        }
      } else {
        if (distanceAtTargetPx < 1000) {
          const niceMeters = [1, 2, 5, 10, 20, 50, 100, 200, 500];
          let meters = niceMeters[0];
          for (const m of niceMeters) {
            if (distanceAtTargetPx >= m) meters = m;
          }
          chosenDistance = meters;
          label = `${meters} m`;
        } else {
          const distanceInKm = distanceAtTargetPx / 1000;
          const niceKm = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000];
          let km = niceKm[0];
          for (const k of niceKm) {
            if (distanceInKm >= k) km = k;
          }
          chosenDistance = km * 1000;
          label = `${km} km`;
        }
      }

      const width = (chosenDistance / metersPerDisplayPixel);
      setScaleData({
        width: Math.round(width),
        label
      });
    };

    // Initial update
    updateScale();

    // Event listeners
    map.on('zoom', updateScale);
    map.on('move', updateScale);
    map.on('resize', updateScale);

    return () => {
      map.off('zoom', updateScale);
      map.off('move', updateScale);
      map.off('resize', updateScale);
    };
  }, [map, distanceUnit]);

  if (!scaleData) return null;

  return (
    <div 
      id="map-scale-bar"
      className={`absolute bottom-24 left-4 z-30 select-none pointer-events-none flex flex-col items-start font-mono text-[8.5px] font-bold drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] ${
        isDark ? 'text-[#00E676]' : 'text-zinc-950'
      }`}
    >
      <span className="mb-0.5 tracking-wider font-extrabold uppercase">{scaleData.label}</span>
      <div className="h-1.5 border-x-2 border-b-2 border-current rounded-b-sm" style={{ width: `${scaleData.width}px` }} />
    </div>
  );
}
