/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Download, Trash2, HardDrive, CheckCircle2, RefreshCcw, Wifi, Server, Check } from 'lucide-react';
import { OfflineMap, AppSettings } from '../types';

interface DownloadManagerProps {
  offlineMaps: OfflineMap[];
  onDownloadMap: (id: string) => void;
  onDeleteMap: (id: string) => void;
  settings: AppSettings;
}

export default function DownloadManager({
  offlineMaps,
  onDownloadMap,
  onDeleteMap,
  settings,
}: DownloadManagerProps) {
  const isDark = settings.theme === 'dark';
  const [activeTab, setActiveTab] = useState<'all' | 'countries' | 'regions'>('all');
  const [autoUpdate, setAutoUpdate] = useState<boolean>(true);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Calculate active storage metrics
  const totalVolume = 10240; // 10 GB simulated storage capacity
  const downloadedSpace = parseFloat(
    offlineMaps
      .filter((m) => m.downloadStatus === 'downloaded')
      .reduce((sum, current) => sum + current.size, 0)
      .toFixed(1)
  );

  const percentageUsed = ((downloadedSpace / totalVolume) * 100).toFixed(1);

  // Filter maps based on country/region tabs
  const filteredMaps = offlineMaps.filter((m) => {
    if (activeTab === 'countries') return m.isCountry;
    if (activeTab === 'regions') return !m.isCountry;
    return true;
  });

  // Theme styling helpers
  const containerBg = isDark ? 'bg-[#08131F] text-white' : 'bg-zinc-50 text-zinc-900';
  const cardBorderClass = isDark ? 'border-zinc-800/80 bg-[#182433]' : 'border-zinc-200 bg-white';
  const inputBgClass = isDark ? 'bg-[#111827] border-zinc-800' : 'bg-white border-zinc-200';
  const textAccent = isDark ? 'text-[#00E676]' : 'text-[#00C853]';
  const progressBgClass = isDark ? 'bg-zinc-950/60' : 'bg-gray-200';
  const progressBarClass = isDark ? 'bg-[#00E676]' : 'bg-[#00C853]';

  return (
    <div className={`p-4 space-y-6 overflow-y-auto h-full flex flex-col justify-start ${containerBg}`}>
      
      {/* Device Storage Status Overview */}
      <div className={`p-5 rounded-2xl border ${cardBorderClass} shadow-md`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <HardDrive className={`h-5 w-5 ${textAccent}`} />
            <h3 className="font-bold text-sm tracking-wider uppercase">LOCAL OFFLINE STORAGE</h3>
          </div>
          <span className="text-[9px] font-mono font-bold bg-neutral-900/30 px-2 py-0.5 rounded border border-gray-700/10 text-gray-400">
            SECURE EX-FLASH CACHE
          </span>
        </div>

        {/* Progress indicator */}
        <div className={`h-3 w-full ${progressBgClass} rounded-full overflow-hidden border border-gray-750/30 mb-3`}>
          <div
            className={`h-full rounded-full transition-all duration-500 ${progressBarClass}`}
            style={{ width: `${Math.max(1, parseFloat(percentageUsed))}%` }}
          />
        </div>

        <div className="flex justify-between items-center text-[11px] font-mono text-gray-400">
          <div>
            Mapped Topo Memory: <span className="font-bold text-gray-200">{downloadedSpace} MB</span>
          </div>
          <div>
            Capacity: <span className="font-bold text-gray-200">10.0 GB</span> ({percentageUsed}% used)
          </div>
        </div>
      </div>

      {/* Auto update toggle */}
      <div className={`p-4 rounded-xl border flex items-center justify-between gap-4 text-xs font-mono ${cardBorderClass}`}>
        <div className="flex items-center gap-2.5">
          <Wifi className="h-4 w-4 text-sky-500 animate-pulse" />
          <div>
            <div className="font-bold">AUTOMATIC ONLINE SYNC</div>
            <div className="text-[10px] text-gray-500">Auto-update map vectors once cellular connection is restored</div>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setAutoUpdate(!autoUpdate)}
          className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out outline-none ${
            autoUpdate ? (isDark ? 'bg-green-500' : 'bg-sky-600') : 'bg-zinc-700'
          }`}
        >
          <span
            className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
              autoUpdate ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* Tabs configuration */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h4 className="text-sm font-sans font-extrabold uppercase tracking-widest text-[#00E676]">
            OFF-GRID MAP DATASETS
          </h4>
          
          <div className="flex bg-zinc-900/80 p-1 rounded-lg border border-zinc-800">
            {(['all', 'countries', 'regions'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1.5 text-[10px] uppercase font-bold rounded-md transition-colors cursor-pointer ${
                  activeTab === tab
                    ? (isDark ? 'bg-[#00E676] text-black font-black shadow-sm' : 'bg-[#00C853] text-white font-black shadow-sm')
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Vector Pack Registry Items */}
        <div className="grid grid-cols-1 gap-3">
          {filteredMaps.map((map) => {
            const isNotDownloaded = map.downloadStatus === 'not_downloaded';
            const isDownloading = map.downloadStatus === 'downloading';
            const isDownloaded = map.downloadStatus === 'downloaded';

            return (
              <div
                key={map.id}
                className={`flex flex-col p-4 rounded-xl border transition-all ${
                  isDownloaded
                    ? (isDark ? 'border-green-800 bg-emerald-990/5' : 'border-sky-150 bg-sky-50/15')
                    : isDownloading
                    ? (isDark ? 'border-yellow-850 bg-yellow-990/5 animate-pulse' : 'border-amber-200 bg-amber-50/20')
                    : (isDark ? 'border-gray-800 bg-zinc-950/40' : 'border-gray-200 hover:bg-gray-50')
                }`}
              >
                <div className="flex items-start justify-between gap-3 mb-1.5">
                  <div>
                    <h5 className="font-bold text-sm tracking-wide flex items-center gap-1.5 flex-wrap">
                      <span>{map.isCountry ? '🌍' : '🏔️'} {map.name}</span>
                      
                      <span className={`text-[8px] font-mono uppercase px-1.5 py-0.5 rounded ${
                        map.isCountry 
                          ? 'bg-purple-950/45 text-purple-400 border border-purple-900' 
                          : 'bg-zinc-800/85 text-zinc-400 border border-zinc-700'
                      }`}>
                        {map.isCountry ? 'Country Block' : 'Local Region'}
                      </span>

                      {isDownloaded && (
                        <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded font-extrabold flex items-center gap-1 ${
                          isDark ? 'bg-green-950 text-green-400 border border-green-805' : 'bg-sky-100 text-sky-700 border border-sky-150'
                        }`}>
                          <Check className="h-2 w-2" /> AVAILABLE
                        </span>
                      )}
                    </h5>
                    <p className="text-[10px] text-gray-400 mt-1 font-mono uppercase">{map.region}</p>
                  </div>

                  <span className="text-[10.5px] font-mono font-bold bg-zinc-800/10 border border-gray-750/30 px-2 py-0.5 rounded">
                    {map.size} MB
                  </span>
                </div>

                {/* Progress bar info for downloading status */}
                {isDownloading && (
                  <div className="my-2 p-1.5 rounded bg-zinc-900/35 border border-yellow-900/25 space-y-1">
                    <div className="flex justify-between items-center text-[10px] font-mono">
                      <span className="flex items-center gap-1.5 text-yellow-600 font-bold">
                        <RefreshCcw className="h-2.5 w-2.5 animate-spin" /> DOWNLOADING SYNC POINTERS...
                      </span>
                      <span className="text-yellow-500 font-bold">{map.progress}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-zinc-800/80 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-yellow-500 rounded-full transition-all duration-300"
                        style={{ width: `${map.progress}%` }}
                      />
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between border-t border-gray-700/10 mt-3 pt-3 gap-2 text-[10px] font-mono text-gray-500">
                  <div>
                    {isDownloaded ? (
                      <span>Vectored: <span className="font-semibold text-gray-400">{map.lastUpdated || '2026-06'}</span></span>
                    ) : (
                      <span className="truncate block max-w-[200px]">BBOX: X:{map.boundingBox.minX}-{map.boundingBox.maxX}, Y:{map.boundingBox.minY}-{map.boundingBox.maxY}</span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    {isNotDownloaded && (
                      <button
                        onClick={() => onDownloadMap(map.id)}
                        className={`px-2.5 py-1 rounded text-[10px] font-bold tracking-wider flex items-center gap-1 cursor-pointer transition-colors ${
                          isDark
                            ? 'bg-green-500 hover:bg-green-600 text-black'
                            : 'bg-[#006ca5] hover:bg-sky-800 text-white'
                        }`}
                      >
                        <Download className="h-3 w-3" /> DOWNLOAD
                      </button>
                    )}

                    {isDownloading && (
                      <span className="text-[9px] uppercase font-bold text-yellow-600 tracking-wider">
                        STREAMING FILES...
                      </span>
                    )}

                    {isDownloaded && (
                      <button
                        onClick={() => setConfirmDeleteId(map.id)}
                        className="p-1 rounded border border-rose-900/40 bg-rose-950/5 text-rose-400 hover:bg-rose-900 hover:text-white transition-all cursor-pointer"
                        title="Purge map from offline storage cache"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Confirmation Modal overlay */}
      {confirmDeleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className={`w-full max-w-sm rounded-2xl border p-5 shadow-2xl flex flex-col gap-4 ${isDark ? 'bg-zinc-950 border-rose-900 text-white' : 'bg-white border-red-200 text-zinc-900'}`}>
            <h3 className="text-sm font-black font-mono tracking-wider text-rose-500 uppercase flex items-center gap-1.5">
              ⚠️ CONFIRM PURGE DATASET
            </h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              Are you sure you want to delete the offline map dataset for <span className="font-bold text-gray-200">{offlineMaps.find(m => m.id === confirmDeleteId)?.name}</span>?
              <br/><br/>
              This will free up <span className="font-bold text-gray-200">{offlineMaps.find(m => m.id === confirmDeleteId)?.size} MB</span> but will remove all cached vector paths. You will require cellular data or Wi-Fi to load this territory again.
            </p>
            <div className="flex gap-2.5 mt-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteId(null)}
                className="flex-1 py-2 text-xs font-bold rounded-xl border border-zinc-700 hover:bg-zinc-900 transition-colors cursor-pointer text-center text-gray-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteMap(confirmDeleteId);
                  setConfirmDeleteId(null);
                }}
                className="flex-1 py-2 text-xs font-bold rounded-xl bg-red-600 hover:bg-red-700 text-white transition-colors cursor-pointer text-center"
              >
                Purge Dataset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
