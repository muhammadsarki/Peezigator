import React, { useState, useEffect, useRef } from 'react';
import { 
  Radio, Signal, RefreshCw, Check, CheckCircle2, Server, User, 
  Navigation, MapPin, AlertTriangle, Shield, CheckSquare, Search,
  Share2, ChevronRight, X, Heart, Power, Trash2, List, Pocket, Info
} from 'lucide-react';
import { Waypoint, Route } from '../types';

interface Peer {
  id: string;
  callsign: string;
  deviceType: 'Smartphone' | 'Tactical Console' | 'Emergency Beacon' | 'Satellite Router';
  distanceMeters: number;
  rssi: number;
  syncStatus: 'synced' | 'out_of_sync' | 'syncing';
  lastSynced: string;
  waypointsAvailable: number;
  routesAvailable: number;
  isOfficialRescue?: boolean;
}

interface P2PSyncPanelProps {
  routes: Route[];
  waypoints: Waypoint[];
  onSyncData: (newWaypoints: Waypoint[], newRoutes: Route[]) => void;
  isDark: boolean;
  addToast?: (msg: string) => void;
}

export default function P2PSyncPanel({
  routes,
  waypoints,
  onSyncData,
  isDark,
  addToast
}: P2PSyncPanelProps) {
  // BLE Settings states
  const [broadcastingEnabled, setBroadcastingEnabled] = useState<boolean>(() => {
    return localStorage.getItem('peezigator_p2p_broadcasting') !== 'false';
  });
  const [autoSyncEnabled, setAutoSyncEnabled] = useState<boolean>(() => {
    return localStorage.getItem('peezigator_p2p_autosync') !== 'false';
  });
  const [callsign, setCallsign] = useState<string>(() => {
    return localStorage.getItem('peezigator_p2p_callsign') || `EXPLORER-ALPHA-${Math.floor(10 + Math.random() * 90)}`;
  });

  // Share selection states
  const [selectedWps, setSelectedWps] = useState<Record<string, boolean>>({});
  const [selectedRts, setSelectedRts] = useState<Record<string, boolean>>({});

  // Scanning & Syncing operational states
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [activeSyncPeer, setActiveSyncPeer] = useState<Peer | null>(null);
  const [syncProgress, setSyncProgress] = useState<number>(0);
  const [syncStateMsg, setSyncStateMsg] = useState<string>('');
  
  // Nearby BLE nodes list
  const [peers, setPeers] = useState<Peer[]>([
    {
      id: 'p1',
      callsign: 'RESCUE-MEDIC-04',
      deviceType: 'Tactical Console',
      distanceMeters: 8,
      rssi: -52,
      syncStatus: 'out_of_sync',
      lastSynced: '2 hours ago',
      waypointsAvailable: 2,
      routesAvailable: 1,
      isOfficialRescue: true
    },
    {
      id: 'p2',
      callsign: 'OUTBACK-RANGER-9',
      deviceType: 'Emergency Beacon',
      distanceMeters: 22,
      rssi: -72,
      syncStatus: 'out_of_sync',
      lastSynced: 'Never',
      waypointsAvailable: 1,
      routesAvailable: 1,
      isOfficialRescue: true
    },
    {
      id: 'p3',
      callsign: 'WILDERNESS-EXPLORER-38',
      deviceType: 'Smartphone',
      distanceMeters: 45,
      rssi: -84,
      syncStatus: 'synced',
      lastSynced: '10 minutes ago',
      waypointsAvailable: 0,
      routesAvailable: 0
    }
  ]);

  // Terminal telemetry logs
  const [logs, setLogs] = useState<string[]>([
    `[${new Date().toLocaleTimeString()}] BLE_P2P_INIT: Peer-to-Peer Off-Grid Mesh Sync engine online.`,
    `[${new Date().toLocaleTimeString()}] BLE_GAP_ADV: Advertising active on Service UUID 0000fee7-0000-1000-8000-00805f9b34fb`,
    `[${new Date().toLocaleTimeString()}] BLE_GAP_SCAN: Automated background listener operational.`
  ]);

  const logContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll logs to bottom
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  // Persist settings
  useEffect(() => {
    localStorage.setItem('peezigator_p2p_broadcasting', String(broadcastingEnabled));
  }, [broadcastingEnabled]);

  useEffect(() => {
    localStorage.setItem('peezigator_p2p_autosync', String(autoSyncEnabled));
  }, [autoSyncEnabled]);

  useEffect(() => {
    localStorage.setItem('peezigator_p2p_callsign', callsign);
  }, [callsign]);

  // Pre-fill selection objects
  useEffect(() => {
    const initialWps: Record<string, boolean> = {};
    waypoints.forEach(wp => {
      initialWps[wp.id] = true;
    });
    setSelectedWps(initialWps);

    const initialRts: Record<string, boolean> = {};
    routes.forEach(rt => {
      initialRts[rt.id] = true;
    });
    setSelectedRts(initialRts);
  }, [waypoints, routes]);

  const appendLog = (msg: string) => {
    const timeStr = new Date().toLocaleTimeString();
    setLogs(prev => [...prev, `[${timeStr}] ${msg}`]);
  };

  const handleStartScan = () => {
    if (isScanning || isSyncing) return;
    setIsScanning(true);
    appendLog('BLE_GAP_DISCOVERY: Starting active physical RSSI probe (3000ms duration)...');

    // Simulate finding / updating peers
    setTimeout(() => {
      setPeers(prev => {
        return prev.map(p => {
          // Jitter the distance and rssi slightly to show real-time live data
          const rssiDelta = Math.floor(Math.random() * 7) - 3;
          const newRssi = Math.min(-40, Math.max(-95, p.rssi + rssiDelta));
          const newDistance = Math.max(2, Math.floor(newRssi * -0.45 - 15));
          return {
            ...p,
            rssi: newRssi,
            distanceMeters: newDistance,
            // Maybe open up a sync option
            syncStatus: p.syncStatus === 'synced' && Math.random() > 0.7 ? 'out_of_sync' : p.syncStatus
          };
        });
      });
      setIsScanning(false);
      appendLog('BLE_GAP_DISCOVERY: Active scan completed. 3 responsive off-grid BLE nodes found.');
      if (addToast) addToast('BLE P2P: Nearby nodes list refreshed');
    }, 2500);
  };

  // Background automated simulation loop
  useEffect(() => {
    if (!autoSyncEnabled) return;

    const interval = setInterval(() => {
      // Periodic background scanning simulator
      const r = Math.random();
      if (r < 0.15) {
        // Mock a background scan trigger
        appendLog('BLE_DAEMON: Running automated background mesh validation...');
        // Randomly tweak peer signal values
        setPeers(prev => prev.map(p => {
          const delta = Math.floor(Math.random() * 5) - 2;
          return {
            ...p,
            rssi: Math.min(-40, Math.max(-95, p.rssi + delta)),
            distanceMeters: Math.max(3, p.distanceMeters + (delta > 0 ? -1 : 1))
          };
        }));
      } else if (r < 0.25 && !isSyncing && !isScanning) {
        // Mock automatic sync with out_of_sync peer
        const targetPeer = peers.find(p => p.syncStatus === 'out_of_sync');
        if (targetPeer) {
          appendLog(`BLE_DAEMON: Found out-of-sync node '${targetPeer.callsign}' nearby. Initiating automated background merge...`);
          triggerSync(targetPeer, true);
        }
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [autoSyncEnabled, peers, isSyncing, isScanning]);

  // Actual BLE sync handler (simulated GATT handshake and merge)
  const triggerSync = (peer: Peer, isBackground = false) => {
    if (isSyncing) return;
    setIsSyncing(true);
    setActiveSyncPeer(peer);
    setSyncProgress(5);
    setSyncStateMsg('Initializing P2P RF Link...');

    setPeers(prev => prev.map(p => p.id === peer.id ? { ...p, syncStatus: 'syncing' } : p));

    appendLog(`GATT_CONNECT: Connecting to peer ${peer.callsign} (${peer.distanceMeters}m away, RSSI: ${peer.rssi}dBm)...`);

    // Set up step sequence
    const steps = [
      { p: 15, msg: 'Handshaking Security Keys (ECDH-256)...', delay: 600 },
      { p: 30, msg: 'MTU Exchange: Negotiated to 247 bytes.', delay: 500 },
      { p: 45, msg: 'Querying GATT Service UUID 0000fee7...', delay: 700 },
      { p: 65, msg: 'Reading Characteristics (Waypoints & Routes payload)...', delay: 900 },
      { p: 85, msg: 'Downloading payload data packets (CRC-32 Check passed)...', delay: 800 },
      { p: 98, msg: 'Merging telemetry data structures locally...', delay: 600 },
      { p: 100, msg: 'Sync Complete. Connection terminated gracefully.', delay: 400 }
    ];

    let currentStepIdx = 0;

    const runStep = () => {
      if (currentStepIdx >= steps.length) {
        // Finish sync
        completeSync(peer, isBackground);
        return;
      }

      const step = steps[currentStepIdx];
      setTimeout(() => {
        setSyncProgress(step.p);
        setSyncStateMsg(step.msg);
        appendLog(`GATT_TXRX: ${step.msg}`);
        currentStepIdx++;
        runStep();
      }, step.delay);
    };

    runStep();
  };

  const completeSync = (peer: Peer, isBackground: boolean) => {
    // Generate real Emergency Waypoints and Routes to inject into state!
    const incomingWaypoints: Waypoint[] = [];
    const incomingRoutes: Route[] = [];

    // Construct highly detailed off-grid items
    if (peer.callsign === 'RESCUE-MEDIC-04') {
      incomingWaypoints.push({
        id: 'ble_wp_medic_cache',
        name: 'RESCUE-04 Medical & Comms Cache',
        latitude: 24.1610,
        longitude: 21.8315,
        category: 'Emergency Point',
        notes: 'BLE Offline Synced. Waterproof case containing trauma kits, VHF handheld, and MREs. Combination lock: 2026.',
        createdBy: 'RESCUE-MEDIC-04',
        dateCreated: '2026-07-15',
        x: 32,
        y: 28,
        rating: 5,
        isFavorite: true
      });
      incomingWaypoints.push({
        id: 'ble_wp_shelter_cave',
        name: 'Cave Shelter Delta',
        latitude: 24.1022,
        longitude: 21.9125,
        category: 'Campsite',
        notes: 'BLE Synced shelter coordinates. Dry sandstone cave. Water drips inside deep crack (needs filter). Capacity: 6 people.',
        createdBy: 'RESCUE-MEDIC-04',
        dateCreated: '2026-07-15',
        x: 48,
        y: 62,
        rating: 4,
        isFavorite: false
      });
      incomingRoutes.push({
        id: 'ble_rt_evac_route',
        name: 'Evacuation Path Bravo',
        startLocation: 'Dunes Edge Camp',
        destination: 'RESCUE-04 Cache',
        distance: 5.6,
        duration: '1h 35m',
        createdBy: 'RESCUE-MEDIC-04',
        dateCreated: '2026-07-15',
        coordinates: [
          { x: 20, y: 30 },
          { x: 25, y: 28 },
          { x: 32, y: 28 }
        ],
        mode: 'Walking'
      });
    } else if (peer.callsign === 'OUTBACK-RANGER-9') {
      incomingWaypoints.push({
        id: 'ble_wp_ranger_repeater',
        name: 'VHF Off-grid Radio Repeater',
        latitude: 24.2155,
        longitude: 21.8842,
        category: 'Checkpoint',
        notes: 'BLE Offline Synced. Solar solar powered repeater listening on Marine VHF Channel 16. Operational range: 25km radius.',
        createdBy: 'OUTBACK-RANGER-9',
        dateCreated: '2026-07-15',
        x: 58,
        y: 18,
        rating: 5,
        isFavorite: true
      });
      incomingRoutes.push({
        id: 'ble_rt_high_ridge',
        name: 'High Ridge Safe Corridor',
        startLocation: 'Al-Khidr Ancient Well',
        destination: 'Repeater Summit',
        distance: 7.1,
        duration: '2h 10m',
        createdBy: 'OUTBACK-RANGER-9',
        dateCreated: '2026-07-15',
        coordinates: [
          { x: 15, y: 15 },
          { x: 30, y: 16 },
          { x: 45, y: 17 },
          { x: 58, y: 18 }
        ],
        mode: 'Desert Off-Road'
      });
    } else {
      // General peer fallback
      incomingWaypoints.push({
        id: 'ble_wp_explorer_landmark',
        name: 'Shaded Resting Rock',
        latitude: 24.2341,
        longitude: 22.0210,
        category: 'Landmark',
        notes: 'BLE Synced landmark. Shaded area from noon to 3 PM. Good radio line-of-sight to South.',
        createdBy: peer.callsign,
        dateCreated: '2026-07-15',
        x: 72,
        y: 42
      });
    }

    // Call state synchronizer to merge inside App.tsx
    onSyncData(incomingWaypoints, incomingRoutes);

    setPeers(prev => prev.map(p => p.id === peer.id ? { 
      ...p, 
      syncStatus: 'synced', 
      lastSynced: 'Just now',
      waypointsAvailable: 0,
      routesAvailable: 0
    } : p));

    setIsSyncing(false);
    setActiveSyncPeer(null);

    const wpsCount = incomingWaypoints.length;
    const rtsCount = incomingRoutes.length;
    appendLog(`MOCK_SYNC_ENGINE: Merged ${wpsCount} waypoints & ${rtsCount} routes from peer '${peer.callsign}' directly into off-grid database.`);

    const toastMsg = `BLE Sync: Received ${wpsCount} waypoints & ${rtsCount} routes from ${peer.callsign}!`;
    if (addToast) addToast(toastMsg);
  };

  const getRssiColor = (rssi: number) => {
    if (rssi >= -60) return 'text-emerald-400';
    if (rssi >= -75) return 'text-yellow-400';
    return 'text-red-400';
  };

  const clearLogs = () => {
    setLogs([`[${new Date().toLocaleTimeString()}] BLE_CONSOLE: Cleared logging interface telemetry.`]);
  };

  // Counting selection shares
  const selectedWpCount = Object.values(selectedWps).filter(Boolean).length;
  const selectedRtCount = Object.values(selectedRts).filter(Boolean).length;

  return (
    <div className="flex flex-col h-full overflow-y-auto p-4 space-y-4 font-sans text-xs">
      
      {/* 1. OFFGRID BLE BROADCAST CONTROLS */}
      <div className={`p-4 rounded-2xl border flex flex-col gap-3 ${
        isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-gray-50 border-gray-150'
      }`}>
        <div className="flex items-center justify-between border-b border-zinc-800/10 dark:border-zinc-800/40 pb-2 mb-1">
          <div className="flex items-center gap-2">
            <Radio className={`h-4.5 w-4.5 animate-pulse ${broadcastingEnabled ? 'text-[#00E676]' : 'text-zinc-500'}`} />
            <span className="font-mono font-black uppercase tracking-wider text-[#00E676] text-[10px]">
              BLE Local Mesh Radio
            </span>
          </div>
          <span className={`text-[8px] font-mono font-black uppercase px-1.5 py-0.5 rounded ${
            broadcastingEnabled ? 'bg-emerald-500/10 text-[#00E676] border border-emerald-500/20' : 'bg-zinc-500/10 text-zinc-500'
          }`}>
            {broadcastingEnabled ? 'Broadcasting Mesh Node' : 'Mesh Standby'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-1">
          <div>
            <label className="text-[9px] text-zinc-500 uppercase font-mono tracking-wider block mb-1">Local Callsign</label>
            <input 
              type="text" 
              value={callsign}
              onChange={(e) => setCallsign(e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, ''))}
              placeholder="CALLSIGN"
              maxLength={20}
              className={`w-full px-3 py-2 rounded-lg font-mono font-bold text-xs uppercase border focus:outline-none focus:ring-1 ${
                isDark 
                  ? 'bg-[#0b131f] border-zinc-800 text-white focus:ring-[#00E676] focus:border-[#00E676]' 
                  : 'bg-white border-zinc-200 text-zinc-900 focus:ring-[#00C853] focus:border-[#00C853]'
              }`}
            />
          </div>
          <div className="flex flex-col justify-end">
            <span className="text-[9px] text-zinc-500 uppercase font-mono tracking-wider block mb-1">Mesh Status</span>
            <div className="flex items-center gap-2 py-2">
              <span className={`h-2 w-2 rounded-full ${broadcastingEnabled ? 'bg-emerald-400' : 'bg-zinc-500'}`} />
              <span className="font-mono text-[10px] font-bold">
                {broadcastingEnabled ? 'ADV_ACTIVE (2.4GHz)' : 'ADV_STANDBY'}
              </span>
            </div>
          </div>
        </div>

        {/* Toggles */}
        <div className="space-y-2 mt-1">
          <div className="flex items-center justify-between py-1 border-t border-dashed border-zinc-800/10 dark:border-zinc-800/40">
            <div>
              <div className="font-bold text-[10px] uppercase">MESH BEACON BROADCAST</div>
              <div className="text-[8.5px] text-zinc-400">Advertise selected emergency points & routes to nearby users.</div>
            </div>
            <button
              onClick={() => {
                setBroadcastingEnabled(!broadcastingEnabled);
                appendLog(`CONFIG: BLE Advertising ${!broadcastingEnabled ? 'ENABLED' : 'DISABLED'}`);
              }}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full transition-colors duration-200 ease-in-out ${
                broadcastingEnabled ? 'bg-[#00E676]' : 'bg-zinc-700'
              }`}
            >
              <span className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-black shadow ring-0 transition duration-200 ease-in-out mt-0.25 ${
                broadcastingEnabled ? 'translate-x-4' : 'translate-x-0.25'
              }`} />
            </button>
          </div>

          <div className="flex items-center justify-between py-1 border-t border-dashed border-zinc-800/10 dark:border-zinc-800/40">
            <div>
              <div className="font-bold text-[10px] uppercase">AUTOMATED BACKGROUND SYNC</div>
              <div className="text-[8.5px] text-zinc-400">Automatically exchange waypoints with found nodes silently in background.</div>
            </div>
            <button
              onClick={() => {
                setAutoSyncEnabled(!autoSyncEnabled);
                appendLog(`CONFIG: BLE Automated background sync ${!autoSyncEnabled ? 'ENABLED' : 'DISABLED'}`);
              }}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full transition-colors duration-200 ease-in-out ${
                autoSyncEnabled ? 'bg-[#00E676]' : 'bg-zinc-700'
              }`}
            >
              <span className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-black shadow ring-0 transition duration-200 ease-in-out mt-0.25 ${
                autoSyncEnabled ? 'translate-x-4' : 'translate-x-0.25'
              }`} />
            </button>
          </div>
        </div>
      </div>

      {/* 2. REALTIME BLE TRANSCEIVER / ACTIVE SYNCING MODAL PROGRESS */}
      {isSyncing && activeSyncPeer && (
        <div className={`p-4 rounded-2xl border flex flex-col gap-3 ${
          isDark ? 'bg-red-950/20 border-red-500/40 text-red-100 shadow-[0_0_15px_rgba(239,68,68,0.15)]' : 'bg-red-50 border-red-200 text-red-950'
        }`}>
          <div className="flex items-center justify-between border-b border-red-500/20 pb-2 mb-1">
            <span className="font-mono font-black uppercase tracking-wider text-red-500 text-[10px] flex items-center gap-1.5 animate-pulse">
              <RefreshCw className="h-3 w-3 animate-spin" /> ACTIVE PEER SYNC ACTIVE
            </span>
            <span className="text-[8.5px] font-mono">CHUNKS EXCHANGING...</span>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between font-mono text-[9px]">
              <div>Target Callsign: <span className="font-bold">{activeSyncPeer.callsign}</span></div>
              <div className="font-bold">{syncProgress}%</div>
            </div>

            {/* Progress bar */}
            <div className="w-full h-2 rounded-full bg-zinc-800 overflow-hidden">
              <div 
                className="h-full bg-red-500 transition-all duration-300" 
                style={{ width: `${syncProgress}%` }}
              />
            </div>

            <div className="text-[9px] font-mono italic text-zinc-400 text-center animate-pulse">
              {syncStateMsg}
            </div>
          </div>
        </div>
      )}

      {/* 3. RADAR / NEARBY BLE MESH NODES */}
      <div className={`p-4 rounded-2xl border flex flex-col gap-3 ${
        isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-gray-50 border-gray-150'
      }`}>
        <div className="flex items-center justify-between border-b border-zinc-800/10 dark:border-zinc-800/40 pb-2">
          <div className="flex items-center gap-2">
            <Signal className="h-4.5 w-4.5 text-blue-400" />
            <span className="font-mono font-black uppercase tracking-wider text-blue-400 text-[10px]">
              Detected Nearby Mesh Nodes
            </span>
          </div>
          
          <button
            onClick={handleStartScan}
            disabled={isScanning || isSyncing}
            className={`px-2.5 py-1 rounded-lg font-mono font-bold text-[9px] uppercase border cursor-pointer flex items-center gap-1 shadow-sm transition-all duration-150 ${
              isScanning
                ? 'bg-zinc-800 border-zinc-700 text-zinc-500'
                : 'bg-blue-500/10 border-blue-500/20 text-blue-400 hover:bg-blue-500/20'
            }`}
          >
            <RefreshCw className={`h-2.5 w-2.5 ${isScanning ? 'animate-spin' : ''}`} />
            {isScanning ? 'SCANNING...' : 'SCAN BEACONS'}
          </button>
        </div>

        {/* Sonar Radar Screen if scanning */}
        {isScanning && (
          <div className="relative h-28 w-full rounded-xl overflow-hidden flex flex-col items-center justify-center bg-zinc-950/80 border border-zinc-900">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.06)_1%,transparent_70%)]"></div>
            {/* Grid lines */}
            <div className="absolute h-full w-0.5 bg-blue-500/5 left-1/2"></div>
            <div className="absolute w-full h-0.5 bg-blue-500/5 top-1/2"></div>
            
            {/* Radar Sweeper */}
            <div className="absolute h-12 w-12 rounded-full border border-blue-500/20 animate-[ping_2s_infinite]"></div>
            <div className="absolute h-20 w-20 rounded-full border border-blue-500/10 animate-[ping_3s_infinite]"></div>
            
            <div className="z-10 flex flex-col items-center gap-1.5">
              <div className="flex gap-1 items-center">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                </span>
                <span className="font-mono text-[9px] text-blue-400 uppercase tracking-widest font-black animate-pulse">
                  Sweeping 2.4 GHz RF Spectrum...
                </span>
              </div>
              <span className="text-[8px] font-mono text-zinc-500 uppercase tracking-wider">Listening for off-grid beacon advertisements</span>
            </div>
          </div>
        )}

        {/* Peers List */}
        <div className="space-y-2 mt-1">
          {peers.length === 0 ? (
            <div className="text-center py-4 text-zinc-500 font-mono text-[9px]">
              No offline BLE users detected. Tap scan above to search.
            </div>
          ) : (
            peers.map((peer) => {
              const isSynced = peer.waypointsAvailable === 0 && peer.routesAvailable === 0;
              return (
                <div 
                  key={peer.id}
                  className={`p-3 rounded-xl border flex items-center justify-between gap-3 transition-all ${
                    isDark 
                      ? 'bg-[#121c27] hover:bg-[#162534] border-zinc-800' 
                      : 'bg-white hover:bg-zinc-50 border-zinc-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {/* RSSI Signal Bar indicator */}
                    <div className="flex flex-col items-center min-w-[20px]">
                      <span className={`font-mono text-[8px] font-bold ${getRssiColor(peer.rssi)}`}>
                        {peer.rssi}dBm
                      </span>
                      <div className="flex gap-0.5 mt-0.5 items-end h-2">
                        <div className={`w-0.75 rounded-t-sm ${peer.rssi >= -95 ? 'h-1 bg-zinc-500' : 'h-1 bg-zinc-700'} ${peer.rssi >= -85 ? 'bg-emerald-400' : ''}`} />
                        <div className={`w-0.75 rounded-t-sm ${peer.rssi >= -80 ? 'h-1.5 bg-zinc-500' : 'h-1.5 bg-zinc-700'} ${peer.rssi >= -75 ? 'bg-emerald-400' : ''}`} />
                        <div className={`w-0.75 rounded-t-sm ${peer.rssi >= -65 ? 'h-2 bg-zinc-500' : 'h-2 bg-zinc-700'} ${peer.rssi >= -60 ? 'bg-emerald-400' : ''}`} />
                      </div>
                    </div>

                    <div className="space-y-0.5 text-left">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-bold text-xs text-white uppercase tracking-tight flex items-center gap-1">
                          {peer.callsign}
                          {peer.isOfficialRescue && (
                            <span className="text-[7px] font-mono font-black bg-red-500/20 text-red-400 border border-red-500/30 rounded px-1 uppercase tracking-wider py-0.25">
                              RESCUE
                            </span>
                          )}
                        </span>
                        <span className="text-[8px] text-zinc-500 font-mono">• {peer.distanceMeters}m</span>
                      </div>
                      <div className="text-[8.5px] text-zinc-400 flex items-center gap-1">
                        <span>{peer.deviceType}</span>
                        <span>•</span>
                        <span>Last sync: {peer.lastSynced}</span>
                      </div>
                      
                      {!isSynced && (
                        <div className="flex items-center gap-1.5 mt-1 text-[8px] font-mono text-[#00E676] bg-emerald-500/5 px-1.5 py-0.5 rounded border border-emerald-500/10 w-fit">
                          <MapPin className="h-2.5 w-2.5" />
                          <span>{peer.waypointsAvailable} waypoints, {peer.routesAvailable} routes ready to sync</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    {isSynced ? (
                      <div className="flex items-center gap-1 text-emerald-400 font-mono text-[9px] font-bold bg-emerald-500/10 px-2 py-1 rounded-lg border border-emerald-500/20">
                        <Check className="h-3 w-3 stroke-[3]" />
                        <span>SYNCED</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => triggerSync(peer)}
                        disabled={isSyncing || isScanning}
                        className={`px-3 py-1.5 rounded-lg font-mono font-black text-[9.5px] border cursor-pointer tracking-wider uppercase transition-all duration-150 ${
                          isSyncing || isScanning
                            ? 'bg-zinc-800 border-zinc-700 text-zinc-500 cursor-not-allowed'
                            : 'bg-[#00E676] hover:bg-[#00c564] border-[#00E676] text-black hover:scale-[1.03] shadow-md font-bold'
                        }`}
                      >
                        SYNC NOW
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 4. BROADCAST ASSETS DIRECTORY */}
      <div className={`p-4 rounded-2xl border flex flex-col gap-3 ${
        isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-gray-50 border-gray-150'
      }`}>
        <div className="flex items-center justify-between border-b border-zinc-800/10 dark:border-zinc-800/40 pb-2 mb-1">
          <div className="flex items-center gap-2">
            <Share2 className="h-4.5 w-4.5 text-emerald-400" />
            <span className="font-mono font-black uppercase tracking-wider text-emerald-400 text-[10px]">
              Local Share Assets Configuration
            </span>
          </div>
          <span className="text-[9px] font-mono text-zinc-400">
            Selected: {selectedWpCount + selectedRtCount} files
          </span>
        </div>

        <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
          {/* Waypoints checklist */}
          <div>
            <div className="text-[8.5px] uppercase font-mono font-extrabold text-zinc-400 tracking-wider mb-1.5 flex items-center justify-between">
              <span>📍 Private Waypoints ({waypoints.length})</span>
              <button 
                onClick={() => {
                  const anySelected = Object.values(selectedWps).some(Boolean);
                  const updated: Record<string, boolean> = {};
                  waypoints.forEach(wp => { updated[wp.id] = !anySelected; });
                  setSelectedWps(updated);
                }}
                className="text-[8px] text-blue-400 uppercase tracking-widest font-black hover:underline cursor-pointer"
              >
                Toggle All
              </button>
            </div>
            {waypoints.length === 0 ? (
              <div className="text-zinc-500 italic text-[9px] font-mono py-1">No waypoints saved. Pin some on your map!</div>
            ) : (
              <div className="space-y-1">
                {waypoints.map(wp => (
                  <label 
                    key={wp.id} 
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg border text-[9px] font-mono cursor-pointer transition-all ${
                      selectedWps[wp.id] 
                        ? (isDark ? 'bg-emerald-500/5 border-emerald-500/20 text-white' : 'bg-emerald-50 border-emerald-200 text-zinc-950')
                        : (isDark ? 'bg-zinc-900/30 border-zinc-800/60 text-zinc-400' : 'bg-white border-zinc-200 text-zinc-500')
                    }`}
                  >
                    <div className="flex items-center gap-2 text-left">
                      <input 
                        type="checkbox"
                        checked={!!selectedWps[wp.id]}
                        onChange={() => setSelectedWps(prev => ({ ...prev, [wp.id]: !prev[wp.id] }))}
                        className="rounded border-zinc-800 dark:bg-zinc-950 text-emerald-400 focus:ring-emerald-400 h-3 w-3"
                      />
                      <span className="font-bold uppercase truncate max-w-[150px]">{wp.name}</span>
                    </div>
                    <span className="text-[7.5px] px-1 py-0.25 bg-zinc-800 dark:bg-black rounded text-zinc-500 uppercase">{wp.category}</span>
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* Routes Checklist */}
          <div>
            <div className="text-[8.5px] uppercase font-mono font-extrabold text-zinc-400 tracking-wider mb-1.5 flex items-center justify-between">
              <span>🗺️ Nav Routes ({routes.length})</span>
              <button 
                onClick={() => {
                  const anySelected = Object.values(selectedRts).some(Boolean);
                  const updated: Record<string, boolean> = {};
                  routes.forEach(rt => { updated[rt.id] = !anySelected; });
                  setSelectedRts(updated);
                }}
                className="text-[8px] text-blue-400 uppercase tracking-widest font-black hover:underline cursor-pointer"
              >
                Toggle All
              </button>
            </div>
            {routes.length === 0 ? (
              <div className="text-zinc-500 italic text-[9px] font-mono py-1">No navigation routes saved.</div>
            ) : (
              <div className="space-y-1">
                {routes.map(rt => (
                  <label 
                    key={rt.id} 
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-lg border text-[9px] font-mono cursor-pointer transition-all ${
                      selectedRts[rt.id] 
                        ? (isDark ? 'bg-emerald-500/5 border-emerald-500/20 text-white' : 'bg-emerald-50 border-emerald-200 text-zinc-950')
                        : (isDark ? 'bg-zinc-900/30 border-zinc-800/60 text-zinc-400' : 'bg-white border-zinc-200 text-zinc-500')
                    }`}
                  >
                    <div className="flex items-center gap-2 text-left">
                      <input 
                        type="checkbox"
                        checked={!!selectedRts[rt.id]}
                        onChange={() => setSelectedRts(prev => ({ ...prev, [rt.id]: !prev[rt.id] }))}
                        className="rounded border-zinc-800 dark:bg-zinc-950 text-emerald-400 focus:ring-emerald-400 h-3 w-3"
                      />
                      <span className="font-bold uppercase truncate max-w-[150px]">{rt.name}</span>
                    </div>
                    <span className="text-[7.5px] px-1 py-0.25 bg-zinc-800 dark:bg-black rounded text-zinc-500 uppercase">{rt.distance.toFixed(1)} km</span>
                  </label>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 5. TACTICAL REALTIME TELEMETRY SYSTEM LOGGER */}
      <div className={`p-4 rounded-2xl border flex flex-col gap-2 ${
        isDark ? 'bg-black border-zinc-850' : 'bg-zinc-950 border-zinc-900 text-zinc-200'
      }`}>
        <div className="flex items-center justify-between border-b border-zinc-800 pb-1.5 mb-1">
          <div className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-[#00E676] animate-pulse"></span>
            <span className="font-mono font-black uppercase text-[8.5px] text-[#00E676] tracking-widest">
              BLE Radio Console Telemetry Log
            </span>
          </div>
          <button 
            onClick={clearLogs}
            className="text-[7.5px] font-mono uppercase bg-zinc-900 text-zinc-400 hover:text-white px-1.5 py-0.5 rounded border border-zinc-800 cursor-pointer"
          >
            Clear Log
          </button>
        </div>

        <div 
          ref={logContainerRef}
          className="h-28 overflow-y-auto font-mono text-[8.5px] text-zinc-400 leading-tight space-y-1 text-left scrollbar-thin scrollbar-thumb-zinc-800"
        >
          {logs.map((log, i) => (
            <div key={i} className="whitespace-pre-wrap font-mono leading-relaxed select-text">
              {log}
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
