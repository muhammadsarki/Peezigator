/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Route, Waypoint, AppSettings, NavigationMode } from '../types';
import { Plus, Trash2, Map, Navigation, Save, Edit, Play, Search, MoveRight } from 'lucide-react';

interface RoutePlannerProps {
  routes: Route[];
  waypoints: Waypoint[];
  selectedRoute: Route | null;
  onSelectRoute: (route: Route | null) => void;
  onAddRoute: (route: Route) => void;
  onRemoveRoute: (id: string) => void;
  onEditRoute: (updatedRoute: Route) => void;
  settings: AppSettings;
  currentUserEmail: string;
  // Interactive route builder coordination
  routeBuilderActive: boolean;
  routeBuilderPoints: { x: number; y: number }[];
  onToggleRouteBuilder: (active: boolean) => void;
  onClearRouteBuilderPoints: () => void;
}

const NAV_MODES: NavigationMode[] = ['Driving', 'Walking', 'Desert Off-Road', 'Sailing'];

export default function RoutePlanner({
  routes,
  waypoints,
  selectedRoute,
  onSelectRoute,
  onAddRoute,
  onRemoveRoute,
  onEditRoute,
  settings,
  currentUserEmail,
  routeBuilderActive,
  routeBuilderPoints,
  onToggleRouteBuilder,
  onClearRouteBuilderPoints,
}: RoutePlannerProps) {
  const isDark = settings.theme === 'dark';

  // Toggle Route Creator Mode
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [editingRouteId, setEditingRouteId] = useState<string | null>(null);
  const [routeSearchQuery, setRouteSearchQuery] = useState<string>('');

  // Form states
  const [name, setName] = useState<string>('');
  const [start, setStart] = useState<string>('');
  const [destination, setDestination] = useState<string>('');
  const [selectedWpIds, setSelectedWpIds] = useState<string[]>([]);
  const [navMode, setNavMode] = useState<NavigationMode>('Walking');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const formatDistance = (km: number) => {
    if (settings.distanceUnit === 'miles') {
      return `${(km * 0.621371).toFixed(1)} miles`;
    }
    return `${km.toFixed(1)} km`;
  };

  const handleCreateSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage('');

    if (!name.trim() || !start.trim() || !destination.trim()) {
      setErrorMessage('Route name, start, and destination point labels are required.');
      return;
    }

    // Assemble coordinates
    let coordinates: { x: number; y: number }[] = [];
    if (routeBuilderPoints.length >= 2) {
      coordinates = [...routeBuilderPoints];
    } else if (selectedWpIds.length > 0) {
      coordinates = selectedWpIds
        .map((id) => waypoints.find((w) => w.id === id))
        .filter((w): w is Waypoint => !!w)
        .map((w) => ({ x: w.x, y: w.y }));
    }

    // Fallback if no points loaded
    if (coordinates.length < 2) {
      const startX = Math.floor(Math.random() * 30) + 20;
      const startY = Math.floor(Math.random() * 30) + 20;
      coordinates = [
        { x: startX, y: startY },
        { x: startX + 15, y: startY + 12 },
        { x: startX + 30, y: startY + 5 },
      ];
    }

    // Calculate realistic distance based on scale
    let totalDist = 0;
    for (let i = 0; i < coordinates.length - 1; i++) {
      const dx = coordinates[i + 1].x - coordinates[i].x;
      const dy = coordinates[i + 1].y - coordinates[i].y;
      totalDist += Math.sqrt(dx * dx + dy * dy);
    }
    if (totalDist === 0) totalDist = Math.floor(Math.random() * 25) + 10;

    // Simulated duration based on speed
    let speed = 5; // typical Walking speed (km/h)
    if (navMode === 'Driving') speed = 50;
    else if (navMode === 'Desert Off-Road') speed = 25;
    else if (navMode === 'Sailing') speed = 15;

    const durationHours = totalDist / speed;
    const hours = Math.floor(durationHours);
    const minutes = Math.round((durationHours - hours) * 60);
    const durationString = hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;

    if (editingRouteId) {
      // Edit route
      const oldRoute = routes.find((r) => r.id === editingRouteId);
      if (oldRoute) {
        const updated: Route = {
          ...oldRoute,
          name,
          startLocation: start,
          destination,
          distance: totalDist,
          duration: durationString,
          coordinates,
          mode: navMode,
        };
        onEditRoute(updated);
      }
      setEditingRouteId(null);
    } else {
      // Create new route
      const newRoute: Route = {
        id: `route_${Date.now()}`,
        name,
        startLocation: start,
        destination,
        distance: totalDist,
        duration: durationString,
        createdBy: currentUserEmail || 'guest',
        dateCreated: new Date().toISOString().split('T')[0],
        coordinates,
        mode: navMode,
      };
      onAddRoute(newRoute);
    }

    // Reset Form & coordinates builder
    setName('');
    setStart('');
    setDestination('');
    setSelectedWpIds([]);
    onClearRouteBuilderPoints();
    onToggleRouteBuilder(false);
    setIsCreating(false);
  };

  const handleEditClick = (route: Route) => {
    setName(route.name);
    setStart(route.startLocation);
    setDestination(route.destination);
    setNavMode(route.mode || 'Walking');
    setEditingRouteId(route.id);
    setIsCreating(true);
    // If route has existing coords, load them so user can edit them
    onClearRouteBuilderPoints();
    route.coordinates.forEach(pt => {
      routeBuilderPoints.push(pt);
    });
  };

  const toggleWpSelection = (id: string) => {
    setSelectedWpIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const startInteractiveDrawing = () => {
    onToggleRouteBuilder(true);
    // Auto populate default names if blank
    if (!name.trim()) setName('Interactive Vector Route');
    if (!start.trim()) setStart('Tapped Coordinate A');
    if (!destination.trim()) setDestination('Tapped Coordinate B');
  };

  // Filter routes
  const filteredRoutes = routes.filter((r) => {
    return (
      r.name.toLowerCase().includes(routeSearchQuery.toLowerCase()) ||
      r.startLocation.toLowerCase().includes(routeSearchQuery.toLowerCase()) ||
      r.destination.toLowerCase().includes(routeSearchQuery.toLowerCase()) ||
      (r.mode && r.mode.toLowerCase().includes(routeSearchQuery.toLowerCase()))
    );
  });

  const getModeEmoji = (mode: NavigationMode) => {
    switch (mode) {
      case 'Driving': return '🚗';
      case 'Walking': return '🥾';
      case 'Desert Off-Road': return '🏜️';
      case 'Sailing': return '⛵';
      default: return '📍';
    }
  };

  const containerBg = isDark ? 'bg-[#08131F] text-white' : 'bg-zinc-50 text-zinc-900';
  const cardBorderClass = isDark ? 'border-zinc-800/80 bg-[#182433]' : 'border-zinc-200 bg-white';
  const primaryBtn = isDark ? 'bg-[#00E676] hover:bg-[#00C853] text-black font-extrabold' : 'bg-[#00C853] hover:bg-emerald-700 text-white font-bold';
  const inputBgClass = isDark ? 'bg-[#111827] border-zinc-800 text-white focus:border-[#00E676]' : 'bg-white border-zinc-200 text-zinc-800';

  return (
    <div className={`p-4 h-full overflow-y-auto flex flex-col justify-start space-y-6 ${containerBg}`}>
      
      {/* Action Header bar */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-sans font-extrabold uppercase tracking-widest text-[#00E676]">
          TRAILS & ROUTES DIRECTORY
        </h3>
        
        {!isCreating && (
          <button
            onClick={() => {
              setIsCreating(true);
              setEditingRouteId(null);
              onClearRouteBuilderPoints();
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold tracking-wider flex items-center gap-1.5 cursor-pointer uppercase ${primaryBtn}`}
          >
            <Plus className="h-4 w-4" /> NEW ROUTE
          </button>
        )}
      </div>

      {isCreating ? (
        /* Create or Edit Route Workspace */
        <div className={`p-5 rounded-xl border ${cardBorderClass} space-y-4 shadow-xl`}>
          <h4 className="text-sm font-bold uppercase tracking-wider text-gray-200 flex items-center gap-2">
            <Map className="h-4 w-4 text-green-500" />
            {editingRouteId ? 'RE-ORIENT ROUTE LOG' : 'PLOT NEW EXPEDITION LOG'}
          </h4>

          {errorMessage && (
            <div className={`p-2.5 text-xs rounded-xl font-mono text-center border ${
              isDark ? 'bg-red-950/20 border-red-900 text-red-400' : 'bg-red-50 border-red-200 text-red-700'
            }`}>
              ⚠️ {errorMessage}
            </div>
          )}

          {/* Draw button */}
          <div className="p-4 rounded-xl border border-dashed border-gray-700 bg-black/20 text-center space-y-2.5">
            <h5 className="text-[11px] font-bold font-mono tracking-wider text-gray-400 uppercase">
              🧭 CO-ORDINATE METHOD
            </h5>
            
            {routeBuilderPoints.length > 0 ? (
              <div className="text-[11px] text-green-400 font-mono font-bold">
                ✓ Recorded {routeBuilderPoints.length} points on mapping grid!
              </div>
            ) : (
              <p className="text-[10px] text-gray-500 font-sans leading-none">
                Tap points directly on the vector map to trace detailed tracks
              </p>
            )}

            <div className="flex gap-2 justify-center">
              <button
                type="button"
                onClick={startInteractiveDrawing}
                className={`px-3 py-1.5 rounded text-[10px] font-bold tracking-wider uppercase cursor-pointer flex items-center gap-1.5 ${
                  routeBuilderActive ? 'bg-amber-600 text-white animate-pulse' : 'bg-zinc-800 text-gray-300 hover:bg-zinc-700'
                }`}
              >
                <Plus className="h-3 w-3" />
                {routeBuilderActive ? 'TAP ON CANVAS MAP...' : 'TAP MAP POINTS'}
              </button>
              
              {routeBuilderPoints.length > 0 && (
                <button
                  type="button"
                  onClick={onClearRouteBuilderPoints}
                  className="px-2.5 py-1 text-[10px] bg-red-950/30 border border-red-905 text-red-400 rounded hover:bg-red-900 hover:text-white"
                >
                  CLEAR
                </button>
              )}
            </div>
          </div>

          <div className="space-y-3.5">
            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">ROUTE IDENTIFIER</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Ridge Summit Traverse"
                className={`w-full px-3.5 py-2 rounded-lg border text-xs outline-none focus:ring-1 ${inputBgClass}`}
              />
            </div>

            <div className="grid grid-cols-2 gap-3.5">
              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">STARTING DECK</label>
                <input
                  type="text"
                  value={start}
                  onChange={(e) => setStart(e.target.value)}
                  placeholder="e.g. Campsite Alpha"
                  className={`w-full px-3.5 py-2 rounded-lg border text-xs outline-none ${inputBgClass}`}
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">TERMINATION APEX</label>
                <input
                  type="text"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  placeholder="e.g. Haven Outpost"
                  className={`w-full px-3.5 py-2 rounded-lg border text-xs outline-none ${inputBgClass}`}
                />
              </div>
            </div>

            {/* Navigation mode selector */}
            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1.5 font-bold">
                NAVIGATION TRANSPORT MODE
              </label>
              <div className="grid grid-cols-4 gap-1">
                {NAV_MODES.map((mode) => (
                  <button
                    type="button"
                    key={mode}
                    onClick={() => setNavMode(mode)}
                    className={`py-2 rounded text-[9px] font-bold uppercase transition-all tracking-wide cursor-pointer text-center border ${
                      navMode === mode
                        ? (isDark ? 'bg-green-500 text-black border-green-500' : 'bg-[#006ca5] text-white border-sky-850')
                        : 'bg-zinc-800/10 hover:bg-zinc-800/30 text-gray-400 border-transparent'
                    }`}
                  >
                    <div className="text-xs mb-0.5">{getModeEmoji(mode)}</div>
                    <div className="scale-90">{mode.split(' ')[0]}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Waypoint chain select (fallback/alternative) */}
            {routeBuilderPoints.length === 0 && (
              <div>
                <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1.5 font-bold">
                  OR: CONNECT WAYPOINTS TO FORM LINE
                </label>
                
                {waypoints.length === 0 ? (
                  <div className="p-2 text-center rounded border border-dashed border-gray-800 text-[9px] text-gray-500 uppercase">
                    No waypoints available.
                  </div>
                ) : (
                  <div className="max-h-24 overflow-y-auto space-y-1 p-1 rounded-lg bg-zinc-900/30 border border-gray-800">
                    {waypoints.map((wp) => {
                      const isSelected = selectedWpIds.includes(wp.id);
                      return (
                        <button
                          type="button"
                          key={wp.id}
                          onClick={() => toggleWpSelection(wp.id)}
                          className={`w-full text-left px-2.5 py-1 rounded text-[10px] font-mono flex items-center justify-between cursor-pointer ${
                            isSelected
                              ? (isDark ? 'bg-green-950/40 text-green-300' : 'bg-sky-100 text-sky-850')
                              : 'hover:bg-zinc-850/20 text-gray-400'
                          }`}
                        >
                          <span>📍 {wp.name}</span>
                          <span className="text-[8px] uppercase tracking-wider opacity-60">{wp.category}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex gap-2 pt-2 text-xs">
            <button
              type="button"
              onClick={() => handleCreateSubmit()}
              className={`flex-1 py-2.5 rounded-lg flex items-center justify-center gap-1.5 font-bold cursor-pointer ${primaryBtn}`}
            >
              <Save className="h-4 w-4" /> SAVE ROUTE
            </button>
            <button
              type="button"
              onClick={() => {
                setIsCreating(false);
                setName('');
                setStart('');
                setDestination('');
                onClearRouteBuilderPoints();
                onToggleRouteBuilder(false);
              }}
              className="px-4 py-2.5 rounded-lg border border-gray-650 hover:bg-zinc-800/30 transition-all font-semibold"
            >
              ABORT
            </button>
          </div>
        </div>
      ) : (
        /* Routes listing display */
        <div className="space-y-4">
          
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <input
              type="text"
              value={routeSearchQuery}
              onChange={(e) => setRouteSearchQuery(e.target.value)}
              placeholder="Search trails, start/stop locations..."
              className={`w-full pl-9 pr-4 py-2.5 rounded-xl border text-xs outline-none focus:ring-1 ${inputBgClass}`}
            />
          </div>

          {filteredRoutes.length === 0 ? (
            <div className="p-10 text-center rounded-2xl border border-dashed border-gray-700 text-gray-500 text-xs uppercase space-y-1">
              <span>No Matching Trails Found</span>
              <p className="text-[10px] lowercase text-gray-600">click "new route" to begin plotting a trail segment!</p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {filteredRoutes.map((route) => {
                const isSelected = selectedRoute?.id === route.id;
                return (
                  <div
                    key={route.id}
                    className={`p-4 rounded-xl border relative transition-all ${
                      isSelected
                        ? (isDark ? 'border-green-600 bg-emerald-990/5' : 'border-sky-505 bg-sky-50/20')
                        : (isDark ? 'border-zinc-800 bg-[#060a07]/30' : 'border-gray-200 hover:bg-gray-50/50')
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div>
                        <h4 className="font-bold text-sm text-gray-200 flex items-center gap-1.5">
                          <span>{route.name}</span>
                          <span className="text-[9px] font-mono tracking-wider bg-zinc-800 text-gray-400 px-1.5 py-0.5 rounded uppercase">
                            {getModeEmoji(route.mode)} {route.mode || 'Walking'}
                          </span>
                        </h4>
                        
                        <div className="flex items-center gap-1 text-[11px] font-mono text-gray-400 mt-1">
                          <span className="text-sky-500 font-bold">{route.startLocation}</span>
                          <MoveRight className="h-3 w-3 text-gray-500" />
                          <span className="text-yellow-500 font-bold">{route.destination}</span>
                        </div>
                      </div>

                      <div className="flex gap-1">
                        <button
                          onClick={() => handleEditClick(route)}
                          className="p-1.5 rounded border border-gray-751 hover:bg-zinc-800 text-gray-400 hover:text-white"
                          title="Reparameterize trail lines"
                        >
                          <Edit className="h-3.5 w-3.5" />
                        </button>
                        
                        <button
                          onClick={() => onRemoveRoute(route.id)}
                          className="p-1.5 rounded border border-rose-900 bg-rose-950/10 text-rose-400 hover:bg-rose-905 hover:text-white transition-all cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="border-t border-gray-700/10 mt-3 pt-3 flex items-center justify-between gap-4">
                      <div className="flex gap-4 text-xs font-mono">
                        <div>
                          Distance: <span className="font-bold text-gray-300">{formatDistance(route.distance)}</span>
                        </div>
                        <div>
                          Est Duration: <span className="font-bold text-gray-300">{route.duration}</span>
                        </div>
                      </div>

                      <div className="flex gap-1.5">
                        <button
                          onClick={() => onSelectRoute(isSelected ? null : route)}
                          className={`px-3 py-1 rounded text-xs font-bold tracking-wider uppercase flex items-center gap-1 cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-amber-600 text-white'
                              : (isDark ? 'bg-zinc-850 hover:bg-zinc-700 text-green-300' : 'bg-gray-100 text-sky-800 hover:bg-gray-200')
                          }`}
                        >
                          <Navigation className="h-3 w-3" />
                          {isSelected ? 'LOCKED' : 'FOCUS'}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
