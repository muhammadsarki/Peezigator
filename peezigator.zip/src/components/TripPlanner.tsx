/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Trip, Route, Waypoint, AppSettings } from '../types';
import { Route as TripIcon, Plus, Trash2, Calendar, MapPin, Eye, Save, Clock, Milestone } from 'lucide-react';

interface TripPlannerProps {
  trips: Trip[];
  routes: Route[];
  waypoints: Waypoint[];
  onAddTrip: (trip: Trip) => void;
  onRemoveTrip: (id: string) => void;
  onSelectRoute: (route: Route | null) => void;
  onSelectWaypoint: (wp: Waypoint | null) => void;
  settings: AppSettings;
  currentUserEmail: string;
}

export default function TripPlanner({
  trips,
  routes,
  waypoints,
  onAddTrip,
  onRemoveTrip,
  onSelectRoute,
  onSelectWaypoint,
  settings,
  currentUserEmail,
}: TripPlannerProps) {
  const isDark = settings.theme === 'dark';

  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [desc, setDesc] = useState<string>('');
  const [selectedRouteIds, setSelectedRouteIds] = useState<string[]>([]);
  const [selectedWpIds, setSelectedWpIds] = useState<string[]>([]);
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Helper to parse "Xh Ym" or similar into total minutes
  const parseDurationToMinutes = (durStr: string): number => {
    const hoursMatch = durStr.match(/(\d+)\s*h/);
    const minsMatch = durStr.match(/(\d+)\s*m/);
    const hours = hoursMatch ? parseInt(hoursMatch[1]) : 0;
    const mins = minsMatch ? parseInt(minsMatch[1]) : 0;
    return hours * 60 + mins;
  };

  // Helper to format minutes into "Xh Ym"
  const formatMinutesToDuration = (totalMins: number): string => {
    const hours = Math.floor(totalMins / 60);
    const mins = Math.round(totalMins % 60);
    if (hours === 0) return `${mins}m`;
    return `${hours}h ${mins}m`;
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim()) {
      setErrorMessage('A trip folder name is mandatory.');
      return;
    }

    if (selectedRouteIds.length === 0) {
      setErrorMessage('Please include at least one active route track log in this trip.');
      return;
    }

    // Dynamic aggregates
    const selectedRoutes = routes.filter(r => selectedRouteIds.includes(r.id));
    const totalDistance = selectedRoutes.reduce((sum, r) => sum + r.distance, 0);
    const totalMinutes = selectedRoutes.reduce((sum, r) => sum + parseDurationToMinutes(r.duration), 0);
    const aggregatedDuration = formatMinutesToDuration(totalMinutes || 45);

    const newTrip: Trip = {
      id: `trip_${Date.now()}`,
      name,
      description: desc,
      routeIds: selectedRouteIds,
      waypointIds: selectedWpIds,
      distance: totalDistance,
      duration: aggregatedDuration,
      dateCreated: new Date().toISOString().split('T')[0],
      createdBy: currentUserEmail || 'guest',
    };

    onAddTrip(newTrip);

    // Reset Form
    setName('');
    setDesc('');
    setSelectedRouteIds([]);
    setSelectedWpIds([]);
    setIsCreating(false);
  };

  const toggleRouteSelection = (id: string) => {
    setSelectedRouteIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const toggleWpSelection = (id: string) => {
    setSelectedWpIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const formatDistance = (km: number) => {
    if (settings.distanceUnit === 'miles') {
      return `${(km * 0.621371).toFixed(1)} mi`;
    }
    return `${km.toFixed(1)} km`;
  };

  const containerBg = isDark ? 'bg-[#08131F] text-white' : 'bg-zinc-50 text-zinc-900';
  const cardBorderClass = isDark ? 'border-zinc-800/80 bg-[#182433]' : 'border-zinc-200 bg-white';
  const inputBgClass = isDark ? 'bg-[#111827] border-zinc-800 text-white focus:border-[#00E676]' : 'bg-white border-zinc-200 text-zinc-850';
  const btnPrimary = isDark ? 'bg-[#00E676] hover:bg-[#00C853] text-black font-extrabold' : 'bg-[#00C853] hover:bg-emerald-700 text-white font-extrabold';

  return (
    <div className={`p-4 h-full overflow-y-auto flex flex-col justify-start space-y-6 ${containerBg}`}>
      
      {/* Header operations */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-sans font-extrabold uppercase tracking-widest text-[#00E676]">
          OFF-GRID TRIP FILES
        </h3>

        {!isCreating && (
          <button
            onClick={() => setIsCreating(true)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold tracking-wider flex items-center gap-1.5 cursor-pointer uppercase ${btnPrimary}`}
          >
            <Plus className="h-4 w-4" /> BUNDLE TRIP
          </button>
        )}
      </div>

      {isCreating ? (
        /* Trip Assembly Workspace */
        <form onSubmit={handleCreateSubmit} className={`p-5 rounded-2xl border ${cardBorderClass} space-y-4 shadow-xl`}>
          <h4 className="text-sm font-bold uppercase tracking-wider text-gray-300 flex items-center gap-2">
            <TripIcon className="h-4 w-4 text-green-500" /> ASSEMBLE TRIP FILES BUNDLE
          </h4>

          {errorMessage && (
            <div className={`p-2.5 font-mono text-xs rounded-xl border text-center ${
              isDark ? 'bg-red-950/20 border-red-900 text-red-400' : 'bg-red-50 border-red-200 text-red-700'
            }`}>
              ⚠️ {errorMessage}
            </div>
          )}

          <div className="space-y-3.5">
            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Trip Bundle Label</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Solstice Ridge Traversing Trek"
                className={`w-full px-3.5 py-2 rounded-lg border text-xs outline-none ${inputBgClass}`}
                required
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1 font-bold">Mission Description / Logistics</label>
              <textarea
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                placeholder="Details of physical prep, fuel caches, survival vectors, weather thresholds..."
                className={`w-full h-16 px-3.5 py-2 rounded-lg border text-xs outline-none resize-none ${inputBgClass}`}
              />
            </div>

            {/* Select MULTIPLE routes */}
            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1.5 font-bold">
                Trace Tracklogs to Group <span className="text-gray-500">({selectedRouteIds.length} Linked)</span>
              </label>
              {routes.length === 0 ? (
                <div className="p-3 text-center rounded-lg border border-dashed border-gray-750 text-[10px] text-gray-500 uppercase">
                  No active routes mapped. Please create a route first.
                </div>
              ) : (
                <div className="max-h-24 overflow-y-auto p-1.5 rounded-lg border border-gray-700/20 bg-black/15 space-y-1">
                  {routes.map((r) => {
                    const isChecked = selectedRouteIds.includes(r.id);
                    return (
                      <button
                        type="button"
                        key={r.id}
                        onClick={() => toggleRouteSelection(r.id)}
                        className={`w-full text-left px-2.5 py-1.5 rounded text-[11px] font-mono flex items-center justify-between cursor-pointer ${
                          isChecked
                            ? (isDark ? 'bg-green-950/60 border border-green-500/30 text-green-300' : 'bg-sky-100 border border-sky-200 text-sky-800')
                            : 'hover:bg-zinc-800/10 text-gray-405 border border-transparent'
                        }`}
                      >
                        <span>🛣️ {r.name}</span>
                        <span className="text-[9px] font-bold">{formatDistance(r.distance)} ({r.mode})</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Link waypoints checklist */}
            <div>
              <label className="block text-[10px] uppercase font-mono text-gray-400 mb-1.5 font-bold">
                Bundle Waypoint Beacons <span className="text-gray-500 font-normal">({selectedWpIds.length} Target Pins)</span>
              </label>

              {waypoints.length === 0 ? (
                <div className="p-3 text-center rounded-lg border border-dashed border-gray-700 text-[10px] text-gray-500 uppercase">
                  No saved waypoints available for grouping.
                </div>
              ) : (
                <div className="max-h-24 overflow-y-auto p-1.5 rounded-lg border border-gray-700/20 bg-black/15 space-y-1">
                  {waypoints.map((wp) => {
                    const checked = selectedWpIds.includes(wp.id);
                    return (
                      <button
                        type="button"
                        key={wp.id}
                        onClick={() => toggleWpSelection(wp.id)}
                        className={`w-full text-left px-2 py-1.5 rounded text-[11px] font-mono flex items-center justify-between cursor-pointer ${
                          checked
                            ? (isDark ? 'bg-green-950/60 border border-green-550/35 text-green-300' : 'bg-sky-100 border border-sky-150 text-sky-800')
                            : 'hover:bg-zinc-800/10 text-gray-405 border border-transparent'
                        }`}
                      >
                        <span>📍 {wp.name}</span>
                        <span className="text-[9px] uppercase tracking-wide opacity-60">{wp.category}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-2 pt-2 text-xs">
            <button
              type="submit"
              className={`flex-1 py-2.5 rounded-lg flex items-center justify-center gap-1.5 font-bold cursor-pointer ${btnPrimary}`}
            >
              <Save className="h-4 w-4" /> SECURE BUNDLE
            </button>
            <button
              type="button"
              onClick={() => {
                setIsCreating(false);
                setName('');
                setDesc('');
                setSelectedRouteIds([]);
                setSelectedWpIds([]);
              }}
              className="px-4 py-2.5 rounded-lg border border-gray-650 hover:bg-zinc-800/30 transition-all font-semibold"
            >
              ABORT
            </button>
          </div>
        </form>
      ) : (
        /* Trips Lists Browser */
        <div className="space-y-4">
          {trips.length === 0 ? (
            <div className="p-10 text-center rounded-2xl border border-dashed border-gray-700 space-y-2 text-gray-500">
              <TripIcon className="h-8 w-8 mx-auto text-gray-500 animate-pulse" />
              <p className="text-xs font-bold uppercase tracking-wider text-gray-400">No Expedition Folders Ready</p>
              <p className="text-[10px]">Trips pack multiple track logs and coordinate markers into a singular file.</p>
            </div>
          ) : (
            trips.map((trip) => {
              // Extract route distances
              const matchesRoutes = routes.filter((r) => trip.routeIds?.includes(r.id));
              
              return (
                <div
                  key={trip.id}
                  className={`p-4 rounded-xl border relative shadow-md ${
                    isDark ? 'border-gray-800 bg-[#060a07]/30' : 'border-gray-200 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <h4 className="font-bold text-sm tracking-wide text-green-400">{trip.name}</h4>
                      <div className="flex items-center gap-3 text-[10px] text-gray-400 mt-1 font-mono flex-wrap">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" /> {trip.dateCreated}
                        </span>
                        <span className="flex items-center gap-1">
                          <Milestone className="h-3 w-3" /> Total Distance: {formatDistance(trip.distance)}
                        </span>
                        <span className="flex items-center gap-0.5 text-blue-400">
                          <Clock className="h-3 w-3" /> Duration: {trip.duration}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onRemoveTrip(trip.id)}
                      className="p-1.5 rounded border border-rose-900 bg-rose-950/10 text-rose-400 hover:bg-rose-900 hover:text-white transition-all cursor-pointer"
                      title="Erase trip catalog file"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {trip.description && (
                    <p className={`text-xs p-2.5 rounded-lg border font-mono mt-1 ${
                      isDark ? 'bg-zinc-950 border-green-950/30 text-gray-300' : 'bg-gray-50 border-gray-100 text-gray-600'
                    }`}>
                      {trip.description}
                    </p>
                  )}

                  {/* Bundled Routes Details */}
                  <div className="mt-4 border-t border-gray-800/50 pt-3 space-y-2">
                    <span className="text-[10px] font-mono font-bold text-gray-500 uppercase tracking-widest block">
                      🔗 Linked Tracks ({matchesRoutes.length})
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {matchesRoutes.map((mr) => (
                        <button
                          key={mr.id}
                          onClick={() => onSelectRoute(mr)}
                          className={`text-[10px] font-mono px-2 py-1 rounded border border-green-955 bg-green-970/10 hover:bg-green-950/30 text-green-300 transition-all cursor-pointer`}
                          title="Focus track log coordinate pattern"
                        >
                          🛣️ {mr.name} ({formatDistance(mr.distance)})
                        </button>
                      ))}
                    </div>

                    {/* Associated waypoints */}
                    <span className="text-[10px] font-mono font-bold text-gray-500 uppercase tracking-widest block mt-3">
                      📍 Bundled Pins ({trip.waypointIds?.length || 0})
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {trip.waypointIds?.map((wpId) => {
                        const wp = waypoints.find((w) => w.id === wpId);
                        if (!wp) return null;
                        return (
                          <button
                            key={wpId}
                            onClick={() => onSelectWaypoint(wp)}
                            className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase transition-all cursor-pointer bg-zinc-800/30 text-gray-400 hover:text-white hover:bg-sky-950/20`}
                            title={`Focus mapped point coordinate: ${wp.name}`}
                          >
                            📍 {wp.name} ({wp.category})
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
