/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Compass, Map, Navigation, Download, MapPin, Route as TripIcon,
  Settings as SettingsIcon, User as UserIcon, ShieldAlert, Radio,
  Moon, Sun, CloudOff, ZoomIn, Search, AlertCircle, SignalHigh, X, CheckSquare,
  Battery, BatteryCharging, Zap, Share2, Copy, Check, Menu, Bell
} from 'lucide-react';

import { User, OfflineMap, Route, Waypoint, Trip, AppSettings } from './types';
import { DEFAULT_OFFLINE_MAPS, DEFAULT_ROUTES, DEFAULT_WAYPOINTS, DEFAULT_TRIPS } from './data/mockData';
import { safeStorage } from './utils/storage';

import peezigatorLogo from './assets/images/peezigator_logo_1784141893267.jpg';

// Component imports
import InteractiveMap from './components/InteractiveMap';
import AuthModal from './components/AuthModal';
import DownloadManager from './components/DownloadManager';
import RoutePlanner from './components/RoutePlanner';
import WaypointModal from './components/WaypointModal';
import TripPlanner from './components/TripPlanner';
import SettingsPage from './components/SettingsPage';
import TelemetryPage from './components/TelemetryPage';
import EmergencyDashboard from './components/EmergencyDashboard';
import P2PSyncPanel from './components/P2PSyncPanel';

export default function App() {
  
  // Hydrate application configuration settings
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = safeStorage.getItem('peezigator_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object' && 'theme' in parsed) {
          return {
            powerSaverMode: false,
            ...parsed
          };
        }
      } catch (e) { /* ignore */ }
    }
    return {
      theme: 'dark', // Default to Dark high-contrast tactical theme
      gpsHighAccuracy: true,
      distanceUnit: 'km',
      mockCompassHeading: 32,
      notificationsEnabled: true,
      offlineModeActive: true, // Default to true to show off-grid capability
      powerSaverMode: false, // Default to false
    };
  });

  // Track settings changes to sync with HTML nodes or local storage
  useEffect(() => {
    if (settings) {
      safeStorage.setItem('peezigator_settings', JSON.stringify(settings));
      
      // Dynamically tweak document backgrounds if needed
      if (typeof document !== 'undefined' && document.body) {
        if (settings.theme === 'dark') {
          document.body.className = 'bg-black text-white';
        } else {
          document.body.className = 'bg-gray-50 text-gray-800';
        }
      }
    }
  }, [settings]);

  // --- DEVICE BATTERY POWER SYSTEM ---
  const [batteryLevel, setBatteryLevel] = useState<number>(() => {
    const saved = safeStorage.getItem('peezigator_battery_level');
    return saved ? parseInt(saved, 10) : 84;
  });
  const [batteryCharging, setBatteryCharging] = useState<boolean>(() => {
    const saved = safeStorage.getItem('peezigator_battery_charging');
    return saved === 'true';
  });
  const [showBatteryManager, setShowBatteryManager] = useState<boolean>(false);
  const [hasWarnedLowBattery, setHasWarnedLowBattery] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    safeStorage.setItem('peezigator_battery_level', String(batteryLevel));
  }, [batteryLevel]);

  useEffect(() => {
    safeStorage.setItem('peezigator_battery_charging', String(batteryCharging));
  }, [batteryCharging]);

  // Hook into continuous real-time browser battery API level where permitted and available
  useEffect(() => {
    let active = true;
    let batteryObj: any = null;

    const syncBatteryStatus = (batt: any) => {
      setBatteryLevel(Math.round(batt.level * 100));
      setBatteryCharging(batt.charging);
    };

    const onLevelChange = () => {
      if (active && batteryObj) syncBatteryStatus(batteryObj);
    };

    const onChargingChange = () => {
      if (active && batteryObj) syncBatteryStatus(batteryObj);
    };

    try {
      if (typeof navigator !== 'undefined' && typeof (navigator as any).getBattery === 'function') {
        const promise = (navigator as any).getBattery();
        if (promise && typeof promise.then === 'function') {
          promise.then((batt: any) => {
            if (!active) return;
            batteryObj = batt;
            syncBatteryStatus(batt);

            batt.addEventListener('levelchange', onLevelChange);
            batt.addEventListener('chargingchange', onChargingChange);
          }).catch((err: any) => {
            console.warn("Battery status promise rejected or blocked by iframe policy:", err);
          });
        }
      }
    } catch (e) {
      console.warn("Synchronous error querying browser battery status:", e);
    }

    return () => {
      active = false;
      if (batteryObj) {
        try {
          batteryObj.removeEventListener('levelchange', onLevelChange);
          batteryObj.removeEventListener('chargingchange', onChargingChange);
        } catch (e) {}
      }
    };
  }, []);

  // Live simulation: incremental solar collection / offgrid power drainage
  useEffect(() => {
    const interval = setInterval(() => {
      if (batteryCharging) {
        setBatteryLevel((prev) => {
          if (prev >= 100) return 100;
          return prev + 1;
        });
      } else {
        setBatteryLevel((prev) => {
          if (prev <= 0) return 0;
          // Power saving mode cuts drain rate significantly
          const drainRoll = Math.random();
          const threshold = settings.powerSaverMode ? 0.08 : 0.25;

          if (drainRoll < threshold) {
            const newLevel = prev - 1;
            if (newLevel <= 20 && !hasWarnedLowBattery) {
              addToast('⚠️ Off-Grid Low Battery Alert: Device drops below 20%! Activating Tactical Power Saving is highly recommended.');
              setHasWarnedLowBattery(true);
            }
            if (newLevel > 20 && hasWarnedLowBattery) {
              setHasWarnedLowBattery(false);
            }
            return newLevel;
          }
          return prev;
        });
      }
    }, 12000); // Poll simulator every 12 seconds

    return () => clearInterval(interval);
  }, [batteryCharging, settings.powerSaverMode, hasWarnedLowBattery]);

  // Auth / Explorer Account State
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = safeStorage.getItem('peezigator_active_explorer');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object' && 'email' in parsed) {
          return parsed;
        }
      } catch (e) {}
    }
    // Pre-authenticated default offline explorer profile
    return {
      email: 'explorer@peezigator.offgrid',
      fullName: 'Offline Explorer',
      profilePhoto: '🥾',
      tripsSaved: []
    };
  });

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    safeStorage.setItem('peezigator_active_explorer', JSON.stringify(user));
    addToast(`Explorer account synchronized: ${user.fullName}`);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    safeStorage.removeItem('peezigator_active_explorer');
    addToast('Explorer session closed.');
  };

  const handleUpdateProfile = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    safeStorage.setItem('peezigator_active_explorer', JSON.stringify(updatedUser));
  };

  // Hydrate map regions, custom routes, waypoints, and trips
  const [offlineMaps, setOfflineMaps] = useState<OfflineMap[]>(() => {
    const saved = safeStorage.getItem('peezigator_offline_maps');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return DEFAULT_OFFLINE_MAPS;
  });

  const [routes, setRoutes] = useState<Route[]>(() => {
    const saved = safeStorage.getItem('peezigator_routes');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return DEFAULT_ROUTES;
  });

  const [waypoints, setWaypoints] = useState<Waypoint[]>(() => {
    const saved = safeStorage.getItem('peezigator_waypoints');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return DEFAULT_WAYPOINTS;
  });

  const [trips, setTrips] = useState<Trip[]>(() => {
    const saved = safeStorage.getItem('peezigator_trips');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return DEFAULT_TRIPS;
  });

  // Save states to local storage when changed
  useEffect(() => {
    safeStorage.setItem('peezigator_offline_maps', JSON.stringify(offlineMaps));
  }, [offlineMaps]);

  useEffect(() => {
    safeStorage.setItem('peezigator_routes', JSON.stringify(routes));
  }, [routes]);

  useEffect(() => {
    safeStorage.setItem('peezigator_waypoints', JSON.stringify(waypoints));
  }, [waypoints]);

  useEffect(() => {
    safeStorage.setItem('peezigator_trips', JSON.stringify(trips));
  }, [trips]);

  // Dynamic tracking & route selections
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [selectedWaypoint, setSelectedWaypoint] = useState<Waypoint | null>(null);
  const [placementPendingCoords, setPlacementPendingCoords] = useState<{ x: number; y: number; lat: number; lng: number } | null>(null);

  // Interactive Route builder states
  const [routeBuilderActive, setRouteBuilderActive] = useState<boolean>(false);
  const [routeBuilderPoints, setRouteBuilderPoints] = useState<{ x: number; y: number }[]>([]);

  // Navigation Telemetry states
  const [navigationActive, setNavigationActive] = useState<boolean>(false);
  const [voiceMuted, setVoiceMuted] = useState<boolean>(false);
  const [voiceVolume, setVoiceVolume] = useState<number>(0.85);
  const [voiceLanguage, setVoiceLanguage] = useState<string>('en-US');

  const handleClearRouteBuilderPoints = () => {
    setRouteBuilderPoints([]);
  };

  // Active Menu tabs
  // desktop: splitscreen showing map + panel
  // mobile: overlays panel over map OR displays full map
  const [activePanel, setActivePanel] = useState<string>('map');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sosActive, setSosActive] = useState<boolean>(false);
  const [sosCountdown, setSosCountdown] = useState<number>(10);
  const [sosTransmitting, setSosTransmitting] = useState<boolean>(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Generates a compact offline-safe beacon text payload
  const generateShareText = () => {
    const timestampStr = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
    const mapsLink = `https://www.google.com/maps/search/?api=1&query=${gpsData.lat.toFixed(5)},${gpsData.lng.toFixed(5)}`;
    return `--- PEEZIGATOR OFF-GRID BEACON ---\n` +
           `TIME: ${timestampStr}\n` +
           `COORDS: ${gpsData.lat.toFixed(5)}°N, ${gpsData.lng.toFixed(5)}°E\n` +
           `BATTERY: ${batteryLevel}% ${batteryCharging ? '(Charging)' : '(Discharging)'}\n` +
           `SOURCE: Fused Satellite Fix\n` +
           `MAPS: ${mapsLink}`;
  };

  // Simulated GPS Coordinates
  const [gpsData, setGpsData] = useState({
    x: 18.2,
    y: 19.4,
    lat: 24.1940,
    lng: 21.7366,
    heading: 32,
  });

  // Notifications / Toast center
  const [toasts, setToasts] = useState<{ id: string; msg: string }[]>([]);
  const addToast = (msg: string) => {
    const id = `${Date.now()}`;
    setToasts((prev) => [...prev, { id, msg }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Simulated GPS trigger handler
  const handleUpdateGPS = (newGPS: typeof gpsData) => {
    setGpsData(newGPS);
  };

  // Simulated Downloader loop
  const handleDownloadMap = (id: string) => {
    setOfflineMaps((prev) =>
      prev.map((m) =>
        m.id === id ? { ...m, downloadStatus: 'downloading', progress: 5 } : m
      )
    );
    addToast('Starting off-grid map packet sync...');

    let currentProgress = 5;
    const interval = setInterval(() => {
      currentProgress += Math.floor(Math.random() * 15) + 12;
      
      if (currentProgress >= 100) {
        currentProgress = 100;
        clearInterval(interval);
        
        setOfflineMaps((prevMaps) =>
          prevMaps.map((m) =>
            m.id === id
              ? {
                  ...m,
                  downloadStatus: 'downloaded',
                  progress: 100,
                  lastUpdated: new Date().toISOString().split('T')[0],
                }
              : m
          )
        );
        addToast('Topographic vector region mapped successfully!');
      } else {
        setOfflineMaps((prevMaps) =>
          prevMaps.map((m) =>
            m.id === id ? { ...m, progress: currentProgress } : m
          )
        );
      }
    }, 600);
  };

  const handleDeleteMap = (id: string) => {
    setOfflineMaps((prev) =>
      prev.map((m) =>
        m.id === id ? { ...m, downloadStatus: 'not_downloaded', progress: 0 } : m
      )
    );
    addToast('Offline map cache wiped successfully.');
  };

  // Route additions
  const handleAddRoute = (newRoute: Route) => {
    setRoutes((prev) => [newRoute, ...prev]);
    setSelectedRoute(newRoute);
    addToast(`Expedition route plotted: "${newRoute.name}"`);
  };

  const handleRemoveRoute = (id: string) => {
    setRoutes((prev) => prev.filter((r) => r.id !== id));
    if (selectedRoute?.id === id) setSelectedRoute(null);
    addToast('Route deleted.');
  };

  const handleEditRoute = (updatedRoute: Route) => {
    setRoutes((prev) => prev.map((r) => (r.id === updatedRoute.id ? updatedRoute : r)));
    setSelectedRoute(updatedRoute);
    addToast('Route details revised.');
  };

  // Peer-to-peer sync merge handler
  const handleSyncP2PData = (newWaypoints: Waypoint[], newRoutes: Route[]) => {
    if (newWaypoints.length > 0) {
      setWaypoints((prev) => {
        const existingIds = new Set(prev.map(w => w.id));
        const filteredNew = newWaypoints.filter(w => !existingIds.has(w.id));
        return [...filteredNew, ...prev];
      });
    }
    if (newRoutes.length > 0) {
      setRoutes((prev) => {
        const existingIds = new Set(prev.map(r => r.id));
        const filteredNew = newRoutes.filter(r => !existingIds.has(r.id));
        return [...filteredNew, ...prev];
      });
    }
  };

  // Waypoints additions
  const handleAddWaypoint = (newWp: Waypoint) => {
    setWaypoints((prev) => [newWp, ...prev]);
    setSelectedWaypoint(newWp);
    addToast(`Waypoint pinpointed: "${newWp.name}"`);
  };

  const handleRemoveWaypoint = (id: string) => {
    setWaypoints((prev) => prev.filter((w) => w.id !== id));
    if (selectedWaypoint?.id === id) setSelectedWaypoint(null);
    addToast('Pin removed.');
  };

  const handleEditWaypoint = (updatedWp: Waypoint) => {
    setWaypoints((prev) => prev.map((w) => (w.id === updatedWp.id ? updatedWp : w)));
    setSelectedWaypoint(updatedWp);
    addToast('Pin notes updated.');
  };

  // Trip operations
  const handleAddTrip = (newTrip: Trip) => {
    setTrips((prev) => [newTrip, ...prev]);
    addToast(`Trip bundle archived: "${newTrip.name}"`);
  };

  const handleRemoveTrip = (id: string) => {
    setTrips((prev) => prev.filter((t) => t.id !== id));
    addToast('Trip bundle deleted.');
  };

  // Global search triggers panning to named areas
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    const term = searchQuery.toLowerCase();
    
    // Search predefined regions first
    const mapRegion = offlineMaps.find((m) => m.name.toLowerCase().includes(term));
    if (mapRegion) {
      const centerX = (mapRegion.boundingBox.minX + mapRegion.boundingBox.maxX) / 2;
      const centerY = (mapRegion.boundingBox.minY + mapRegion.boundingBox.maxY) / 2;
      const baseLat = 24.0000;
      const baseLng = 21.5000;
      const latConversion = 0.01;
      const lngConversion = 0.013;

      setGpsData({
        x: centerX,
        y: centerY,
        lat: baseLat + centerY * latConversion,
        lng: baseLng + centerX * lngConversion,
        heading: 0,
      });
      setSelectedRoute(null);
      setActivePanel('map');
      addToast(`Map visual panned to: ${mapRegion.name}`);
      return;
    }

    // Search waypoints
    const wp = waypoints.find((w) => w.name.toLowerCase().includes(term));
    if (wp) {
      setSelectedWaypoint(wp);
      setGpsData({
        x: wp.x,
        y: wp.y,
        lat: wp.latitude,
        lng: wp.longitude,
        heading: 0,
      });
      setActivePanel('map');
      addToast(`Focused mapped pin: ${wp.name}`);
      return;
    }

    addToast('Terrain match failed. Search for Sahara, Zion, Alps, or exact pin name.');
  };

  // Coordinate click placing helper
  const handleMapClickToAddWaypoint = (x: number, y: number, lat: number, lng: number) => {
    setPlacementPendingCoords({ x, y, lat, lng });
    setActivePanel('waypoints');
  };

  // Emergency SOS satellite transmitter simulation
  useEffect(() => {
    if (!sosActive) {
      if (sosCountdown !== 10) setSosCountdown(10);
      if (sosTransmitting !== false) setSosTransmitting(false);
      return;
    }

    if (sosCountdown > 0) {
      const timer = setTimeout(() => setSosCountdown((c) => c - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      if (sosTransmitting !== true) setSosTransmitting(true);
    }
  }, [sosActive, sosCountdown, sosTransmitting]);

  // Layout color selection
  const isDark = settings.theme === 'dark';
  const mainLayoutBg = isDark ? 'bg-[#0B0B0B] text-white' : 'bg-zinc-50 text-zinc-900';
  const navSidebarBg = isDark ? 'bg-[#161616] border-r border-zinc-800 text-[#00E676]' : 'bg-white border-r border-zinc-200 text-[#00C853]';
  const topNavHeaderBg = isDark ? 'bg-[#161616] border-b border-zinc-850 text-white' : 'bg-white border-b border-zinc-200 text-zinc-900';
  const tabBtnActive = isDark ? 'bg-zinc-900 text-[#00E676] font-bold border-l-4 border-[#00E676]' : 'bg-zinc-100 text-[#00C853] font-semibold border-l-4 border-[#00C853]';

  return (
    <div className={`h-screen w-screen flex items-center justify-center overflow-hidden select-none transition-all duration-300 ${
      isDark 
        ? 'bg-[#070707] text-zinc-100 bg-[radial-gradient(#1c1c1e_1px,transparent_1px)] [background-size:24px_24px]' 
        : 'bg-zinc-100 text-zinc-900 bg-[radial-gradient(#e4e4e7_1px,transparent_1px)] [background-size:24px_24px]'
    }`}>
      
      {/* Premium Smartphone Frame for desktop views, seamless 100% on actual mobile */}
      <div className={`relative flex flex-col h-full w-full overflow-hidden transition-all duration-500
        md:max-w-[430px] md:h-[92vh] md:max-h-[880px] md:rounded-[3.2rem] md:border-[12px] md:shadow-[0_35px_80px_-15px_rgba(0,0,0,0.95)]
        ${isDark 
          ? 'md:border-zinc-900 md:bg-[#0B0B0B] md:shadow-black' 
          : 'md:border-zinc-300 md:bg-white md:shadow-zinc-400/55'
        }
      `}>
        
        {/* Simulated iOS/Android style Status Bar */}
        <div className={`w-full h-8 flex items-center justify-between px-6 select-none shrink-0 border-b text-[10px] font-sans font-bold tracking-wider ${
          isDark 
            ? 'bg-[#161616] border-zinc-900 text-[#00E676]' 
            : 'bg-zinc-100 border-zinc-200 text-zinc-800'
        }`}>
          <span>14:01</span>
          
          {/* Speaker Notch for smartphone feel on desktop */}
          <div className="hidden md:block w-20 h-3 bg-zinc-900/60 rounded-full border border-zinc-800/10 self-center" />
          
          <div className="flex items-center gap-1.5">
            <SignalHigh className="h-3.5 w-3.5" />
            <span>5G</span>
            {batteryCharging ? (
              <BatteryCharging className="h-3.5 w-3.5 text-emerald-400 animate-pulse" />
            ) : (
              <Battery className={`h-3.5 w-3.5 ${batteryLevel <= 20 ? 'text-red-500 animate-pulse' : ''}`} />
            )}
            <span>{batteryLevel}%</span>
          </div>
        </div>

        {/* Absolute Toast Overlay */}
        <div className="absolute right-4 bottom-22 z-50 flex flex-col gap-2 pointer-events-none">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={`px-4 py-3 rounded-xl border shadow-2xl text-xs font-mono font-bold flex items-center gap-2 animate-bounce ${
                isDark ? 'bg-black/90 border-green-800 text-green-400' : 'bg-white border-blue-200 text-sky-900'
              }`}
            >
              <AlertCircle className="h-4 w-4 shrink-0 text-amber-500" />
              <span>{t.msg}</span>
            </div>
          ))}
        </div>

        {/* EMERGENCY SOS SAT INTRO TELEMETRY PANEL */}
        {sosActive && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 p-4 font-mono">
            <div className="max-w-md w-full bg-zinc-950 border border-red-500/40 p-6 rounded-2xl shadow-2xl space-y-5 text-center text-red-500 relative">
              <div className="flex justify-between items-center border-b border-red-950/40 pb-3 pr-14 relative min-h-[48px]">
                <span className="text-xs uppercase tracking-widest font-bold text-red-400">SATCOM RESCUE LINK</span>
                <button 
                  onClick={() => setSosActive(false)} 
                  className="absolute top-[-4px] right-0 h-12 w-12 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 active:scale-95 shadow-xl border border-red-900/50 bg-zinc-950 text-red-500 hover:bg-zinc-900 hover:text-red-400 focus:outline-none"
                  style={{ minWidth: '48px', minHeight: '48px' }}
                  aria-label="Abort SOS"
                  title="Abort"
                >
                  <X className="h-5 w-5 stroke-[2.5]" />
                </button>
              </div>

              <div className="relative inline-flex items-center justify-center">
                <span className="animate-ping absolute inline-flex h-12 w-12 rounded-full bg-red-500 opacity-60"></span>
                <Radio className="h-14 w-14 animate-pulse shrink-0 text-red-500" />
              </div>

              {!sosTransmitting ? (
                <div className="space-y-2">
                  <h3 className="text-lg font-black tracking-widest uppercase animate-pulse">INITIATING RESCUE BROADCAST</h3>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Broadcasting location payloads on marine frequencies and emergency satellite relays COSPAS-SARSAT.
                  </p>
                  <div className="text-3xl font-black text-white">{sosCountdown}s</div>
                  <div className="text-[10px] text-gray-500 uppercase">Click abort above to suppress alert</div>
                </div>
              ) : (
                <div className="space-y-4">
                  <h3 className="text-lg font-black tracking-widest uppercase text-white flex items-center justify-center gap-2 animate-pulse">
                    <SignalHigh className="h-5 w-5 text-red-500" /> TRANSMITTING SIGNALS
                  </h3>

                  <div className="p-3 bg-red-950/20 border border-red-900 rounded-xl space-y-1 text-xs text-red-300">
                    <div className="flex justify-between">
                      <span>CALLSIGN:</span> <span className="font-bold text-white">PEEZIGATOR-ALPHA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>GPS COORDINATES:</span>{' '}
                      <span className="font-bold text-white">
                        {gpsData.lat.toFixed(5)}°N, {gpsData.lng.toFixed(5)}°E
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>SECTOR BOUNDS:</span>{' '}
                      <span className="font-bold text-white">
                        X:{Math.round(gpsData.x)}% Y:{Math.round(gpsData.y)}%
                      </span>
                    </div>
                  </div>

                  <p className="text-[11px] text-stone-400">
                    Transmitter set to high voltage pulse. Morse strobe active. Position telemetry updates recursively. Stay on terrain ridges or high peaks!
                  </p>

                  <button
                    onClick={() => setSosActive(false)}
                    className="w-full bg-red-600 hover:bg-red-700 text-white text-xs font-bold py-3 uppercase tracking-widest rounded-xl transition-all cursor-pointer"
                  >
                    ABORT EMERGENCY BEACON
                  </button>
                </div>
              )}

              {/* EMERGENCY RESCUE DIRECTORY */}
              <div className="border-t border-red-950/40 pt-4 text-left space-y-2">
                <span className="text-[10px] uppercase tracking-widest font-black text-red-400 flex items-center gap-1.5">
                  🚨 OFFICIAL RESCUE DIRECTORY CONTACTS
                </span>
                <div className="grid grid-cols-2 gap-2 text-[9.5px] font-mono leading-tight">
                  <div className="bg-zinc-900/60 p-2 rounded-lg border border-red-950/20">
                    <div className="text-[7.5px] text-zinc-500 uppercase font-black">Universal Rescue</div>
                    <div className="font-bold text-white">911 / 112 / 999</div>
                  </div>
                  <div className="bg-zinc-900/60 p-2 rounded-lg border border-red-950/20">
                    <div className="text-[7.5px] text-zinc-500 uppercase font-black">SATCOM RCC (Global)</div>
                    <div className="font-bold text-white">+1 (613) 996-1616</div>
                  </div>
                  <div className="bg-zinc-900/60 p-2 rounded-lg border border-red-950/20">
                    <div className="text-[7.5px] text-zinc-500 uppercase font-black">Wilderness Hotline</div>
                    <div className="font-bold text-white">+1 (800) 855-4767</div>
                  </div>
                  <div className="bg-zinc-900/60 p-2 rounded-lg border border-red-950/20">
                    <div className="text-[7.5px] text-zinc-500 uppercase font-black">VHF Marine Radio</div>
                    <div className="font-bold text-white">Ch. 16 (156.8 MHz)</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SHARE LAST KNOWN POINT MODAL */}
        {isShareModalOpen && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 p-4 font-mono animate-in fade-in duration-200">
            <div className={`max-w-md w-full border p-5 rounded-2xl shadow-2xl space-y-4 text-left relative ${
              isDark 
                ? 'bg-zinc-950 border-green-950 text-green-400' 
                : 'bg-white border-sky-200 text-sky-900'
            }`}>
              {/* Header with X Close Button */}
              <div className="flex justify-between items-center border-b pb-2.5 relative min-h-[40px] border-zinc-800/30">
                <div className="flex items-center gap-1.5">
                  <Share2 className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span className="text-xs uppercase tracking-widest font-black">SHARE BEACON DATA</span>
                </div>
                <button 
                  onClick={() => setIsShareModalOpen(false)} 
                  className={`absolute top-[-4px] right-0 h-9 w-9 rounded-full flex items-center justify-center cursor-pointer transition-all duration-150 active:scale-95 border ${
                    isDark 
                      ? 'border-green-950 bg-zinc-900 text-green-400 hover:bg-zinc-800' 
                      : 'border-sky-100 bg-sky-50 text-sky-800 hover:bg-sky-100'
                  }`}
                  aria-label="Close Share Panel"
                  title="Close"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Description explanation */}
              <p className="text-[10px] leading-relaxed text-zinc-400">
                Generate and dispatch a compact text block containing current GPS coordinates, timestamp, and battery status for users to send via emergency messengers.
              </p>

              {/* Formatted Text Box */}
              <div className={`p-3 rounded-xl border font-mono text-[10.5px] leading-relaxed whitespace-pre-wrap select-all relative group ${
                isDark 
                  ? 'bg-black/40 border-zinc-900 text-green-300' 
                  : 'bg-zinc-50 border-zinc-200 text-zinc-800'
              }`}>
                {generateShareText()}
              </div>

              {/* Utility action row */}
              <div className="grid grid-cols-2 gap-2.5">
                {/* 1. Copy button */}
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generateShareText());
                    setCopied(true);
                    addToast('Beacon payload copied to clipboard!');
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    copied
                      ? 'bg-emerald-600 text-white border-emerald-500'
                      : (isDark 
                          ? 'bg-zinc-900 border border-green-950 text-green-400 hover:bg-zinc-850' 
                          : 'bg-sky-50 border border-sky-200 text-sky-800 hover:bg-sky-100')
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="h-4 w-4 text-white" />
                      <span>COPIED!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      <span>COPY TEXT</span>
                    </>
                  )}
                </button>

                {/* 2. Web Share API Button */}
                <button
                  onClick={() => {
                    const text = generateShareText();
                    if (navigator.share) {
                      navigator.share({
                        title: 'My Last Known Point - Peezigator',
                        text: text,
                      }).then(() => {
                        addToast('Shared successfully!');
                      }).catch((err) => {
                        console.log('Share failed:', err);
                      });
                    } else {
                      // Fallback copy
                      navigator.clipboard.writeText(text);
                      addToast('System share unavailable. Text copied to clipboard!');
                    }
                  }}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isDark 
                      ? 'bg-green-500 text-black font-extrabold hover:bg-green-400' 
                      : 'bg-sky-600 text-white font-semibold hover:bg-sky-700'
                  }`}
                >
                  <Share2 className="h-4 w-4" />
                  <span>SHARE LINK</span>
                </button>
              </div>

              {/* Direct offgrid messenger shortcuts */}
              <div className="space-y-1.5 pt-2 border-t border-zinc-800/30">
                <span className="text-[9px] uppercase tracking-wider font-bold text-zinc-400 font-mono block">Direct Messenger Shortcuts:</span>
                <div className="grid grid-cols-3 gap-2">
                  <a
                    href={`sms:?&body=${encodeURIComponent(generateShareText())}`}
                    className={`p-2 rounded-lg border text-[9px] font-bold text-center uppercase tracking-wider flex flex-col items-center gap-1 ${
                      isDark 
                        ? 'border-zinc-800/50 bg-zinc-900/40 text-green-400 hover:bg-zinc-850/50' 
                        : 'border-gray-200 bg-gray-50 text-sky-800 hover:bg-gray-100'
                    }`}
                  >
                    💬 SMS Body
                  </a>
                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent(generateShareText())}`}
                    target="_blank"
                    rel="noreferrer"
                    className={`p-2 rounded-lg border text-[9px] font-bold text-center uppercase tracking-wider flex flex-col items-center gap-1 ${
                      isDark 
                        ? 'border-zinc-800/50 bg-zinc-900/40 text-green-400 hover:bg-zinc-850/50' 
                        : 'border-gray-200 bg-gray-50 text-sky-800 hover:bg-gray-100'
                    }`}
                  >
                    🟢 WhatsApp
                  </a>
                  <a
                    href={`mailto:?subject=Peezigator%20Emergency%20Beacon&body=${encodeURIComponent(generateShareText())}`}
                    className={`p-2 rounded-lg border text-[9px] font-bold text-center uppercase tracking-wider flex flex-col items-center gap-1 ${
                      isDark 
                        ? 'border-zinc-800/50 bg-zinc-900/40 text-green-400 hover:bg-zinc-850/50' 
                        : 'border-gray-200 bg-gray-50 text-sky-800 hover:bg-gray-100'
                    }`}
                  >
                    ✉️ Email
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main App Bar Interface */}
        <header className={`flex items-center justify-between px-5 py-3 select-none shrink-0 ${isDark ? 'bg-[#0B131F] border-b border-zinc-800/80 text-white shadow-xl' : 'bg-white border-b border-gray-200 text-zinc-900'} relative`}>
          {/* Mockup burger menu */}
          <button 
            onClick={() => {
              setActivePanel('settings');
              addToast('Opening Settings sidebar menu');
            }}
            className={`p-2 rounded-xl transition-all hover:scale-105 active:scale-95 cursor-pointer ${
              isDark ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/40' : 'text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100'
            }`}
            title="Menu Settings"
          >
            <Menu className="h-6 w-6" />
          </button>

          {/* Central Branded Title block */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center text-center pointer-events-none select-none">
            <h1 className="text-base font-black tracking-[0.2em] uppercase font-sans flex items-center justify-center select-none text-white">
              PEE<span className="text-[#38B6FF]">ZI</span>GATOR
            </h1>
            <div className="flex items-center gap-1 text-[7px] tracking-wider font-black uppercase font-sans mt-0.5 select-none opacity-90">
              <span className="text-[#38B6FF]">NAVIGATE.</span>
              <span className="text-[#00E676]">SURVIVE.</span>
              <span className="text-[#EF4444]">RESCUE.</span>
            </div>
          </div>

          {/* Global Coordinates & Settings Shortcuts */}
          <div className="flex items-center gap-1.5 z-10">
            
            {/* Quick-toggle offline mode */}
            <button
              onClick={() => setSettings({ ...settings, offlineModeActive: !settings.offlineModeActive })}
              className={`flex items-center gap-1 px-2.5 py-1.5 text-[9px] font-sans font-bold rounded-lg border transition-all cursor-pointer select-none shadow-sm ${
                settings.offlineModeActive
                  ? 'bg-amber-600/90 text-white border-amber-500'
                  : (isDark ? 'bg-[#161616] border-zinc-800 text-[#00E676] hover:bg-zinc-900' : 'bg-transparent border-gray-300 text-zinc-750')
              }`}
              title="Toggle Hard Offline State"
            >
              <CloudOff className="h-3 w-3" />
              <span>{settings.offlineModeActive ? 'OFFLINE' : 'SAT-LINK'}</span>
            </button>

            {/* Device Battery Level Indicator */}
            <div className="relative">
              <button
                onClick={() => setShowBatteryManager(!showBatteryManager)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-[9px] font-sans font-bold rounded-lg border transition-all cursor-pointer select-none relative shadow-sm ${
                  showBatteryManager
                    ? (isDark ? 'bg-zinc-900 border-[#00E676] text-[#00E676]' : 'bg-zinc-100 border-zinc-400 text-zinc-900')
                    : (isDark ? 'bg-[#161616] border-zinc-800 text-white hover:bg-zinc-900' : 'bg-transparent border-gray-300 text-zinc-700')
                } ${batteryLevel <= 20 && !batteryCharging ? 'border-red-600 text-red-500 animate-pulse bg-red-950/20' : ''}`}
                title="Device Power Consumption Panel"
              >
                {batteryCharging ? (
                  <BatteryCharging className="h-3.5 w-3.5 text-[#00E676] animate-bounce" />
                ) : batteryLevel <= 20 ? (
                  <Battery className="h-3.5 w-3.5 text-[#EF4444]" />
                ) : batteryLevel <= 50 ? (
                  <Battery className="h-3.5 w-3.5 text-[#F59E0B]" />
                ) : (
                  <Battery className="h-3.5 w-3.5 text-[#00E676]" />
                )}
                <span>{batteryLevel}%</span>
              </button>

              {/* BATTERY DIAGNOSTIC CONTROL PANEL TOOLTIP */}
              {showBatteryManager && (
                <div 
                  className={`absolute top-10 right-0 w-72 p-4 rounded-2xl border shadow-2xl z-50 transition-all font-sans leading-relaxed ${
                    isDark ? 'bg-black/95 border-green-950 text-white shadow-green-950/20' : 'bg-white border-gray-200 text-gray-800 shadow-gray-250/20'
                  }`}
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between border-b pb-2 mb-3 border-gray-700/10">
                    <div className="flex items-center gap-1.5">
                      <Zap className={`h-4 w-4 ${isDark ? 'text-green-400' : 'text-sky-600'}`} />
                      <h3 className="text-[10px] font-black tracking-wider uppercase">Power Diagnostics</h3>
                    </div>
                    <button 
                      onClick={() => setShowBatteryManager(false)}
                      className="opacity-50 hover:opacity-100 p-1 cursor-pointer"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {/* Big charge meter read-out */}
                  <div className={`flex items-center justify-between mb-3 p-3 rounded-xl border border-gray-750/10 ${isDark ? 'bg-zinc-950/20' : 'bg-sky-50/30'}`}>
                    <div className="space-y-0.5 text-left">
                      <span className="text-[9px] text-gray-400 uppercase tracking-wider block font-mono">CHARGE ACCUMULATOR</span>
                      <span className="text-lg font-black tracking-tight flex items-baseline gap-1">
                        {batteryLevel}%
                        <span className="text-[9px] font-mono font-medium opacity-65">
                          {batteryCharging ? '(Solar)' : '(Drain)'}
                        </span>
                      </span>
                    </div>
                    <div className="relative">
                      {batteryCharging ? (
                        <BatteryCharging className={`h-6 w-6 ${batteryLevel <= 20 ? 'text-red-500 animate-pulse' : (batteryLevel <= 50 ? 'text-amber-500' : 'text-green-400')}`} />
                      ) : (
                        <Battery className={`h-6 w-6 ${batteryLevel <= 20 ? 'text-red-500 animate-pulse' : (batteryLevel <= 50 ? 'text-amber-500' : 'text-green-400')}`} />
                      )}
                    </div>
                  </div>

                  {/* Tactical Power Saving Toggle */}
                  <div className="space-y-2 border-b border-gray-700/10 pb-3 mb-3">
                    <button
                      onClick={() => setSettings({ ...settings, powerSaverMode: !settings.powerSaverMode })}
                      className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                        settings.powerSaverMode
                          ? (isDark ? 'bg-green-950/50 border-green-500 text-green-300' : 'bg-sky-50 border-sky-400 text-sky-850')
                          : (isDark ? 'border-zinc-805 bg-neutral-900/10 text-gray-400' : 'border-gray-200 bg-white text-gray-500')
                      }`}
                    >
                      <div className="text-left">
                        <span className="block text-[10px] font-extrabold uppercase tracking-wide">Power Saver</span>
                        <span className="text-[8px] opacity-75 font-mono block">GPS sync updates throttled {settings.powerSaverMode ? '(120s)' : '(5s)'}</span>
                      </div>
                      <div className={`w-7 h-4 rounded-full p-0.5 transition-colors duration-200 ${settings.powerSaverMode ? (isDark ? 'bg-green-500' : 'bg-sky-600') : 'bg-gray-400'}`}>
                        <div className={`bg-white w-3 h-3 rounded-full shadow-md transform duration-200 ${settings.powerSaverMode ? 'translate-x-3' : 'translate-x-0'}`} />
                      </div>
                    </button>
                  </div>

                  {/* Simulated solar exposure / external block controls */}
                  <div className="space-y-2.5">
                    <div className="space-y-1 text-left">
                      <label className="text-[9px] text-gray-400 uppercase tracking-widest font-mono block">Simulate Power Reserves</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={batteryLevel}
                          onChange={(e) => setBatteryLevel(parseInt(e.target.value, 10))}
                          className="flex-1 accent-green-500 cursor-pointer h-1 rounded-lg bg-gray-700/20"
                        />
                        <span className="text-[10px] font-mono font-bold w-8 text-right">{batteryLevel}%</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-1">
                      <span className="text-[10px] font-semibold text-gray-400">Power Source</span>
                      <button
                        onClick={() => setBatteryCharging(!batteryCharging)}
                        className={`px-2 py-1 rounded-lg text-[8px] font-bold uppercase tracking-wider transition-all cursor-pointer border ${
                          batteryCharging
                            ? 'bg-green-500 text-black border-green-405'
                            : (isDark ? 'bg-zinc-900 border-zinc-800 text-gray-400 hover:text-white' : 'bg-gray-100 border-gray-200 text-gray-600 hover:text-gray-900')
                        }`}
                      >
                        {batteryCharging ? '🔌 SOLAR BLOCK' : '🔋 DRAIN'}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* SHARE LAST KNOWN POINT TRIGGER */}
            <button
              onClick={() => {
                setIsShareModalOpen(true);
                setCopied(false);
              }}
              className={`flex items-center gap-1 px-2.5 py-1 text-[9px] font-mono font-bold rounded-lg border transition-all cursor-pointer select-none ${
                isDark
                  ? 'bg-zinc-900 border-green-950 text-green-400 hover:bg-zinc-800'
                  : 'bg-transparent border-sky-450 text-sky-100 hover:bg-sky-700/50'
              }`}
              title="Share Last Known Point Payload"
            >
              <Share2 className="h-3.5 w-3.5" />
              <span>SHARE</span>
            </button>

            {/* EMERGENCY SOS TRIGGER - Mockup Bell Design */}
            <button
              onClick={() => {
                setActivePanel('emergency');
                addToast('Emergency SOS Hub activated');
              }}
              className={`p-2 rounded-xl transition-all hover:scale-105 active:scale-95 cursor-pointer relative ${
                isDark ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/40' : 'text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100'
              }`}
              title="Trigger emergency offgrid distress beacon"
            >
              <Bell className="h-6 w-6" />
              {/* Active emergency signal notification indicator dot */}
              <span className="absolute top-1.5 right-1.5 h-2.5 w-2.5 rounded-full bg-rose-500 ring-2 ring-[#0B131F] animate-pulse" />
            </button>
          </div>
        </header>

        {/* Core Platform Layout */}
        <div className="flex-1 flex overflow-hidden relative">
          
          {/* Continuous edge-to-edge interactive Map and Floating Details Card */}
          <main className="flex-1 h-full overflow-hidden relative w-full z-0">
            
            {/* Continuous Full-Screen Map Viewport */}
            <div className="absolute inset-0 w-full h-full z-0">
              <InteractiveMap
                offlineMaps={offlineMaps}
                waypoints={waypoints}
                routes={routes}
                selectedRoute={selectedRoute}
                selectedWaypoint={selectedWaypoint}
                onSelectWaypoint={(wp) => {
                  setSelectedWaypoint(wp);
                  if (wp) {
                    setGpsData({
                      x: wp.x,
                      y: wp.y,
                      lat: wp.latitude,
                      lng: wp.longitude,
                      heading: 0,
                    });
                  }
                }}
                onMapClickToAddWaypoint={handleMapClickToAddWaypoint}
                settings={settings}
                currentGPS={gpsData}
                onUpdateGPS={handleUpdateGPS}
                // Interactive drawn routes
                routeBuilderActive={routeBuilderActive}
                routeBuilderPoints={routeBuilderPoints}
                onAddRouteBuilderPoint={(pt) => setRouteBuilderPoints((prev) => [...prev, pt])}
                onToggleRouteBuilder={setRouteBuilderActive}
                onClearRouteBuilderPoints={handleClearRouteBuilderPoints}
                // Navigation sessions
                navigationActive={navigationActive}
                onToggleNavigation={setNavigationActive}
                voiceMuted={voiceMuted}
                onSetVoiceMuted={setVoiceMuted}
                voiceVolume={voiceVolume}
                onSetVoiceVolume={setVoiceVolume}
                voiceLanguage={voiceLanguage}
                onSetVoiceLanguage={setVoiceLanguage}
                onActivePanelChange={setActivePanel}
                onUpdateSettings={setSettings}
                activePanel={activePanel}
              />
            </div>

            {/* Floating details panel for tabs other than raw 'map' */}
            {activePanel !== 'map' && (
              <div className={`absolute z-10 flex flex-col overflow-hidden backdrop-blur-lg border shadow-3xl rounded-[2rem] transition-all duration-300 left-3 right-3 bottom-4 top-4 ${
                isDark 
                  ? 'border-zinc-800/60 bg-[#08131F]/95 text-[#00E676] shadow-[0_25px_60px_rgba(0,0,0,0.9)]' 
                  : 'border-gray-200/85 bg-white/94 text-zinc-900 shadow-[0_20px_50px_rgba(0,0,0,0.18)]'
              }`}>
                
                {/* Standard Mobile App Bar (Header) with standard close button */}
                <div className={`flex items-center justify-between px-5 py-3.5 border-b shrink-0 min-h-[52px] ${
                  isDark ? 'bg-[#111827]/80 border-zinc-800/80' : 'bg-white border-gray-200'
                }`}>
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-[#00E676] animate-pulse shadow-[0_0_8px_#00E676]"></span>
                    <span className={`text-[10px] font-sans font-black uppercase tracking-widest ${
                      isDark ? 'text-zinc-200' : 'text-zinc-600'
                    }`}>
                      {activePanel === 'routes' ? 'Trails Planner' : 
                       activePanel === 'waypoints' ? 'Waypoints Pin' : 
                       activePanel === 'trips' ? 'Trip Expeditions' : 
                       activePanel === 'downloads' ? 'Downloaded Packs' : 
                       activePanel === 'profile' || activePanel === 'auth' ? 'Explorer Profile' : 
                       activePanel === 'settings' ? 'Preferences' : 
                       activePanel === 'telemetry' ? 'Telemetry Sensors' : 
                       activePanel === 'emergency' ? 'Emergency Rescue Link' : 
                       activePanel === 'sync' ? 'Mesh Radio P2P Sync' : `${activePanel} View`}                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setActivePanel('map');
                      setPlacementPendingCoords(null);
                    }}
                    className={`h-8 w-8 rounded-full flex items-center justify-center transition-all duration-150 active:scale-95 border cursor-pointer ${
                      isDark 
                        ? 'bg-[#182433] border-zinc-800 text-zinc-300 hover:text-white hover:bg-[#111827]' 
                        : 'bg-gray-100 border-gray-250 text-gray-750 hover:text-black hover:bg-gray-150'
                    }`}
                    aria-label="Close"
                    title="Close"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                {/* Dynamic Panel Content routers */}
                <div className="flex-1 overflow-hidden h-full">
                  {activePanel === 'routes' && (
                    <RoutePlanner
                      routes={routes}
                      waypoints={waypoints}
                      selectedRoute={selectedRoute}
                      onSelectRoute={setSelectedRoute}
                      onAddRoute={handleAddRoute}
                      onRemoveRoute={handleRemoveRoute}
                      onEditRoute={handleEditRoute}
                      settings={settings}
                      currentUserEmail={currentUser?.email || 'Guest Explorer'}
                      routeBuilderActive={routeBuilderActive}
                      routeBuilderPoints={routeBuilderPoints}
                      onToggleRouteBuilder={setRouteBuilderActive}
                      onClearRouteBuilderPoints={handleClearRouteBuilderPoints}
                    />
                  )}

                  {activePanel === 'waypoints' && (
                    <WaypointModal
                      waypoints={waypoints}
                      selectedWaypoint={selectedWaypoint}
                      onSelectWaypoint={(wp) => {
                        setSelectedWaypoint(wp);
                        if (wp) {
                          setGpsData({
                            x: wp.x,
                            y: wp.y,
                            lat: wp.latitude,
                            lng: wp.longitude,
                            heading: 0,
                          });
                        }
                      }}
                      onAddWaypoint={handleAddWaypoint}
                      onRemoveWaypoint={handleRemoveWaypoint}
                      onEditWaypoint={handleEditWaypoint}
                      currentUserEmail={currentUser?.email || 'Guest Explorer'}
                      settings={settings}
                      placementPendingCoords={placementPendingCoords}
                      onCancelPlacement={() => setPlacementPendingCoords(null)}
                    />
                  )}

                  {activePanel === 'trips' && (
                    <TripPlanner
                      trips={trips}
                      routes={routes}
                      waypoints={waypoints}
                      onAddTrip={handleAddTrip}
                      onRemoveTrip={handleRemoveTrip}
                      onSelectRoute={(r) => { setSelectedRoute(r); setActivePanel('map'); }}
                      onSelectWaypoint={(wp) => {
                        setSelectedWaypoint(wp);
                        if (wp) {
                          setGpsData({
                            x: wp.x,
                            y: wp.y,
                            lat: wp.latitude,
                            lng: wp.longitude,
                            heading: 0,
                          });
                          setActivePanel('map');
                        }
                      }}
                      settings={settings}
                      currentUserEmail={currentUser?.email || 'Guest Explorer'}
                    />
                  )}

                  {activePanel === 'downloads' && (
                    <DownloadManager
                      offlineMaps={offlineMaps}
                      onDownloadMap={handleDownloadMap}
                      onDeleteMap={handleDeleteMap}
                      settings={settings}
                    />
                  )}

                  {(activePanel === 'profile' || activePanel === 'auth') && (
                    <AuthModal
                      currentUser={currentUser}
                      onLogin={handleLogin}
                      onLogout={handleLogout}
                      onUpdateProfile={handleUpdateProfile}
                      settings={settings}
                      onUpdateSettings={setSettings}
                    />
                  )}

                  {activePanel === 'settings' && (
                    <SettingsPage
                      settings={settings}
                      onUpdateSettings={setSettings}
                      voiceLanguage={voiceLanguage}
                      onSetVoiceLanguage={setVoiceLanguage}
                      voiceVolume={voiceVolume}
                      onSetVoiceVolume={setVoiceVolume}
                      voiceMuted={voiceMuted}
                      onSetVoiceMuted={setVoiceMuted}
                      onActivePanelChange={setActivePanel}
                    />
                  )}

                  {activePanel === 'telemetry' && (
                    <TelemetryPage
                      currentGPS={gpsData}
                      isDark={isDark}
                      settings={settings}
                      onUpdateGPS={handleUpdateGPS}
                    />
                  )}

                  {activePanel === 'emergency' && (
                    <EmergencyDashboard
                      currentGPS={gpsData}
                      batteryLevel={batteryLevel}
                      batteryCharging={batteryCharging}
                      isDark={isDark}
                      onClose={() => setActivePanel('map')}
                      addToast={addToast}
                      onActivePanelChange={setActivePanel}
                    />
                  )}

                  {activePanel === 'sync' && (
                    <P2PSyncPanel
                      routes={routes}
                      waypoints={waypoints}
                      onSyncData={handleSyncP2PData}
                      isDark={isDark}
                      addToast={addToast}
                    />
                  )}
                </div>
              </div>
            )}

          </main>
        </div>

        {/* Navigation Mobile Bottom Bar (Sleek tabs interface) */}
        <footer className={`flex items-center justify-around select-none py-3.5 px-2 shrink-0 border-t transition-all ${
          isDark ? 'bg-[#161616] border-zinc-850/80 text-[#00E676]' : 'bg-white border-zinc-200 text-zinc-800'
        }`}>
          <button
            onClick={() => { setActivePanel('map'); setPlacementPendingCoords(null); }}
            className={`flex flex-col items-center gap-1 text-[9.5px] font-sans font-medium transition-all duration-200 cursor-pointer ${
              activePanel === 'map' 
                ? (isDark ? 'text-[#00E676] scale-105 font-bold' : 'text-emerald-600 scale-105 font-bold') 
                : (isDark ? 'text-zinc-500 hover:text-white' : 'text-zinc-500 hover:text-zinc-900')
            }`}
          >
            <Map className="h-5 w-5" />
            <span>Home</span>
          </button>

          <button
            onClick={() => setActivePanel('routes')}
            className={`flex flex-col items-center gap-1 text-[9.5px] font-sans font-medium transition-all duration-200 cursor-pointer ${
              activePanel === 'routes' 
                ? (isDark ? 'text-[#00E676] scale-105 font-bold' : 'text-emerald-600 scale-105 font-bold') 
                : (isDark ? 'text-zinc-500 hover:text-white' : 'text-zinc-500 hover:text-zinc-900')
            }`}
          >
            <Navigation className="h-5 w-5" />
            <span>Navigate</span>
          </button>

          <button
            onClick={() => setActivePanel('trips')}
            className={`flex flex-col items-center gap-1 text-[9.5px] font-sans font-medium transition-all duration-200 cursor-pointer ${
              activePanel === 'trips' 
                ? (isDark ? 'text-[#00E676] scale-105 font-bold' : 'text-emerald-600 scale-105 font-bold') 
                : (isDark ? 'text-zinc-500 hover:text-white' : 'text-zinc-500 hover:text-zinc-900')
            }`}
          >
            <Compass className="h-5 w-5" />
            <span>Trips</span>
          </button>

          <button
            onClick={() => setActivePanel('downloads')}
            className={`flex flex-col items-center gap-1 text-[9.5px] font-sans font-medium transition-all duration-200 cursor-pointer ${
              activePanel === 'downloads' 
                ? (isDark ? 'text-[#00E676] scale-105 font-bold' : 'text-emerald-600 scale-105 font-bold') 
                : (isDark ? 'text-zinc-500 hover:text-white' : 'text-zinc-500 hover:text-zinc-900')
            }`}
          >
            <Download className="h-5 w-5" />
            <span>Offline</span>
          </button>

          <button
            onClick={() => setActivePanel('sync')}
            className={`flex flex-col items-center gap-1 text-[9.5px] font-sans font-medium transition-all duration-200 cursor-pointer ${
              activePanel === 'sync' 
                ? (isDark ? 'text-[#00E676] scale-105 font-bold' : 'text-emerald-600 scale-105 font-bold') 
                : (isDark ? 'text-zinc-500 hover:text-white' : 'text-zinc-500 hover:text-zinc-900')
            }`}
          >
            <Radio className="h-5 w-5" />
            <span>P2P Sync</span>
          </button>

          <button
            onClick={() => setActivePanel('settings')}
            className={`flex flex-col items-center gap-1 text-[9.5px] font-sans font-medium transition-all duration-200 cursor-pointer ${
              activePanel === 'settings' 
                ? (isDark ? 'text-[#00E676] scale-105 font-bold' : 'text-emerald-600 scale-105 font-bold') 
                : (isDark ? 'text-zinc-500 hover:text-white' : 'text-zinc-500 hover:text-zinc-900')
            }`}
          >
            <SettingsIcon className="h-5 w-5" />
            <span>Settings</span>
          </button>
        </footer>
      </div>
    </div>
  );
}
