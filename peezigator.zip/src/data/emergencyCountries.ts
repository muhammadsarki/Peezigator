/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CountryEmergencyData {
  countryName: string;
  isoCode: string; // ISO 3166-1 alpha-2
  police: string;
  ambulance: string;
  fireService: string;
  coastGuard: string;
  searchRescue: string;
  redCrossCrescent: string;
  iom: string;
  mrcc: string;
  desertRescue: string;
  centerLat: number;
  centerLng: number;
  flag: string;
}

export const EMERGENCY_COUNTRIES_DATABASE: CountryEmergencyData[] = [
  {
    countryName: "Algeria",
    isoCode: "DZ",
    police: "17",
    ambulance: "14",
    fireService: "14",
    coastGuard: "112",
    searchRescue: "+213 21 71 14 14",
    redCrossCrescent: "+213 21 63 31 55",
    iom: "+213 23 50 88 82",
    mrcc: "+213 21 71 83 83",
    desertRescue: "+213 29 30 11 12",
    centerLat: 28.0339,
    centerLng: 1.6596,
    flag: "🇩🇿"
  },
  {
    countryName: "Nigeria",
    isoCode: "NG",
    police: "112",
    ambulance: "112",
    fireService: "112",
    coastGuard: "+234 1 271 3911",
    searchRescue: "+234 803 200 3555",
    redCrossCrescent: "+234 9 290 2315",
    iom: "+234 814 067 1122",
    mrcc: "+234 1 270 3920",
    desertRescue: "Not Applicable",
    centerLat: 9.0820,
    centerLng: 8.6753,
    flag: "🇳🇬"
  },
  {
    countryName: "Libya",
    isoCode: "LY",
    police: "193",
    ambulance: "191",
    fireService: "190",
    coastGuard: "112",
    searchRescue: "+218 21 444 8000",
    redCrossCrescent: "+218 21 334 1414",
    iom: "+218 21 477 7222",
    mrcc: "+218 21 444 1400",
    desertRescue: "+218 91 220 3344",
    centerLat: 26.3351,
    centerLng: 17.2283,
    flag: "🇱🇾"
  },
  {
    countryName: "United States",
    isoCode: "US",
    police: "911",
    ambulance: "911",
    fireService: "911",
    coastGuard: "+1 202-372-2100",
    searchRescue: "+1 800-424-8802",
    redCrossCrescent: "+1 800-733-2767",
    iom: "+1 202-862-1826",
    mrcc: "+1 757-398-6390",
    desertRescue: "+1 760-384-5665",
    centerLat: 37.0902,
    centerLng: -95.7129,
    flag: "🇺🇸"
  },
  {
    countryName: "United Kingdom",
    isoCode: "GB",
    police: "999",
    ambulance: "999",
    fireService: "999",
    coastGuard: "999",
    searchRescue: "+44 20 7008 5000",
    redCrossCrescent: "+44 344 871 11 11",
    iom: "+44 20 7811 6000",
    mrcc: "+44 23 8032 9000",
    desertRescue: "Not Applicable",
    centerLat: 55.3781,
    centerLng: -3.4360,
    flag: "🇬🇧"
  },
  {
    countryName: "Australia",
    isoCode: "AU",
    police: "000",
    ambulance: "000",
    fireService: "000",
    coastGuard: "000",
    searchRescue: "+61 2 6230 6811",
    redCrossCrescent: "1800 733 276",
    iom: "+61 2 6267 6600",
    mrcc: "+61 2 6279 5000",
    desertRescue: "+61 8 8951 8888",
    centerLat: -25.2744,
    centerLng: 133.7751,
    flag: "🇦🇺"
  },
  {
    countryName: "Canada",
    isoCode: "CA",
    police: "911",
    ambulance: "911",
    fireService: "911",
    coastGuard: "+1 800-267-7270",
    searchRescue: "+1 800-852-3100",
    redCrossCrescent: "+1 800-418-1111",
    iom: "+1 613-237-0651",
    mrcc: "+1 709-772-5151",
    desertRescue: "Not Applicable",
    centerLat: 56.1304,
    centerLng: -106.3468,
    flag: "🇨🇦"
  },
  {
    countryName: "Egypt",
    isoCode: "EG",
    police: "122",
    ambulance: "123",
    fireService: "180",
    coastGuard: "112",
    searchRescue: "+20 2 2404 4444",
    redCrossCrescent: "+20 2 2634 0101",
    iom: "+20 2 2736 5147",
    mrcc: "+20 2 461 4000",
    desertRescue: "+20 100 123 4567",
    centerLat: 26.8206,
    centerLng: 30.8025,
    flag: "🇪🇬"
  },
  {
    countryName: "Niger",
    isoCode: "NE",
    police: "17",
    ambulance: "15",
    fireService: "18",
    coastGuard: "Not Applicable",
    searchRescue: "+227 20 73 31 11",
    redCrossCrescent: "+227 20 73 30 19",
    iom: "+227 20 75 22 22",
    mrcc: "Not Applicable",
    desertRescue: "+227 96 40 41 42",
    centerLat: 17.6078,
    centerLng: 8.0817,
    flag: "🇳🇪"
  },
  {
    countryName: "Mali",
    isoCode: "ML",
    police: "17",
    ambulance: "15",
    fireService: "18",
    coastGuard: "Not Applicable",
    searchRescue: "+223 20 22 40 10",
    redCrossCrescent: "+223 20 22 21 02",
    iom: "+223 20 29 22 90",
    mrcc: "Not Applicable",
    desertRescue: "+223 76 50 12 34",
    centerLat: 17.5707,
    centerLng: -3.9962,
    flag: "🇲🇱"
  },
  {
    countryName: "Morocco",
    isoCode: "MA",
    police: "19",
    ambulance: "15",
    fireService: "15",
    coastGuard: "112",
    searchRescue: "+212 537 671 010",
    redCrossCrescent: "+212 537 651 111",
    iom: "+212 537 652 881",
    mrcc: "+212 522 201 515",
    desertRescue: "+212 661 123 456",
    centerLat: 31.7917,
    centerLng: -7.0926,
    flag: "🇲🇦"
  },
  {
    countryName: "Switzerland",
    isoCode: "CH",
    police: "117",
    ambulance: "144",
    fireService: "118",
    coastGuard: "Not Applicable",
    searchRescue: "1414",
    redCrossCrescent: "+41 58 400 41 11",
    iom: "+41 22 717 91 11",
    mrcc: "Not Applicable",
    desertRescue: "Not Applicable",
    centerLat: 46.8182,
    centerLng: 8.2275,
    flag: "🇨🇭"
  }
];

/**
 * Calculates the great-circle distance between two points on the Earth's surface using the Haversine formula.
 */
export function calculateHaversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Finds the closest country in our database based on the provided latitude and longitude.
 */
export function getClosestCountryByCoordinates(lat: number, lng: number): CountryEmergencyData {
  let closest: CountryEmergencyData = EMERGENCY_COUNTRIES_DATABASE[0];
  let minDistance = Infinity;

  for (const country of EMERGENCY_COUNTRIES_DATABASE) {
    const dist = calculateHaversineDistance(lat, lng, country.centerLat, country.centerLng);
    if (dist < minDistance) {
      minDistance = dist;
      closest = country;
    }
  }

  return closest;
}

/**
 * Generates/retrieves standard country emergency contacts based on code as a general fallback
 */
export function getFallbackCountryByIsoCode(isoCode: string, name?: string): CountryEmergencyData {
  const code = isoCode.toUpperCase();
  const matched = EMERGENCY_COUNTRIES_DATABASE.find(c => c.isoCode === code);
  if (matched) return matched;

  // Otherwise return standard fallback
  return {
    countryName: name || `Country (${code})`,
    isoCode: code,
    police: "112",
    ambulance: "112",
    fireService: "112",
    coastGuard: "112",
    searchRescue: "112",
    redCrossCrescent: "112",
    iom: "Not Available",
    mrcc: "Not Available",
    desertRescue: "Not Applicable",
    centerLat: 0,
    centerLng: 0,
    flag: "🌍"
  };
}
