/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { OfflineMap, Route, Waypoint, Trip } from '../types';

export const DEFAULT_OFFLINE_MAPS: OfflineMap[] = [
  {
    id: 'sahara',
    name: 'Sahara Sandhills',
    region: 'North Africa, Remote Al-Kufrah',
    size: 42.5,
    downloadStatus: 'downloaded', // Start preloaded so we have map graphics instantly
    progress: 100,
    lastUpdated: '2026-06-15',
    boundingBox: { minX: 5, maxX: 45, minY: 5, maxY: 45 },
    features: [
      {
        type: 'contour',
        elevation: 350,
        points: [
          { x: 10, y: 15 }, { x: 15, y: 22 }, { x: 25, y: 18 }, { x: 30, y: 35 }, { x: 40, y: 28 }
        ]
      },
      {
        type: 'contour',
        elevation: 420,
        points: [
          { x: 13, y: 18 }, { x: 18, y: 25 }, { x: 23, y: 21 }, { x: 28, y: 32 }, { x: 38, y: 26 }
        ]
      },
      {
        type: 'trail',
        name: 'Caravan Oasis Route',
        points: [
          { x: 8, y: 10 }, { x: 15, y: 15 }, { x: 20, y: 30 }, { x: 35, y: 32 }, { x: 44, y: 40 }
        ]
      },
      {
        type: 'river',
        name: 'Wadi Al-Ajal (Seasonal Creek)',
        points: [
          { x: 5, y: 30 }, { x: 12, y: 28 }, { x: 22, y: 29 }, { x: 32, y: 24 }, { x: 40, y: 10 }
        ]
      }
    ]
  },
  {
    id: 'zion',
    name: 'Zion Slot Canyons',
    region: 'Utah, Remote Wilderness Reserve',
    size: 68.1,
    downloadStatus: 'not_downloaded',
    progress: 0,
    boundingBox: { minX: 45, maxX: 95, minY: 5, maxY: 45 },
    features: [
      {
        type: 'coastline',
        points: [
          { x: 48, y: 5 }, { x: 52, y: 15 }, { x: 58, y: 22 }, { x: 62, y: 38 }, { x: 70, y: 45 }
        ]
      },
      {
        type: 'contour',
        elevation: 1200,
        points: [
          { x: 55, y: 8 }, { x: 65, y: 12 }, { x: 75, y: 22 }, { x: 80, y: 18 }, { x: 92, y: 25 }
        ]
      },
      {
        type: 'contour',
        elevation: 1450,
        points: [
          { x: 58, y: 10 }, { x: 68, y: 15 }, { x: 73, y: 25 }, { x: 78, y: 21 }, { x: 90, y: 28 }
        ]
      },
      {
        type: 'trail',
        name: 'Narrows Overlook Ridge',
        points: [
          { x: 50, y: 35 }, { x: 62, y: 30 }, { x: 72, y: 20 }, { x: 85, y: 15 }, { x: 93, y: 10 }
        ]
      }
    ]
  },
  {
    id: 'chamonix',
    name: 'Chamonix Glacial Pass',
    region: 'Western Alps, High Altitudes',
    size: 112.4,
    downloadStatus: 'not_downloaded',
    progress: 0,
    boundingBox: { minX: 5, maxX: 45, minY: 45, maxY: 95 },
    features: [
      {
        type: 'contour',
        elevation: 3200,
        points: [
          { x: 10, y: 50 }, { x: 14, y: 65 }, { x: 22, y: 72 }, { x: 30, y: 75 }, { x: 42, y: 85 }
        ]
      },
      {
        type: 'contour',
        elevation: 3800,
        points: [
          { x: 12, y: 52 }, { x: 16, y: 67 }, { x: 24, y: 74 }, { x: 32, y: 77 }, { x: 44, y: 87 }
        ]
      },
      {
        type: 'river',
        name: 'Mer de Glace Crevasse Creek',
        points: [
          { x: 35, y: 50 }, { x: 28, y: 65 }, { x: 20, y: 78 }, { x: 15, y: 85 }, { x: 8, y: 92 }
        ]
      },
      {
        type: 'trail',
        name: 'Grand Balcon Tunnel Pathway',
        points: [
          { x: 8, y: 55 }, { x: 18, y: 60 }, { x: 25, y: 70 }, { x: 35, y: 85 }, { x: 42, y: 90 }
        ]
      }
    ]
  },
  {
    id: 'mariana',
    name: 'Mariana Blue Archipelago',
    region: 'Western Pacific Ocean Trench',
    size: 34.0,
    downloadStatus: 'not_downloaded',
    progress: 0,
    boundingBox: { minX: 45, maxX: 95, minY: 45, maxY: 95 },
    features: [
      {
        type: 'coastline',
        points: [
          { x: 50, y: 50 }, { x: 60, y: 55 }, { x: 65, y: 65 }, { x: 60, y: 75 }, { x: 55, y: 85 }, { x: 50, y: 90 }
        ]
      },
      {
        type: 'contour',
        elevation: -5500, // Bathymetry!
        points: [
          { x: 70, y: 55 }, { x: 80, y: 65 }, { x: 85, y: 75 }, { x: 80, y: 85 }, { x: 75, y: 92 }
        ]
      },
      {
        type: 'trail',
        name: 'Deepwater Reef Navigation Axis',
        points: [
          { x: 48, y: 55 }, { x: 58, y: 64 }, { x: 68, y: 72 }, { x: 74, y: 82 }, { x: 88, y: 90 }
        ]
      }
    ]
  }
];

export const DEFAULT_WAYPOINTS: Waypoint[] = [
  // Sahara Region
  {
    id: 'wp1',
    name: 'Al-Khidr Ancient Well',
    latitude: 24.1204,
    longitude: 21.8492,
    category: 'Water Source',
    notes: 'Groundwater pump works manually. Water is rich in sulfur, requires micro-filtering.',
    createdBy: 'Muhammadhudutahir@gmail.com',
    dateCreated: '2026-06-21',
    x: 15,
    y: 15,
    photoUrl: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=300&q=80',
    rating: 4,
    isFavorite: true
  },
  {
    id: 'wp2',
    name: 'Dunes Edge Camp',
    latitude: 24.1843,
    longitude: 21.9054,
    category: 'Campsite',
    notes: 'Protected from northern winds under sandstone ridge. Perfect setting for overnight stops.',
    createdBy: 'Muhammadhudutahir@gmail.com',
    dateCreated: '2026-06-21',
    x: 20,
    y: 30,
    photoUrl: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=300&q=80',
    rating: 5,
    isFavorite: true
  },
  {
    id: 'wp3',
    name: 'Pass Horizon Checkpoint',
    latitude: 24.2341,
    longitude: 22.0210,
    category: 'Checkpoint',
    notes: 'High clearance required. Ensure tire pressure is down to 1.1 bar before traversing.',
    createdBy: 'Muhammadhudutahir@gmail.com',
    dateCreated: '2026-06-22',
    x: 35,
    y: 32,
    rating: 3,
    isFavorite: false
  },
  // Chamonix area (will show up when downloaded, or on map grid)
  {
    id: 'wp4',
    name: 'Glacial Crevice Rescue Locker',
    latitude: 45.9227,
    longitude: 6.8685,
    category: 'Emergency Point',
    notes: 'Equipped with rescue sled, ropes, beacons, and shelf-stable rations.',
    createdBy: 'Muhammadhudutahir@gmail.com',
    dateCreated: '2026-06-22',
    x: 18,
    y: 60,
    photoUrl: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=300&q=80',
    rating: 5,
    isFavorite: false
  }
];

export const DEFAULT_ROUTES: Route[] = [
  {
    id: 'route1',
    name: 'Caravan Sand Express',
    startLocation: 'Al-Khidr Ancient Well',
    destination: 'Pass Horizon Checkpoint',
    distance: 34.2,
    duration: '6h 45m',
    createdBy: 'Muhammadhudutahir@gmail.com',
    dateCreated: '2026-06-22',
    coordinates: [
      { x: 15, y: 15 },
      { x: 20, y: 30 },
      { x: 35, y: 32 }
    ],
    mode: 'Desert Off-Road'
  },
  {
    id: 'route2',
    name: 'Glacial Ridge Summit Traverse',
    startLocation: 'Glacial Crevice Rescue Locker',
    destination: 'High Ridge Peak',
    distance: 14.8,
    duration: '4h 15m',
    createdBy: 'Muhammadhudutahir@gmail.com',
    dateCreated: '2026-06-23',
    coordinates: [
      { x: 18, y: 60 },
      { x: 25, y: 70 },
      { x: 42, y: 90 }
    ],
    mode: 'Walking'
  }
];

export const DEFAULT_TRIPS: Trip[] = [
  {
    id: 'trip1',
    name: 'Sahara Solstice Survival Run',
    description: 'A multi-day trekking traverse inspecting water availability, traveling along ancient camel pathways.',
    routeIds: ['route1'],
    waypointIds: ['wp1', 'wp2', 'wp3'],
    distance: 34.2,
    duration: '6h 45m',
    dateCreated: '2026-06-23',
    createdBy: 'Muhammadhudutahir@gmail.com'
  }
];
