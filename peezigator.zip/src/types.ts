/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type WaypointCategory =
  | 'Campsite'
  | 'Water Source'
  | 'Checkpoint'
  | 'Harbor'
  | 'Landmark'
  | 'Emergency Point'
  | 'Hazard'
  | 'Custom';

export interface User {
  fullName: string;
  email: string;
  profilePhoto: string; // Base64 or elegant SVG generator option
  createdDate: string;
}

export interface OfflineMap {
  id: string;
  name: string;
  region: string;
  size: number; // in MB
  downloadStatus: 'not_downloaded' | 'downloading' | 'downloaded';
  progress: number; // 0 to 100
  lastUpdated?: string;
  isCountry?: boolean; // country vs region
  // Geographical description for our vector map rendering
  boundingBox: {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
  };
  features: {
    type: 'river' | 'contour' | 'trail' | 'peak' | 'coastline';
    name?: string;
    elevation?: number;
    points: { x: number; y: number }[];
  }[];
}

export type NavigationMode = 'Driving' | 'Walking' | 'Desert Off-Road' | 'Sailing';

export interface Route {
  id: string;
  name: string;
  startLocation: string;
  destination: string;
  distance: number; // in km
  duration: string; // e.g. "4h 30m"
  createdBy: string;
  dateCreated: string;
  coordinates: { x: number; y: number }[]; // coordinates on our 100x100 relative map canvas
  mode: NavigationMode;
}

export interface Waypoint {
  id: string;
  name: string;
  latitude: number; // custom mapping offset in coordinate bounds
  longitude: number;
  category: WaypointCategory;
  notes: string;
  createdBy: string;
  dateCreated: string;
  x: number; // pixel coords on our canvas
  y: number;
  photoUrl?: string; // photo selection or offline path
  rating?: number; // 1 to 5 rating
  isFavorite?: boolean;
}

export interface Trip {
  id: string;
  name: string;
  description: string;
  routeIds: string[]; // List of routes in the trip
  waypointIds: string[]; // List of waypoints visited
  distance: number; // cumulative distance (km)
  duration: string; // cumulative duration
  dateCreated: string;
  createdBy: string;
}

export interface AppSettings {
  theme: 'light' | 'dark';
  gpsHighAccuracy: boolean;
  distanceUnit: 'km' | 'miles';
  mockCompassHeading: number;
  notificationsEnabled: boolean;
  offlineModeActive: boolean; // toggle to simulate absolute disconnection
  powerSaverMode: boolean; // helps manage power consumption in excursions
}
