/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import {
  CountryEmergencyData,
  getClosestCountryByCoordinates,
  getFallbackCountryByIsoCode
} from '../data/emergencyCountries';

interface UseCountrySOSProps {
  lat: number;
  lng: number;
  addToast: (msg: string) => void;
}

export function useCountrySOS({ lat, lng, addToast }: UseCountrySOSProps) {
  // 1. Core States
  const [gpsAvailable, setGpsAvailable] = useState<boolean>(() => {
    const saved = localStorage.getItem('peezigator_gps_sensor_available');
    return saved !== null ? saved === 'true' : true;
  });

  const [simCountryCode, setSimCountryCode] = useState<string>(() => {
    return localStorage.getItem('peezigator_sim_country_code') || 'DZ'; // Algeria as default SIM
  });

  const [detectionMethod, setDetectionMethod] = useState<'gps' | 'sim' | 'local_storage'>('gps');

  const [currentCountry, setCurrentCountry] = useState<CountryEmergencyData>(() => {
    // Initial calculation on load
    const lastKnownJson = localStorage.getItem('peezigator_last_known_country_data');
    if (lastKnownJson) {
      try {
        return JSON.parse(lastKnownJson);
      } catch (e) {
        // Fallback
      }
    }
    return getFallbackCountryByIsoCode('DZ', 'Algeria');
  });

  // Internet connectivity states
  const [isOnline, setIsOnline] = useState<boolean>(() => typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => {
    return localStorage.getItem('peezigator_emergency_db_last_sync') || '2026-07-15 12:00:00 (Offline Preloaded)';
  });

  // Track the previously active country to detect cross-border transitions
  const prevCountryCodeRef = useRef<string | null>(null);

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('peezigator_gps_sensor_available', String(gpsAvailable));
  }, [gpsAvailable]);

  useEffect(() => {
    localStorage.setItem('peezigator_sim_country_code', simCountryCode);
  }, [simCountryCode]);

  // Keep track of navigator online status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      // Trigger silent background synchronization when connection is restored
      triggerSilentSync();
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Silent sync helper
  const triggerSilentSync = () => {
    setIsSyncing(true);
    addToast("Network link detected. Silently syncing emergency rescue registry...");
    
    // Simulate a secure, lightweight background fetch/sync
    setTimeout(() => {
      setIsSyncing(false);
      const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
      localStorage.setItem('peezigator_emergency_db_last_sync', timestamp);
      setLastSyncTime(timestamp);
      addToast("Emergency rescue registry silently updated to the latest revision.");
    }, 2500);
  };

  // Perform country detection whenever coordinates, GPS availability, or SIM country code changes
  useEffect(() => {
    let resolvedCountry: CountryEmergencyData;
    let method: 'gps' | 'sim' | 'local_storage';

    if (gpsAvailable && lat !== undefined && lng !== undefined) {
      // 1. Detect using GPS location first
      resolvedCountry = getClosestCountryByCoordinates(lat, lng);
      method = 'gps';
    } else if (simCountryCode && simCountryCode !== 'none') {
      // 2. If GPS is unavailable, detect using mobile network/SIM country
      resolvedCountry = getFallbackCountryByIsoCode(simCountryCode);
      method = 'sim';
    } else {
      // 3. If both are unavailable, use the last known country stored locally
      const saved = localStorage.getItem('peezigator_last_known_country_data');
      if (saved) {
        try {
          resolvedCountry = JSON.parse(saved);
          method = 'local_storage';
        } catch (e) {
          resolvedCountry = getFallbackCountryByIsoCode('DZ', 'Algeria');
          method = 'local_storage';
        }
      } else {
        // Absolute fallback if nothing is stored
        resolvedCountry = getFallbackCountryByIsoCode('DZ', 'Algeria');
        method = 'local_storage';
      }
    }

    // Update state and persistence
    setCurrentCountry(resolvedCountry);
    setDetectionMethod(method);
    localStorage.setItem('peezigator_last_known_country_data', JSON.stringify(resolvedCountry));

    // Detect border crossing or country change
    if (prevCountryCodeRef.current !== null && prevCountryCodeRef.current !== resolvedCountry.isoCode) {
      // Only trigger notification when it transitions
      addToast(`Emergency contacts updated for ${resolvedCountry.countryName}.`);
    }
    
    prevCountryCodeRef.current = resolvedCountry.isoCode;
  }, [lat, lng, gpsAvailable, simCountryCode]);

  // Initial trigger flag setting so we don't alert on first load unless already loaded
  useEffect(() => {
    if (currentCountry) {
      prevCountryCodeRef.current = currentCountry.isoCode;
    }
  }, []);

  return {
    currentCountry,
    detectionMethod,
    gpsAvailable,
    setGpsAvailable,
    simCountryCode,
    setSimCountryCode,
    isOnline,
    isSyncing,
    lastSyncTime,
    triggerSilentSync
  };
}
