/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

let isStorageAvailable = false;
try {
  if (typeof window !== 'undefined' && 'localStorage' in window) {
    const testKey = '__storage_test__';
    window.localStorage.setItem(testKey, testKey);
    window.localStorage.removeItem(testKey);
    isStorageAvailable = true;
  }
} catch (e) {
  isStorageAvailable = false;
}

const memoryStorage: Record<string, string> = {};

export const safeStorage = {
  getItem(key: string): string | null {
    if (isStorageAvailable && typeof window !== 'undefined') {
      try {
        return window.localStorage.getItem(key);
      } catch (e) {
        return memoryStorage[key] || null;
      }
    }
    return memoryStorage[key] || null;
  },
  setItem(key: string, value: string): void {
    if (isStorageAvailable && typeof window !== 'undefined') {
      try {
        window.localStorage.setItem(key, value);
        return;
      } catch (e) {
        // Fallback
      }
    }
    memoryStorage[key] = value;
  },
  removeItem(key: string): void {
    if (isStorageAvailable && typeof window !== 'undefined') {
      try {
        window.localStorage.removeItem(key);
        return;
      } catch (e) {
        // Fallback
      }
    }
    delete memoryStorage[key];
  }
};
